﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Empleados : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Empleados
        public Empleados()
        {
            InitializeComponent();
            CargarEmpleados();
        }

        // Método para cargar los empleados desde la base de datos
        public void CargarEmpleados()
        {
            // Limpiar filas existentes en el DataGridView
            dgvEmpleados.Rows.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // Consulta SQL para obtener los datos de empleados, departamentos y puestos
                    string query = @"
                    SELECT E.ID_Empleado,
                           E.Nombre,
                           E.Apellidos,
                           E.DNI_NIF,
                           E.Fecha_Nacimiento,
                           E.Direccion,
                           E.Telefono,
                           E.Email,
                           E.Contrasenia,
                           E.Fecha_Contratacion,
                           D.Nombre AS Nombre_Departamento,
                           P.Nombre_Puesto
                    FROM EMPLEADO E
                    LEFT JOIN DEPARTAMENTO D ON E.ID_Departamento = D.ID_Departamento
                    JOIN PUESTO P ON E.ID_Puesto = P.ID_Puesto";

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    // Leer los datos y añadirlos al DataGridView
                    while (reader.Read())
                    {
                        int fila = dgvEmpleados.Rows.Add();
                        dgvEmpleados.Rows[fila].Cells["ID_Empleado"].Value = reader["ID_Empleado"];
                        dgvEmpleados.Rows[fila].Cells["Nombre"].Value = reader["Nombre"];
                        dgvEmpleados.Rows[fila].Cells["Apellidos"].Value = reader["Apellidos"];
                        dgvEmpleados.Rows[fila].Cells["DNI_NIF"].Value = reader["DNI_NIF"];
                        dgvEmpleados.Rows[fila].Cells["Fecha_Nacimiento"].Value = reader["Fecha_Nacimiento"];
                        dgvEmpleados.Rows[fila].Cells["Direccion"].Value = reader["Direccion"];
                        dgvEmpleados.Rows[fila].Cells["Telefono"].Value = reader["Telefono"];
                        dgvEmpleados.Rows[fila].Cells["Email"].Value = reader["Email"];
                        dgvEmpleados.Rows[fila].Cells["Contrasenia"].Value = reader["Contrasenia"];
                        dgvEmpleados.Rows[fila].Cells["Fecha_Contratacion"].Value = Convert.ToDateTime(reader["Fecha_Contratacion"]).ToString("dd/MM/yyyy");
                        dgvEmpleados.Rows[fila].Cells["Nombre_Departamento"].Value = reader["Nombre_Departamento"];
                        dgvEmpleados.Rows[fila].Cells["Nombre_Puesto"].Value = reader["Nombre_Puesto"];
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar empleados: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Método para manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvEmpleados.SelectedRows.Count > 0)
            {
                // Obtener el ID del empleado seleccionado
                int idEmpleado = Convert.ToInt32(dgvEmpleados.SelectedRows[0].Cells["ID_Empleado"].Value);
                // Abrir el formulario de edición de empleado
                EditarEmpleado editarForm = new EditarEmpleado(idEmpleado);
                if (editarForm.ShowDialog() == DialogResult.OK)
                {
                    CargarEmpleados();
                    MessageBox.Show("Empleado actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Seleccione un empleado para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Método para manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvEmpleados.SelectedRows.Count > 0)
            {
                // Obtener el ID del empleado seleccionado
                int idEmpleado = Convert.ToInt32(dgvEmpleados.SelectedRows[0].Cells["ID_Empleado"].Value);

                // Confirmar la eliminación con el usuario
                var confirm = MessageBox.Show("¿Está seguro de que desea borrar este empleado?",
                                              "Confirmar borrado",
                                              MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    // Eliminar el empleado de la base de datos
                    if (EliminarEmpleadoBD(idEmpleado))
                    {
                        CargarEmpleados();
                        MessageBox.Show("Empleado eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione un empleado para borrar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Método para eliminar un empleado de la base de datos
        private bool EliminarEmpleadoBD(int idEmpleado)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM EMPLEADO WHERE ID_Empleado = @ID_Empleado";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Empleado", idEmpleado);
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar empleado: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Método para manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IEmpleados(); // Asegurar que `IEmpleados` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Listado_de_Empleados{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de visualización del informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}