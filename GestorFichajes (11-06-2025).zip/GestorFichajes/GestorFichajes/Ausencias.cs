﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Ausencias : Form
    {
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        public Ausencias()
        {
            InitializeComponent();
            CargarDatos();
            // ConfigurarDataGridView(); // Eliminado, ya no se usa
        }

        // Método para cargar los datos de ausencias desde la base de datos
        public void CargarDatos()
        {
            dgvAusencias.Rows.Clear(); // Limpiar filas existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT
                            a.ID_Ausencia,
                            a.ID_Empleado,
                            e.Nombre + ' ' + e.Apellidos AS Empleado,
                            a.Tipo,
                            CONVERT(varchar, a.Fecha_Inicio, 103) AS Fecha_Inicio,
                            CASE
                                WHEN a.Fecha_Fin IS NULL THEN ''
                                ELSE CONVERT(varchar, a.Fecha_Fin, 103)
                            END AS Fecha_Fin,
                            CASE
                                WHEN a.Certificado = 1 THEN 'Sí'
                                ELSE 'No'
                            END AS Certificado,
                            ISNULL(a.Observaciones, '') AS Observaciones
                        FROM AUSENCIA a
                        INNER JOIN EMPLEADO e ON a.ID_Empleado = e.ID_Empleado
                        ORDER BY a.Fecha_Inicio DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            dgvAusencias.Rows.Add(
                                reader["ID_Ausencia"],
                                reader["ID_Empleado"],
                                reader["Empleado"],
                                reader["Tipo"],
                                reader["Fecha_Inicio"],
                                reader["Fecha_Fin"],
                                reader["Certificado"],
                                reader["Observaciones"]
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las ausencias: {ex.Message}", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvAusencias.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una ausencia para ver.", "Advertencia",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow fila = dgvAusencias.SelectedRows[0];

            int idAusencia = Convert.ToInt32(fila.Cells["ID_Ausencia"].Value);
            int idEmpleado = Convert.ToInt32(fila.Cells["ID_Empleado"].Value);
            string tipo = fila.Cells["Tipo"].Value.ToString();
            DateTime fechaInicio = DateTime.ParseExact(fila.Cells["Fecha_Inicio"].Value.ToString(), "dd/MM/yyyy", null);
            DateTime? fechaFin = string.IsNullOrWhiteSpace(fila.Cells["Fecha_Fin"].Value.ToString())
                ? (DateTime?)null
                : DateTime.ParseExact(fila.Cells["Fecha_Fin"].Value.ToString(), "dd/MM/yyyy", null);
            bool certificado = fila.Cells["Certificado"].Value.ToString() == "Sí";
            string observaciones = fila.Cells["Observaciones"].Value.ToString();

            AEAusencias frm = new AEAusencias(idAusencia, idEmpleado, tipo, fechaInicio, fechaFin, certificado, observaciones);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                CargarDatos();
            }
        }

        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvAusencias.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una ausencia para eliminar.", "Advertencia",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int idAusencia = Convert.ToInt32(dgvAusencias.SelectedRows[0].Cells["ID_Ausencia"].Value);
            string empleado = dgvAusencias.SelectedRows[0].Cells["Empleado"].Value.ToString();

            var confirm = MessageBox.Show(
                $"¿Está seguro de que desea eliminar la ausencia de {empleado}?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                if (EliminarAusenciaBD(idAusencia))
                {
                    MessageBox.Show("Ausencia eliminada correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarDatos();
                }
            }
        }

        private bool EliminarAusenciaBD(int idAusencia)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM AUSENCIA WHERE ID_Ausencia = @ID_Ausencia";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID_Ausencia", idAusencia);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar la ausencia: {ex.Message}", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void actualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CargarDatos();
        }

        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ReportDocument informe = new IAusencias();
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Informe_Ausencias{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe))
            {
                form.ShowDialog();
            }
        }
    }
}
