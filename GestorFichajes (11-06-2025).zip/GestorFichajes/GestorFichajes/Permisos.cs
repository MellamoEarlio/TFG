﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Permisos : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Permisos
        public Permisos()
        {
            InitializeComponent();
            CargarPermisos();
        }

        // Método para cargar los permisos desde la base de datos y mostrarlos en el DataGridView
        private void CargarPermisos()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"SELECT p.ID_Permiso,
                                e.Nombre + ' ' + e.Apellidos AS NombreEmpleado,
                                p.Fecha,
                                p.Horas,
                                p.Motivo,
                                p.Estado
                         FROM PERMISO p
                         JOIN EMPLEADO e ON p.ID_Empleado = e.ID_Empleado";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                dgvPermisos.Rows.Clear(); // Limpiar filas antes de agregar nuevas

                while (reader.Read())
                {
                    dgvPermisos.Rows.Add(
                        reader["ID_Permiso"],
                        reader["NombreEmpleado"], // Aquí mostramos el nombre del empleado en lugar del ID
                        reader["Fecha"],
                        reader["Horas"],
                        reader["Motivo"],
                        reader["Estado"]
                    );
                }
            }
        }

        // Método para manejar el evento de clic del menú "Añadir"
        private void añadirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AEPermiso form = new AEPermiso();
            if (form.ShowDialog() == DialogResult.OK)
            {
                CargarPermisos();
            }
        }

        // Método para manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvPermisos.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvPermisos.SelectedRows[0];
                AEPermiso form = new AEPermiso(
                    (int)row.Cells["ID_Permiso"].Value,
                    (DateTime)row.Cells["Fecha"].Value,
                    row.Cells["Motivo"].Value.ToString(),
                    row.Cells["Estado"].Value.ToString()
                );

                if (form.ShowDialog() == DialogResult.OK)
                {
                    CargarPermisos();
                }
            }
            else
            {
                MessageBox.Show("Selecciona un permiso para editar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvPermisos.SelectedRows.Count > 0)
            {
                int idPermiso = (int)dgvPermisos.SelectedRows[0].Cells["ID_Permiso"].Value;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM PERMISO WHERE ID_Permiso = @id", conn);
                    cmd.Parameters.AddWithValue("@id", idPermiso);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Permiso eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarPermisos();
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el permiso.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecciona un permiso para borrar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IPermiso(); // Asegurar que `IPermiso` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Listado_de_dias_de_Permiso{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de visualización del informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}