﻿using System;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Login : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Login
        public Login()
        {
            InitializeComponent();
            CargarDepartamentos();
            CargarPuestos();

            // Configurar eventos para validación en tiempo real
            tb_name.KeyPress += SoloLetras_KeyPress;
            tb_ape.KeyPress += SoloLetras_KeyPress;
            tb_dni.KeyPress += DNI_KeyPress;
            tb_phone.KeyPress += SoloNumeros_KeyPress;
            tb_email.Leave += Email_Leave;
        }

        // Método para cargar departamentos desde la base de datos
        private void CargarDepartamentos()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nombre FROM DEPARTAMENTO";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBox_depart.Items.Add(reader["Nombre"].ToString());
                        }
                    }
                }
            }
            if (comboBox_depart.Items.Count > 0)
                comboBox_depart.SelectedIndex = 0;
        }

        // Método para cargar puestos desde la base de datos
        private void CargarPuestos()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nombre_Puesto FROM PUESTO";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBox_puesto.Items.Add(reader["Nombre_Puesto"].ToString());
                        }
                    }
                }
            }
            if (comboBox_puesto.Items.Count > 0)
                comboBox_puesto.SelectedIndex = 0;
        }

        // Método para manejar el evento de clic del botón de login
        private void bttn_login_Click(object sender, EventArgs e)
        {
            string usuarioIngresado = tb_user.Text;
            string contraseñaIngresada = tb_pass.Text;

            if (ValidarCredenciales(usuarioIngresado, contraseñaIngresada))
            {
                MessageBox.Show($"Bienvenido, {NombreEmpleado}.");
                this.Hide();

                DialogResult resultado = MessageBox.Show("¿Deseas entrar en Gestor de la APP?",
                                                     "Selecciona destino",
                                                     MessageBoxButtons.YesNo,
                                                     MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    Gestor_de_la_APP gestor = new Gestor_de_la_APP(IdEmpleado);
                    gestor.Show();
                }
                else
                {
                    Main main = new Main(NombreEmpleado, IdEmpleado, PuestoEmpleado);
                    main.Show();
                }
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.");
            }
        }

        // Método para manejar el evento de clic del botón de registro
        private void bttn_signin_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            string nombre = tb_name.Text.Trim();
            string apellidos = tb_ape.Text.Trim();
            string dniNif = tb_dni.Text.Trim();
            DateTime fechaNacimiento = dtp_nacimiento.Value;
            string direccion = tb_address.Text.Trim();
            string telefono = tb_phone.Text.Trim();
            string email = tb_email.Text.Trim();
            string contraseña = tb_password.Text;
            DateTime fechaContratacion = dtp_contratacion.Value;

            string nombreDepartamento = comboBox_depart.SelectedItem?.ToString();
            string nombrePuesto = comboBox_puesto.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(nombreDepartamento) || string.IsNullOrEmpty(nombrePuesto))
            {
                MessageBox.Show("Error: Debe seleccionar un departamento y un puesto.");
                return;
            }

            int idDepartamento = ObtenerIdDepartamento(nombreDepartamento);
            int idPuesto = ObtenerIdPuesto(nombrePuesto);

            if (idDepartamento == -1 || idPuesto == -1)
            {
                MessageBox.Show("Error: Departamento o puesto no encontrados.");
                return;
            }

            if (RegistrarUsuario(nombre, apellidos, dniNif, fechaNacimiento, direccion, telefono, email, contraseña, fechaContratacion, idDepartamento, idPuesto))
            {
                MessageBox.Show("Registro exitoso.");
                this.Hide();

                int nuevoId = ObtenerUltimoIdEmpleado();
                Main main = new Main(nombre, nuevoId, idPuesto);
                main.ShowDialog();
            }
            else
            {
                MessageBox.Show("Error al registrar el usuario.");
            }
        }

        // Propiedades estáticas para almacenar información del empleado
        public static string NombreEmpleado { get; private set; }
        public static int IdEmpleado { get; private set; }
        public static int PuestoEmpleado { get; private set; }

        // Método para validar las credenciales del usuario
        private bool ValidarCredenciales(string usuario, string contraseña)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Empleado, Nombre, ID_Puesto FROM EMPLEADO WHERE Nombre = @usuario AND Contrasenia = @contraseña";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@usuario", usuario);
                    cmd.Parameters.AddWithValue("@contraseña", contraseña);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            IdEmpleado = Convert.ToInt32(reader["ID_Empleado"]);
                            NombreEmpleado = reader["Nombre"].ToString();
                            PuestoEmpleado = Convert.ToInt32(reader["ID_Puesto"]);
                            return true;
                        }
                        return false;
                    }
                }
            }
        }

        // Método para obtener el último ID de empleado registrado
        private int ObtenerUltimoIdEmpleado()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT MAX(ID_Empleado) FROM EMPLEADO";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        // Método para obtener el ID de un departamento por su nombre
        private int ObtenerIdDepartamento(string nombreDepartamento)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Departamento FROM DEPARTAMENTO WHERE Nombre = @nombreDepartamento";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nombreDepartamento", nombreDepartamento);
                    object result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
        }

        // Método para obtener el ID de un puesto por su nombre
        private int ObtenerIdPuesto(string nombrePuesto)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Puesto FROM PUESTO WHERE Nombre_Puesto = @nombrePuesto";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nombrePuesto", nombrePuesto);
                    object result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
        }

        // Método para registrar un nuevo usuario en la base de datos
        private bool RegistrarUsuario(string nombre, string apellidos, string dniNif, DateTime fechaNacimiento,
                                    string direccion, string telefono, string email, string contraseña,
                                    DateTime fechaContratacion, int idDepartamento, int idPuesto)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"INSERT INTO EMPLEADO (Nombre, Apellidos, DNI_NIF, Fecha_Nacimiento, Direccion,
                                Telefono, Email, Contrasenia, Fecha_Contratacion, ID_Departamento, ID_Puesto)
                                VALUES (@nombre, @apellidos, @dniNif, @fechaNacimiento, @direccion, @telefono,
                                @email, @contrasenia, @fechaContratacion, @idDepartamento, @idPuesto)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@apellidos", apellidos);
                    cmd.Parameters.AddWithValue("@dniNif", dniNif);
                    cmd.Parameters.AddWithValue("@fechaNacimiento", fechaNacimiento);
                    cmd.Parameters.AddWithValue("@direccion", direccion);
                    cmd.Parameters.AddWithValue("@telefono", telefono);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@contrasenia", contraseña);
                    cmd.Parameters.AddWithValue("@fechaContratacion", fechaContratacion);
                    cmd.Parameters.AddWithValue("@idDepartamento", idDepartamento);
                    cmd.Parameters.AddWithValue("@idPuesto", idPuesto);

                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Método para mostrar el panel de registro al hacer clic en el enlace
        private void lbl_nocuenta_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }

        // Método para mostrar el panel de login al hacer clic en el enlace
        private void lbl_sicuenta_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }

        #region Métodos de Validación

        // Método para validar los campos de entrada del usuario
        private bool ValidarCampos()
        {
            // Validar Nombre
            if (string.IsNullOrWhiteSpace(tb_name.Text) || !EsSoloLetras(tb_name.Text))
            {
                MessageBox.Show("El nombre solo puede contener letras y espacios.", "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_name.Focus();
                return false;
            }

            // Validar Apellidos
            if (string.IsNullOrWhiteSpace(tb_ape.Text) || !EsSoloLetras(tb_ape.Text))
            {
                MessageBox.Show("Los apellidos solo pueden contener letras y espacios.", "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_ape.Focus();
                return false;
            }

            // Validar DNI
            if (!ValidarDNI(tb_dni.Text.Trim()))
            {
                MessageBox.Show("El DNI/NIF debe tener 8 números seguidos de 1 letra.", "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_dni.Focus();
                return false;
            }

            // Validar Teléfono
            if (string.IsNullOrWhiteSpace(tb_phone.Text) || !EsSoloNumeros(tb_phone.Text))
            {
                MessageBox.Show("El teléfono solo puede contener números.", "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_phone.Focus();
                return false;
            }

            // Validar Email
            if (!ValidarEmail(tb_email.Text.Trim()))
            {
                MessageBox.Show("Por favor, introduce una dirección de email válida.", "Error de validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_email.Focus();
                return false;
            }

            return true;
        }

        // Método para permitir solo letras y espacios en un TextBox
        private void SoloLetras_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // Método para permitir solo números en un TextBox
        private void SoloNumeros_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // Método para validar el formato del DNI/NIF en un TextBox
        private void DNI_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (char.IsControl(e.KeyChar))
                return;

            if (textBox.Text.Length >= 8 && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                return;
            }

            if (textBox.Text.Length < 8 && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // Método para validar el formato del email cuando se pierde el foco del TextBox
        private void Email_Leave(object sender, EventArgs e)
        {
            if (!ValidarEmail(tb_email.Text.Trim()))
            {
                MessageBox.Show("Por favor, introduce una dirección de email válida.", "Email inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_email.Focus();
            }
        }

        // Método para verificar si un texto contiene solo letras y espacios
        private bool EsSoloLetras(string texto)
        {
            return Regex.IsMatch(texto, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$");
        }

        // Método para verificar si un texto contiene solo números
        private bool EsSoloNumeros(string texto)
        {
            return Regex.IsMatch(texto, @"^\d+$");
        }

        // Método para validar el formato del DNI/NIF
        private bool ValidarDNI(string dni)
        {
            return Regex.IsMatch(dni, @"^\d{8}[a-zA-Z]$");
        }

        // Método para validar el formato del email
        private bool ValidarEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        #endregion
    }
}