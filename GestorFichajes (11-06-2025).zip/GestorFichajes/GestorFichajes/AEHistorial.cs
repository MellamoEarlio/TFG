﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class AEHistorial : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        // ID del historial de cambio de puesto, puede ser nulo si es una nueva entrada
        private readonly int? idHistorial;
        // ID del puesto anterior del empleado seleccionado
        private int idPuestoAnterior;

        // Constructor de la clase AEHistorial
        public AEHistorial(int? id = null, DateTime? fechaCambio = null, string motivo = "")
        {
            InitializeComponent();
            idHistorial = id;

            CargarEmpleados();
            CargarPuestos();

            if (fechaCambio.HasValue) dTPFecha.Value = fechaCambio.Value;
            tBMotivo.Text = motivo;

            // Suscribirse al evento de cambio de selección del ComboBox de empleados
            comboBoxEmpleado.SelectedIndexChanged += ComboBoxEmpleado_SelectedIndexChanged;
        }

        // Método para cargar los empleados en el ComboBox
        private void CargarEmpleados()
        {
            comboBoxEmpleado.Items.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Empleado, Nombre + ' ' + Apellidos AS NombreCompleto FROM EMPLEADO";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    comboBoxEmpleado.Items.Add(new ComboBoxItem
                    {
                        Text = reader["NombreCompleto"].ToString(),
                        Value = (int)reader["ID_Empleado"]
                    });
                }
            }

            if (comboBoxEmpleado.Items.Count > 0)
                comboBoxEmpleado.SelectedIndex = 0;
        }

        // Método para cargar los puestos en el ComboBox
        private void CargarPuestos()
        {
            comboBoxPuesto.Items.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Puesto, Nombre_Puesto FROM PUESTO";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    comboBoxPuesto.Items.Add(new ComboBoxItem
                    {
                        Text = reader["Nombre_Puesto"].ToString(),
                        Value = (int)reader["ID_Puesto"]
                    });
                }
            }

            if (comboBoxPuesto.Items.Count > 0)
                comboBoxPuesto.SelectedIndex = 0;
        }

        // Maneja el evento de cambio de selección en el ComboBox de empleados
        private void ComboBoxEmpleado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxEmpleado.SelectedItem is ComboBoxItem empleado)
            {
                idPuestoAnterior = ObtenerPuestoActual(empleado.Value);
                SeleccionarPuestoAnterior(idPuestoAnterior);
            }
        }

        // Obtiene el ID del puesto actual del empleado seleccionado
        private int ObtenerPuestoActual(int idEmpleado)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Puesto FROM EMPLEADO WHERE ID_Empleado = @idEmpleado";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    return (int)reader["ID_Puesto"];
                }
            }
            return 0;
        }

        // Selecciona el puesto anterior en el ComboBox de puestos
        private void SeleccionarPuestoAnterior(int idPuestoAnterior)
        {
            for (int i = 0; i < comboBoxPuesto.Items.Count; i++)
            {
                if (comboBoxPuesto.Items[i] is ComboBoxItem item && item.Value == idPuestoAnterior)
                {
                    comboBoxPuesto.SelectedIndex = i;
                    break;
                }
            }
        }

        // Verifica si un puesto existe en la base de datos
        private bool PuestoExiste(int idPuesto)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM PUESTO WHERE ID_Puesto = @idPuesto";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@idPuesto", idPuesto);

                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
        }

        // Maneja el evento de clic del botón Aceptar
        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            if (!(comboBoxEmpleado.SelectedItem is ComboBoxItem empleado) || !(comboBoxPuesto.SelectedItem is ComboBoxItem puestoNuevo))
            {
                MessageBox.Show("Debes seleccionar un empleado y un puesto válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(tBMotivo.Text))
            {
                MessageBox.Show("El motivo no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!PuestoExiste(idPuestoAnterior))
            {
                MessageBox.Show("El puesto anterior seleccionado no existe en la base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd;

                if (idHistorial.HasValue)
                {
                    cmd = new SqlCommand(@"UPDATE HISTORIAL_PUESTO SET
                                            ID_Empleado = @idEmpleado,
                                            ID_Puesto_Anterior = @idPuestoAnterior,
                                            ID_Puesto_Nuevo = @idPuestoNuevo,
                                            Fecha_Cambio = @fecha,
                                            Motivo = @motivo
                                            WHERE ID_Historial = @id", conn);
                    cmd.Parameters.AddWithValue("@id", idHistorial.Value);
                }
                else
                {
                    cmd = new SqlCommand(@"INSERT INTO HISTORIAL_PUESTO
                                          (ID_Empleado, ID_Puesto_Anterior, ID_Puesto_Nuevo, Fecha_Cambio, Motivo)
                                          VALUES (@idEmpleado, @idPuestoAnterior, @idPuestoNuevo, @fecha, @motivo)", conn);
                }

                cmd.Parameters.AddWithValue("@idEmpleado", empleado.Value);
                cmd.Parameters.AddWithValue("@idPuestoAnterior", idPuestoAnterior);
                cmd.Parameters.AddWithValue("@idPuestoNuevo", puestoNuevo.Value);
                cmd.Parameters.AddWithValue("@fecha", dTPFecha.Value);
                cmd.Parameters.AddWithValue("@motivo", tBMotivo.Text.Trim());

                if (cmd.ExecuteNonQuery() > 0)
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Error al guardar el historial.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Maneja el evento de clic del botón Cancelar
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        // Clase auxiliar para manejar los items del ComboBox
        private class ComboBoxItem
        {
            public string Text { get; set; }
            public int Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }
    }
}