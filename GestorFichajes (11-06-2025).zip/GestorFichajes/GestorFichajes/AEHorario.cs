﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class AEHorario : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        // ID del horario, puede ser nulo si es una nueva entrada
        private int? idHorario;
        // ID del empleado al que pertenece el horario
        private int idEmpleado;
        // Indica si se está editando un horario existente
        private bool esEdicion;

        // Constructor para añadir nuevo horario
        public AEHorario(int idEmpleado)
        {
            InitializeComponent();
            this.idEmpleado = idEmpleado;
            esEdicion = false;
            CargarDias();
            CargarOpcionesFlexible();
            Text = "Añadir Nuevo Horario";
            dTPEntrada.Value = DateTime.Now;
            dTPSalida.Value = DateTime.Now;
        }

        // Constructor para editar horario existente
        public AEHorario(int idHorario, int idEmpleado, string dia, TimeSpan entrada, TimeSpan salida, bool flexible)
        {
            InitializeComponent();
            this.idHorario = idHorario;
            this.idEmpleado = idEmpleado;
            esEdicion = true;
            Text = "Editar Horario";

            CargarDias();
            CargarOpcionesFlexible();

            comboBoxDia.SelectedValue = dia;
            dTPEntrada.Value = DateTime.Today.Add(entrada);
            dTPSalida.Value = DateTime.Today.Add(salida);
            comboBoxFlexible.SelectedValue = flexible ? "Sí" : "No";
        }

        // Método para cargar los días de la semana en el ComboBox
        private void CargarDias()
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Dia");
                dt.Rows.Add("Lunes");
                dt.Rows.Add("Martes");
                dt.Rows.Add("Miércoles");
                dt.Rows.Add("Jueves");
                dt.Rows.Add("Viernes");
                dt.Rows.Add("Sábado");
                dt.Rows.Add("Domingo");

                comboBoxDia.DataSource = dt;
                comboBoxDia.DisplayMember = "Dia";
                comboBoxDia.ValueMember = "Dia";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los días: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para cargar las opciones de horario flexible en el ComboBox
        private void CargarOpcionesFlexible()
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Opcion");
                dt.Rows.Add("Sí");
                dt.Rows.Add("No");

                comboBoxFlexible.DataSource = dt;
                comboBoxFlexible.DisplayMember = "Opcion";
                comboBoxFlexible.ValueMember = "Opcion";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las opciones de horario flexible: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Maneja el evento de clic del botón Aceptar
        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            // Validar que se haya seleccionado un día de la semana
            if (comboBoxDia.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar un día de la semana.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que la hora de entrada sea anterior a la hora de salida
            if (dTPEntrada.Value.TimeOfDay >= dTPSalida.Value.TimeOfDay)
            {
                MessageBox.Show("La hora de entrada debe ser anterior a la hora de salida.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string dia = comboBoxDia.SelectedValue.ToString();
                    TimeSpan entrada = dTPEntrada.Value.TimeOfDay;
                    TimeSpan salida = dTPSalida.Value.TimeOfDay;
                    bool flexible = comboBoxFlexible.SelectedValue.ToString() == "Sí";

                    if (esEdicion)
                    {
                        // Actualizar horario existente
                        string query = @"
                        UPDATE HORARIO
                        SET Dia_Semana = @Dia,
                            Hora_Entrada = @Entrada,
                            Hora_Salida = @Salida,
                            Flexible = @Flexible
                        WHERE ID_Horario = @ID_Horario";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ID_Horario", idHorario);
                            command.Parameters.AddWithValue("@Dia", dia);
                            command.Parameters.AddWithValue("@Entrada", entrada);
                            command.Parameters.AddWithValue("@Salida", salida);
                            command.Parameters.AddWithValue("@Flexible", flexible);

                            command.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // Insertar nuevo horario
                        string query = @"
                        INSERT INTO HORARIO (ID_Empleado, Dia_Semana, Hora_Entrada, Hora_Salida, Flexible)
                        VALUES (@ID_Empleado, @Dia, @Entrada, @Salida, @Flexible)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ID_Empleado", idEmpleado);
                            command.Parameters.AddWithValue("@Dia", dia);
                            command.Parameters.AddWithValue("@Entrada", entrada);
                            command.Parameters.AddWithValue("@Salida", salida);
                            command.Parameters.AddWithValue("@Flexible", flexible);

                            command.ExecuteNonQuery();
                        }
                    }

                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) // Violación de constraint UNIQUE
                {
                    MessageBox.Show("Ya existe un horario para este empleado en el día seleccionado.", "Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show($"Error al guardar el horario: {ex.Message}", "Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar el horario: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Maneja el evento de clic del botón Cancelar
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}