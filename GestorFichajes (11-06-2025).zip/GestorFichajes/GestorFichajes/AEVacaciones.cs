﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class AEVacaciones : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        // ID de las vacaciones, puede ser nulo
        private readonly int? idVacaciones;

        // Constructor de la clase AEVacaciones
        public AEVacaciones(int? id = null, DateTime? inicio = null, DateTime? fin = null, string estado = "", string motivo = "", int idEmpleado = 0)
        {
            InitializeComponent();
            idVacaciones = id;

            // Cargar empleados y estados en los ComboBox
            CargarEmpleados();
            CargarEstados();

            // Asignar valores a los controles si se proporcionan
            if (inicio.HasValue) dTPInicio.Value = inicio.Value;
            if (fin.HasValue) dTPFin.Value = fin.Value;
            if (!string.IsNullOrWhiteSpace(estado)) comboBoxEstado.Text = estado;
            tbMotivo.Text = motivo;

            // Seleccionar el empleado por ID si se proporciona
            if (idEmpleado > 0)
                SeleccionarEmpleadoPorId(idEmpleado);
        }

        // Método para cargar empleados en el ComboBox
        private void CargarEmpleados()
        {
            comboBoxEmpleado.Items.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Empleado, Nombre + ' ' + Apellidos AS NombreCompleto FROM EMPLEADO";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                // Leer los resultados y añadir a ComboBoxItem
                while (reader.Read())
                {
                    comboBoxEmpleado.Items.Add(new ComboBoxItem
                    {
                        Text = reader["NombreCompleto"].ToString(),
                        Value = (int)reader["ID_Empleado"]
                    });
                }
            }

            // Seleccionar el primer empleado por defecto
            if (comboBoxEmpleado.Items.Count > 0)
                comboBoxEmpleado.SelectedIndex = 0;
        }

        // Método para seleccionar un empleado por su ID
        private void SeleccionarEmpleadoPorId(int idEmpleado)
        {
            for (int i = 0; i < comboBoxEmpleado.Items.Count; i++)
            {
                if (comboBoxEmpleado.Items[i] is ComboBoxItem item && item.Value == idEmpleado)
                {
                    comboBoxEmpleado.SelectedIndex = i;
                    break;
                }
            }
        }

        // Método para cargar estados en el ComboBox
        private void CargarEstados()
        {
            comboBoxEstado.Items.Clear();
            comboBoxEstado.Items.Add("Pendiente");
            comboBoxEstado.Items.Add("Aprobado");
            comboBoxEstado.Items.Add("Rechazado");
            comboBoxEstado.Items.Add("Cancelado");

            comboBoxEstado.SelectedIndex = 0;
        }

        // Manejar el evento de clic del botón Aceptar
        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            // Validar que la fecha de fin no sea anterior a la de inicio
            if (dTPFin.Value < dTPInicio.Value)
            {
                MessageBox.Show("La fecha de fin no puede ser anterior a la de inicio.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que se haya seleccionado un empleado
            if (comboBoxEmpleado.SelectedItem == null)
            {
                MessageBox.Show("Debes seleccionar un empleado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar el estado seleccionado
            string estado = comboBoxEstado.Text.Trim();
            if (estado != "Pendiente" && estado != "Aprobado" && estado != "Rechazado" && estado != "Cancelado")
            {
                MessageBox.Show("Valor de estado no válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Obtener el ID del empleado seleccionado
            int idEmpleado = ((ComboBoxItem)comboBoxEmpleado.SelectedItem).Value;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd;

                if (idVacaciones.HasValue)
                {
                    // Modo edición: actualizar el registro existente
                    cmd = new SqlCommand(@"UPDATE VACACIONES SET
                                            Fecha_Inicio = @inicio,
                                            Fecha_Fin = @fin,
                                            Estado = @estado,
                                            Motivo = @motivo,
                                            ID_Empleado = @idEmpleado
                                            WHERE ID_Vacaciones = @id", conn);
                    cmd.Parameters.AddWithValue("@id", idVacaciones.Value);
                }
                else
                {
                    // Modo alta: insertar un nuevo registro
                    cmd = new SqlCommand(@"INSERT INTO VACACIONES
                                          (ID_Empleado, Fecha_Inicio, Fecha_Fin, Estado, Motivo)
                                          VALUES (@idEmpleado, @inicio, @fin, @estado, @motivo)", conn);
                }

                // Añadir parámetros a la consulta
                cmd.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                cmd.Parameters.AddWithValue("@inicio", dTPInicio.Value);
                cmd.Parameters.AddWithValue("@fin", dTPFin.Value);
                cmd.Parameters.AddWithValue("@estado", estado);
                cmd.Parameters.AddWithValue("@motivo", tbMotivo.Text.Trim());

                // Ejecutar la consulta y verificar si se realizó correctamente
                if (cmd.ExecuteNonQuery() > 0)
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Error al guardar las vacaciones.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Manejar el evento de clic del botón Cancelar
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        // Clase interna para representar un elemento del ComboBox
        private class ComboBoxItem
        {
            public string Text { get; set; }
            public int Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }
    }
}