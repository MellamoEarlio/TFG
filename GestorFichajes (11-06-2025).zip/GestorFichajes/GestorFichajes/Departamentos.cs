﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Departamentos : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Departamentos
        public Departamentos()
        {
            InitializeComponent();
            CargarDatos();
            ConfigurarDataGridView();
        }

        // Método para configurar el DataGridView
        private void ConfigurarDataGridView()
        {
            // Desactivar la generación automática de columnas
            dgvDepartamentos.AutoGenerateColumns = false;
            // Desactivar la adición y eliminación de filas por el usuario
            dgvDepartamentos.AllowUserToAddRows = false;
            dgvDepartamentos.AllowUserToDeleteRows = false;
            // Establecer el DataGridView como de solo lectura
            dgvDepartamentos.ReadOnly = true;
            // Configurar el modo de selección de filas
            dgvDepartamentos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDepartamentos.MultiSelect = false;
            // Ajustar el tamaño de las columnas automáticamente
            dgvDepartamentos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Configurar columnas manualmente
            dgvDepartamentos.Columns.Clear();

            // Columna ID (oculta)
            DataGridViewTextBoxColumn colId = new DataGridViewTextBoxColumn
            {
                Name = "ID_Departamento",
                HeaderText = "ID",
                DataPropertyName = "ID_Departamento",
                Visible = false
            };
            dgvDepartamentos.Columns.Add(colId);

            // Columna Nombre
            DataGridViewTextBoxColumn colNombre = new DataGridViewTextBoxColumn
            {
                Name = "Nombre",
                HeaderText = "Nombre",
                DataPropertyName = "Nombre",
                Width = 150
            };
            dgvDepartamentos.Columns.Add(colNombre);

            // Columna Descripción
            DataGridViewTextBoxColumn colDescripcion = new DataGridViewTextBoxColumn
            {
                Name = "Descripcion",
                HeaderText = "Descripción",
                DataPropertyName = "Descripcion",
                Width = 200
            };
            dgvDepartamentos.Columns.Add(colDescripcion);

            // Columna Responsable
            DataGridViewTextBoxColumn colResponsable = new DataGridViewTextBoxColumn
            {
                Name = "Responsable",
                HeaderText = "Responsable",
                DataPropertyName = "Responsable",
                Width = 150
            };
            dgvDepartamentos.Columns.Add(colResponsable);

            // Columna ID_Responsable (oculta)
            DataGridViewTextBoxColumn colIdResponsable = new DataGridViewTextBoxColumn
            {
                Name = "ID_Responsable",
                HeaderText = "ID Responsable",
                DataPropertyName = "ID_Responsable",
                Visible = false
            };
            dgvDepartamentos.Columns.Add(colIdResponsable);
        }

        // Método para cargar los datos de departamentos desde la base de datos
        public void CargarDatos()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Consultar los datos de departamentos y empleados responsables
                    string query = @"
                    SELECT
                        d.ID_Departamento,
                        d.Nombre,
                        ISNULL(d.Descripcion, '') AS Descripcion,
                        d.ID_Responsable,
                        CASE
                            WHEN e.ID_Empleado IS NULL THEN 'Sin responsable'
                            ELSE e.Nombre + ' ' + e.Apellidos
                        END AS Responsable
                    FROM DEPARTAMENTO d
                    LEFT JOIN EMPLEADO e ON d.ID_Responsable = e.ID_Empleado
                    ORDER BY d.Nombre";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvDepartamentos.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los departamentos: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del menú "Añadir"
        private void añadirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Abrir el formulario para añadir un nuevo departamento
            AEDepartamento frm = new AEDepartamento();
            if (frm.ShowDialog() == DialogResult.OK)
            {
                CargarDatos();
            }
        }

        // Método para manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvDepartamentos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un departamento para editar.", "Advertencia",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow fila = dgvDepartamentos.SelectedRows[0];

            // Obtener los datos de la fila seleccionada
            int idDepartamento = Convert.ToInt32(fila.Cells["ID_Departamento"].Value);
            string nombre = fila.Cells["Nombre"].Value.ToString();
            string descripcion = fila.Cells["Descripcion"].Value.ToString();
            int? idResponsable = string.IsNullOrWhiteSpace(fila.Cells["ID_Responsable"].Value.ToString())
                ? (int?)null
                : Convert.ToInt32(fila.Cells["ID_Responsable"].Value);

            // Abrir el formulario para editar el departamento seleccionado
            AEDepartamento frm = new AEDepartamento(idDepartamento, nombre, descripcion, idResponsable);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                CargarDatos();
            }
        }

        // Método para manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvDepartamentos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un departamento para eliminar.", "Advertencia",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int idDepartamento = Convert.ToInt32(dgvDepartamentos.SelectedRows[0].Cells["ID_Departamento"].Value);
            string nombre = dgvDepartamentos.SelectedRows[0].Cells["Nombre"].Value.ToString();

            // Verificar si el departamento tiene empleados asignados
            if (TieneEmpleadosAsignados(idDepartamento))
            {
                MessageBox.Show("No se puede eliminar el departamento porque tiene empleados asignados.", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var confirm = MessageBox.Show(
                $"¿Está seguro de que desea eliminar el departamento '{nombre}'?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                if (EliminarDepartamentoBD(idDepartamento))
                {
                    MessageBox.Show("Departamento eliminado correctamente.", "Éxito",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarDatos();
                }
            }
        }

        // Método para verificar si un departamento tiene empleados asignados
        private bool TieneEmpleadosAsignados(int idDepartamento)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM EMPLEADO WHERE ID_Departamento = @ID_Departamento";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID_Departamento", idDepartamento);
                        int count = Convert.ToInt32(command.ExecuteScalar());
                        return count > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al verificar empleados del departamento: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return true; // Por precaución, asumimos que tiene empleados para evitar eliminaciones no deseadas
            }
        }

        // Método para eliminar un departamento de la base de datos
        private bool EliminarDepartamentoBD(int idDepartamento)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM DEPARTAMENTO WHERE ID_Departamento = @ID_Departamento";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID_Departamento", idDepartamento);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el departamento: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Método para manejar el evento de clic del menú "Actualizar"
        private void actualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CargarDatos();
        }

        // Método para manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IDepartamentos(); // Asegurar que `IDepartamentos` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Listado_de_Departamentos{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de visualización del informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}