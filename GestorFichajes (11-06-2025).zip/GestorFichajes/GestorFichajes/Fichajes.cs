﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Fichajes : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Fichajes
        public Fichajes()
        {
            InitializeComponent();
            CargarFichajes();
        }

        // Método para cargar los fichajes desde la base de datos
        public void CargarFichajes()
        {
            // Limpiar filas existentes en el DataGridView
            dgvFichaje.Rows.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // Consulta SQL para obtener los datos de fichajes y empleados
                    string query = @"
                    SELECT F.ID_Fichaje,
                           E.Nombre + ' ' + E.Apellidos AS Nombre_Empleado,
                           F.Fecha_Hora_Entrada,
                           F.Fecha_Hora_Salida,
                           F.Tipo_Fichaje,
                           F.Metodo_Fichaje,
                           F.Ubicacion_Fichaje,
                           F.Estado
                    FROM FICHAJE F
                    JOIN EMPLEADO E ON F.ID_Empleado = E.ID_Empleado";

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    // Leer los datos y añadirlos al DataGridView
                    while (reader.Read())
                    {
                        int fila = dgvFichaje.Rows.Add();
                        dgvFichaje.Rows[fila].Cells["ID_Fichaje"].Value = reader["ID_Fichaje"];
                        dgvFichaje.Rows[fila].Cells["Nombre_Empleado"].Value = reader["Nombre_Empleado"];
                        dgvFichaje.Rows[fila].Cells["Fecha_Hora_Entrada"].Value = Convert.ToDateTime(reader["Fecha_Hora_Entrada"]).ToString("dd/MM/yyyy HH:mm");
                        dgvFichaje.Rows[fila].Cells["Fecha_Hora_Salida"].Value = reader["Fecha_Hora_Salida"] == DBNull.Value ? "" : Convert.ToDateTime(reader["Fecha_Hora_Salida"]).ToString("dd/MM/yyyy HH:mm");
                        dgvFichaje.Rows[fila].Cells["Tipo_Fichaje"].Value = reader["Tipo_Fichaje"];
                        dgvFichaje.Rows[fila].Cells["Metodo_Fichaje"].Value = reader["Metodo_Fichaje"];
                        dgvFichaje.Rows[fila].Cells["Ubicacion_Fichaje"].Value = reader["Ubicacion_Fichaje"];
                        dgvFichaje.Rows[fila].Cells["Estado"].Value = reader["Estado"];
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar fichajes: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Método para manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvFichaje.SelectedRows.Count > 0)
            {
                // Obtener el ID del fichaje seleccionado
                int idFichaje = Convert.ToInt32(dgvFichaje.SelectedRows[0].Cells["ID_Fichaje"].Value);
                // Abrir el formulario de edición de fichaje
                EditarFichaje editarForm = new EditarFichaje(idFichaje); // Este formulario deberás crearlo
                if (editarForm.ShowDialog() == DialogResult.OK)
                {
                    CargarFichajes();
                    MessageBox.Show("Fichaje actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Seleccione un fichaje para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Método para manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvFichaje.SelectedRows.Count > 0)
            {
                // Obtener el ID del fichaje seleccionado
                int idFichaje = Convert.ToInt32(dgvFichaje.SelectedRows[0].Cells["ID_Fichaje"].Value);

                // Confirmar la eliminación con el usuario
                var confirm = MessageBox.Show("¿Está seguro de que desea borrar este fichaje?",
                                              "Confirmar borrado",
                                              MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    // Eliminar el fichaje de la base de datos
                    if (EliminarFichajeBD(idFichaje))
                    {
                        CargarFichajes();
                        MessageBox.Show("Fichaje eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione un fichaje para borrar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Método para eliminar un fichaje de la base de datos
        private bool EliminarFichajeBD(int idFichaje)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM FICHAJE WHERE ID_Fichaje = @ID_Fichaje";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Fichaje", idFichaje);
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar fichaje: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Método para manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IFichajes(); // Asegurar que `IFichajes` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Listado_de_Fichajes{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de visualización del informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}