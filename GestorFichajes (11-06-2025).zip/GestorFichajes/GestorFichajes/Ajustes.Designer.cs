﻿namespace GestorFichajes
{
    partial class Ajustes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lblInformacion = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblApe = new System.Windows.Forms.Label();
            this.lblDNI = new System.Windows.Forms.Label();
            this.lblNacimiento = new System.Windows.Forms.Label();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.lblTele = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblContra = new System.Windows.Forms.Label();
            this.lblContratacion = new System.Windows.Forms.Label();
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.lblPuesto = new System.Windows.Forms.Label();
            this.lblworkstation = new System.Windows.Forms.Label();
            this.lbldepart = new System.Windows.Forms.Label();
            this.lblhiring = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.lblmail = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblbirth = new System.Windows.Forms.Label();
            this.lblnif = new System.Windows.Forms.Label();
            this.lblsubname = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblIncidencia = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bttnCancelar = new System.Windows.Forms.Button();
            this.bttnEnviar = new System.Windows.Forms.Button();
            this.tbIncidencia = new System.Windows.Forms.TextBox();
            this.lblinfoIncidencia = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(933, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lblInformacion
            // 
            this.lblInformacion.AutoSize = true;
            this.lblInformacion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformacion.Location = new System.Drawing.Point(15, 15);
            this.lblInformacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInformacion.Name = "lblInformacion";
            this.lblInformacion.Size = new System.Drawing.Size(117, 15);
            this.lblInformacion.TabIndex = 2;
            this.lblInformacion.Text = "Datos del empleado";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(15, 57);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(51, 15);
            this.lblNombre.TabIndex = 3;
            this.lblNombre.Text = "Nombre";
            // 
            // lblApe
            // 
            this.lblApe.AutoSize = true;
            this.lblApe.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApe.Location = new System.Drawing.Point(15, 82);
            this.lblApe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblApe.Name = "lblApe";
            this.lblApe.Size = new System.Drawing.Size(56, 15);
            this.lblApe.TabIndex = 4;
            this.lblApe.Text = "Apellidos";
            // 
            // lblDNI
            // 
            this.lblDNI.AutoSize = true;
            this.lblDNI.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDNI.Location = new System.Drawing.Point(15, 110);
            this.lblDNI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDNI.Name = "lblDNI";
            this.lblDNI.Size = new System.Drawing.Size(30, 15);
            this.lblDNI.TabIndex = 5;
            this.lblDNI.Text = "DNI ";
            // 
            // lblNacimiento
            // 
            this.lblNacimiento.AutoSize = true;
            this.lblNacimiento.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNacimiento.Location = new System.Drawing.Point(15, 136);
            this.lblNacimiento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNacimiento.Name = "lblNacimiento";
            this.lblNacimiento.Size = new System.Drawing.Size(67, 30);
            this.lblNacimiento.TabIndex = 6;
            this.lblNacimiento.Text = "Fecha de\r\nnacimiento";
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDireccion.Location = new System.Drawing.Point(15, 181);
            this.lblDireccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(57, 15);
            this.lblDireccion.TabIndex = 7;
            this.lblDireccion.Text = "Direccion";
            // 
            // lblTele
            // 
            this.lblTele.AutoSize = true;
            this.lblTele.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTele.Location = new System.Drawing.Point(15, 212);
            this.lblTele.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTele.Name = "lblTele";
            this.lblTele.Size = new System.Drawing.Size(53, 15);
            this.lblTele.TabIndex = 8;
            this.lblTele.Text = "Telefono";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(15, 240);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(36, 15);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "Email";
            // 
            // lblContra
            // 
            this.lblContra.AutoSize = true;
            this.lblContra.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContra.Location = new System.Drawing.Point(15, 267);
            this.lblContra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblContra.Name = "lblContra";
            this.lblContra.Size = new System.Drawing.Size(67, 15);
            this.lblContra.TabIndex = 10;
            this.lblContra.Text = "Contraseña";
            // 
            // lblContratacion
            // 
            this.lblContratacion.AutoSize = true;
            this.lblContratacion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContratacion.Location = new System.Drawing.Point(14, 292);
            this.lblContratacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblContratacion.Name = "lblContratacion";
            this.lblContratacion.Size = new System.Drawing.Size(74, 30);
            this.lblContratacion.TabIndex = 11;
            this.lblContratacion.Text = "Fecha de\r\ncontratacion";
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartamento.Location = new System.Drawing.Point(15, 335);
            this.lblDepartamento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(83, 15);
            this.lblDepartamento.TabIndex = 12;
            this.lblDepartamento.Text = "Departamento";
            // 
            // lblPuesto
            // 
            this.lblPuesto.AutoSize = true;
            this.lblPuesto.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPuesto.Location = new System.Drawing.Point(14, 377);
            this.lblPuesto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPuesto.Name = "lblPuesto";
            this.lblPuesto.Size = new System.Drawing.Size(43, 15);
            this.lblPuesto.TabIndex = 13;
            this.lblPuesto.Text = "Puesto";
            // 
            // lblworkstation
            // 
            this.lblworkstation.AutoSize = true;
            this.lblworkstation.Location = new System.Drawing.Point(146, 377);
            this.lblworkstation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblworkstation.Name = "lblworkstation";
            this.lblworkstation.Size = new System.Drawing.Size(69, 15);
            this.lblworkstation.TabIndex = 24;
            this.lblworkstation.Text = "workstation";
            // 
            // lbldepart
            // 
            this.lbldepart.AutoSize = true;
            this.lbldepart.Location = new System.Drawing.Point(147, 335);
            this.lbldepart.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldepart.Name = "lbldepart";
            this.lbldepart.Size = new System.Drawing.Size(69, 15);
            this.lbldepart.TabIndex = 23;
            this.lbldepart.Text = "department";
            // 
            // lblhiring
            // 
            this.lblhiring.AutoSize = true;
            this.lblhiring.Location = new System.Drawing.Point(146, 298);
            this.lblhiring.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblhiring.Name = "lblhiring";
            this.lblhiring.Size = new System.Drawing.Size(38, 15);
            this.lblhiring.TabIndex = 22;
            this.lblhiring.Text = "hiring";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(147, 267);
            this.lblpass.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(57, 15);
            this.lblpass.TabIndex = 21;
            this.lblpass.Text = "password";
            // 
            // lblmail
            // 
            this.lblmail.AutoSize = true;
            this.lblmail.Location = new System.Drawing.Point(147, 240);
            this.lblmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmail.Name = "lblmail";
            this.lblmail.Size = new System.Drawing.Size(30, 15);
            this.lblmail.TabIndex = 20;
            this.lblmail.Text = "mail";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Location = new System.Drawing.Point(147, 212);
            this.lblphone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(41, 15);
            this.lblphone.TabIndex = 19;
            this.lblphone.Text = "phone";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(147, 181);
            this.lbladdress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(47, 15);
            this.lbladdress.TabIndex = 18;
            this.lbladdress.Text = "address";
            // 
            // lblbirth
            // 
            this.lblbirth.AutoSize = true;
            this.lblbirth.Location = new System.Drawing.Point(147, 143);
            this.lblbirth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblbirth.Name = "lblbirth";
            this.lblbirth.Size = new System.Drawing.Size(32, 15);
            this.lblbirth.TabIndex = 17;
            this.lblbirth.Text = "birth";
            // 
            // lblnif
            // 
            this.lblnif.AutoSize = true;
            this.lblnif.Location = new System.Drawing.Point(147, 110);
            this.lblnif.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnif.Name = "lblnif";
            this.lblnif.Size = new System.Drawing.Size(21, 15);
            this.lblnif.TabIndex = 16;
            this.lblnif.Text = "nif";
            // 
            // lblsubname
            // 
            this.lblsubname.AutoSize = true;
            this.lblsubname.Location = new System.Drawing.Point(147, 82);
            this.lblsubname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsubname.Name = "lblsubname";
            this.lblsubname.Size = new System.Drawing.Size(56, 15);
            this.lblsubname.TabIndex = 15;
            this.lblsubname.Text = "subname";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(147, 57);
            this.lblname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(37, 15);
            this.lblname.TabIndex = 14;
            this.lblname.Text = "name";
            // 
            // lblIncidencia
            // 
            this.lblIncidencia.AutoSize = true;
            this.lblIncidencia.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIncidencia.ForeColor = System.Drawing.Color.Red;
            this.lblIncidencia.Location = new System.Drawing.Point(15, 453);
            this.lblIncidencia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIncidencia.Name = "lblIncidencia";
            this.lblIncidencia.Size = new System.Drawing.Size(130, 13);
            this.lblIncidencia.TabIndex = 25;
            this.lblIncidencia.Text = "Notificar una Incidencia";
            this.lblIncidencia.Click += new System.EventHandler(this.lblIncidencia_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bttnCancelar);
            this.panel1.Controls.Add(this.bttnEnviar);
            this.panel1.Controls.Add(this.tbIncidencia);
            this.panel1.Controls.Add(this.lblinfoIncidencia);
            this.panel1.Location = new System.Drawing.Point(340, 32);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(565, 473);
            this.panel1.TabIndex = 26;
            this.panel1.Visible = false;
            // 
            // bttnCancelar
            // 
            this.bttnCancelar.Enabled = false;
            this.bttnCancelar.Location = new System.Drawing.Point(368, 440);
            this.bttnCancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bttnCancelar.Name = "bttnCancelar";
            this.bttnCancelar.Size = new System.Drawing.Size(88, 27);
            this.bttnCancelar.TabIndex = 28;
            this.bttnCancelar.Text = "Cancelar";
            this.bttnCancelar.UseVisualStyleBackColor = true;
            this.bttnCancelar.Click += new System.EventHandler(this.bttnCancelar_Click);
            // 
            // bttnEnviar
            // 
            this.bttnEnviar.Location = new System.Drawing.Point(462, 440);
            this.bttnEnviar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bttnEnviar.Name = "bttnEnviar";
            this.bttnEnviar.Size = new System.Drawing.Size(88, 27);
            this.bttnEnviar.TabIndex = 27;
            this.bttnEnviar.Text = "Enviar";
            this.bttnEnviar.UseVisualStyleBackColor = true;
            this.bttnEnviar.Click += new System.EventHandler(this.bttnEnviar_Click);
            // 
            // tbIncidencia
            // 
            this.tbIncidencia.ForeColor = System.Drawing.Color.DimGray;
            this.tbIncidencia.Location = new System.Drawing.Point(19, 50);
            this.tbIncidencia.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbIncidencia.Multiline = true;
            this.tbIncidencia.Name = "tbIncidencia";
            this.tbIncidencia.Size = new System.Drawing.Size(530, 382);
            this.tbIncidencia.TabIndex = 1;
            // 
            // lblinfoIncidencia
            // 
            this.lblinfoIncidencia.AutoSize = true;
            this.lblinfoIncidencia.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinfoIncidencia.Location = new System.Drawing.Point(15, 24);
            this.lblinfoIncidencia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblinfoIncidencia.Name = "lblinfoIncidencia";
            this.lblinfoIncidencia.Size = new System.Drawing.Size(152, 13);
            this.lblinfoIncidencia.TabIndex = 0;
            this.lblinfoIncidencia.Text = "Indique cual es la incidencia";
            // 
            // Ajustes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(933, 519);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblIncidencia);
            this.Controls.Add(this.lblworkstation);
            this.Controls.Add(this.lbldepart);
            this.Controls.Add(this.lblhiring);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lblmail);
            this.Controls.Add(this.lblphone);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblbirth);
            this.Controls.Add(this.lblnif);
            this.Controls.Add(this.lblsubname);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblPuesto);
            this.Controls.Add(this.lblDepartamento);
            this.Controls.Add(this.lblContratacion);
            this.Controls.Add(this.lblContra);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblTele);
            this.Controls.Add(this.lblDireccion);
            this.Controls.Add(this.lblNacimiento);
            this.Controls.Add(this.lblDNI);
            this.Controls.Add(this.lblApe);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblInformacion);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.DimGray;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Ajustes";
            this.Text = "Informacion del Empleado";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label lblInformacion;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblApe;
        private System.Windows.Forms.Label lblDNI;
        private System.Windows.Forms.Label lblNacimiento;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.Label lblTele;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblContra;
        private System.Windows.Forms.Label lblContratacion;
        private System.Windows.Forms.Label lblDepartamento;
        private System.Windows.Forms.Label lblPuesto;
        private System.Windows.Forms.Label lblworkstation;
        private System.Windows.Forms.Label lbldepart;
        private System.Windows.Forms.Label lblhiring;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Label lblmail;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblbirth;
        private System.Windows.Forms.Label lblnif;
        private System.Windows.Forms.Label lblsubname;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblIncidencia;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbIncidencia;
        private System.Windows.Forms.Label lblinfoIncidencia;
        private System.Windows.Forms.Button bttnEnviar;
        private System.Windows.Forms.Button bttnCancelar;
    }
}