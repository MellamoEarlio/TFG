﻿namespace GestorFichajes
{
    partial class AEAusencias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTipo = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblFechaIni = new System.Windows.Forms.Label();
            this.lblFechaFin = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.comboBoxTipo = new System.Windows.Forms.ComboBox();
            this.tbObservaciones = new System.Windows.Forms.TextBox();
            this.lblObservaciones = new System.Windows.Forms.Label();
            this.bttnAñadir = new System.Windows.Forms.Button();
            this.bttnCancelar = new System.Windows.Forms.Button();
            this.checkBoxCertificado = new System.Windows.Forms.CheckBox();
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.lblEmpleado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.BackColor = System.Drawing.Color.Transparent;
            this.lblTipo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.Location = new System.Drawing.Point(30, 27);
            this.lblTipo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(31, 15);
            this.lblTipo.TabIndex = 0;
            this.lblTipo.Text = "Tipo";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(130, 58);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // lblFechaIni
            // 
            this.lblFechaIni.AutoSize = true;
            this.lblFechaIni.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaIni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaIni.Location = new System.Drawing.Point(30, 58);
            this.lblFechaIni.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFechaIni.Name = "lblFechaIni";
            this.lblFechaIni.Size = new System.Drawing.Size(88, 15);
            this.lblFechaIni.TabIndex = 2;
            this.lblFechaIni.Text = "Fecha de inicio";
            // 
            // lblFechaFin
            // 
            this.lblFechaFin.AutoSize = true;
            this.lblFechaFin.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaFin.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaFin.Location = new System.Drawing.Point(30, 93);
            this.lblFechaFin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFechaFin.Name = "lblFechaFin";
            this.lblFechaFin.Size = new System.Drawing.Size(74, 15);
            this.lblFechaFin.TabIndex = 3;
            this.lblFechaFin.Text = "Fecha de fin";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(130, 88);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker2.TabIndex = 4;
            // 
            // comboBoxTipo
            // 
            this.comboBoxTipo.FormattingEnabled = true;
            this.comboBoxTipo.Location = new System.Drawing.Point(130, 27);
            this.comboBoxTipo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBoxTipo.Name = "comboBoxTipo";
            this.comboBoxTipo.Size = new System.Drawing.Size(233, 23);
            this.comboBoxTipo.TabIndex = 6;
            // 
            // tbObservaciones
            // 
            this.tbObservaciones.Location = new System.Drawing.Point(130, 118);
            this.tbObservaciones.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbObservaciones.Name = "tbObservaciones";
            this.tbObservaciones.Size = new System.Drawing.Size(233, 23);
            this.tbObservaciones.TabIndex = 7;
            // 
            // lblObservaciones
            // 
            this.lblObservaciones.AutoSize = true;
            this.lblObservaciones.BackColor = System.Drawing.Color.Transparent;
            this.lblObservaciones.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObservaciones.Location = new System.Drawing.Point(31, 121);
            this.lblObservaciones.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblObservaciones.Name = "lblObservaciones";
            this.lblObservaciones.Size = new System.Drawing.Size(88, 15);
            this.lblObservaciones.TabIndex = 9;
            this.lblObservaciones.Text = "Observaciones";
            // 
            // bttnAñadir
            // 
            this.bttnAñadir.Location = new System.Drawing.Point(275, 174);
            this.bttnAñadir.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bttnAñadir.Name = "bttnAñadir";
            this.bttnAñadir.Size = new System.Drawing.Size(88, 27);
            this.bttnAñadir.TabIndex = 10;
            this.bttnAñadir.Text = "Añadir";
            this.bttnAñadir.UseVisualStyleBackColor = true;
            this.bttnAñadir.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // bttnCancelar
            // 
            this.bttnCancelar.Location = new System.Drawing.Point(130, 174);
            this.bttnCancelar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bttnCancelar.Name = "bttnCancelar";
            this.bttnCancelar.Size = new System.Drawing.Size(88, 27);
            this.bttnCancelar.TabIndex = 11;
            this.bttnCancelar.Text = "Cancelar";
            this.bttnCancelar.UseVisualStyleBackColor = true;
            this.bttnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // checkBoxCertificado
            // 
            this.checkBoxCertificado.AutoSize = true;
            this.checkBoxCertificado.BackColor = System.Drawing.Color.Transparent;
            this.checkBoxCertificado.Location = new System.Drawing.Point(182, 148);
            this.checkBoxCertificado.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.checkBoxCertificado.Name = "checkBoxCertificado";
            this.checkBoxCertificado.Size = new System.Drawing.Size(94, 19);
            this.checkBoxCertificado.TabIndex = 12;
            this.checkBoxCertificado.Text = "¿Certificado?";
            this.checkBoxCertificado.UseVisualStyleBackColor = false;
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Location = new System.Drawing.Point(8, 60);
            this.lblDepartamento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(0, 15);
            this.lblDepartamento.TabIndex = 13;
            // 
            // lblEmpleado
            // 
            this.lblEmpleado.AutoSize = true;
            this.lblEmpleado.Location = new System.Drawing.Point(8, 30);
            this.lblEmpleado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpleado.Name = "lblEmpleado";
            this.lblEmpleado.Size = new System.Drawing.Size(0, 15);
            this.lblEmpleado.TabIndex = 14;
            // 
            // AEAusencias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GestorFichajes.Properties.Resources.VeniceAI_fV6KlWo;
            this.ClientSize = new System.Drawing.Size(428, 235);
            this.Controls.Add(this.lblEmpleado);
            this.Controls.Add(this.lblDepartamento);
            this.Controls.Add(this.checkBoxCertificado);
            this.Controls.Add(this.bttnCancelar);
            this.Controls.Add(this.bttnAñadir);
            this.Controls.Add(this.lblObservaciones);
            this.Controls.Add(this.tbObservaciones);
            this.Controls.Add(this.comboBoxTipo);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.lblFechaFin);
            this.Controls.Add(this.lblFechaIni);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblTipo);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "AEAusencias";
            this.Text = "AEAusencias";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblFechaIni;
        private System.Windows.Forms.Label lblFechaFin;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.ComboBox comboBoxTipo;
        private System.Windows.Forms.TextBox tbObservaciones;
        private System.Windows.Forms.Label lblObservaciones;
        private System.Windows.Forms.Button bttnAñadir;
        private System.Windows.Forms.Button bttnCancelar;
        private System.Windows.Forms.CheckBox checkBoxCertificado;
        private System.Windows.Forms.Label lblDepartamento;
        private System.Windows.Forms.Label lblEmpleado;
    }
}