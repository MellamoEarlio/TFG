﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class AEPuesto : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        // ID del puesto, puede ser nulo
        private readonly int? idPuesto;

        // Constructor de la clase AEPuesto
        public AEPuesto(int? id = null, string nombre = "", string descripcion = "", string salario = "")
        {
            InitializeComponent();
            idPuesto = id;
            // Inicializar los controles con los valores proporcionados
            tbNombre.Text = nombre;
            tbDescripcion.Text = descripcion;
            tbSalario.Text = salario;
        }

        // Manejar el evento de clic del botón Aceptar
        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            // Validar que los campos obligatorios no estén vacíos
            if (string.IsNullOrWhiteSpace(tbNombre.Text) || string.IsNullOrWhiteSpace(tbSalario.Text))
            {
                MessageBox.Show("Nombre y salario son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd;

                if (idPuesto.HasValue)
                {
                    // Modo edición: actualizar el registro existente
                    cmd = new SqlCommand(@"UPDATE PUESTO SET Nombre_Puesto = @nombre, Descripcion = @desc, Salario_Base = @salario WHERE ID_Puesto = @id", conn);
                    cmd.Parameters.AddWithValue("@id", idPuesto.Value);
                }
                else
                {
                    // Modo alta: insertar un nuevo registro
                    cmd = new SqlCommand(@"INSERT INTO PUESTO (Nombre_Puesto, Descripcion, Salario_Base) VALUES (@nombre, @desc, @salario)", conn);
                }

                // Añadir parámetros a la consulta
                cmd.Parameters.AddWithValue("@nombre", tbNombre.Text.Trim());
                cmd.Parameters.AddWithValue("@desc", tbDescripcion.Text.Trim());
                cmd.Parameters.AddWithValue("@salario", decimal.Parse(tbSalario.Text.Trim()));

                // Ejecutar la consulta y verificar si se realizó correctamente
                if (cmd.ExecuteNonQuery() > 0)
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Error al guardar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Manejar el evento de clic del botón Cancelar
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}