﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Ajustes : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        private int idEmpleado;

        // Constructor de la clase Ajustes
        public Ajustes(int empleadoId)
        {
            InitializeComponent();
            this.idEmpleado = empleadoId;
            CargarDatosEmpleado();
        }

        // Método que se ejecuta cuando el formulario se carga
        private void Ajustes_Load(object sender, EventArgs e)
        {
            // No es necesario cargar datos aquí ya que se hace en el constructor
        }

        // Método para cargar los datos del empleado desde la base de datos
        private void CargarDatosEmpleado()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"
                        SELECT
                            e.Nombre, e.Apellidos, e.DNI_NIF, e.Fecha_Nacimiento,
                            e.Direccion, e.Telefono, e.Email, e.Contrasenia,
                            e.Fecha_Contratacion, d.Nombre AS Departamento,
                            p.Nombre_Puesto AS Puesto
                        FROM EMPLEADO e
                        LEFT JOIN DEPARTAMENTO d ON e.ID_Departamento = d.ID_Departamento
                        LEFT JOIN PUESTO p ON e.ID_Puesto = p.ID_Puesto
                        WHERE e.ID_Empleado = @idEmpleado";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@idEmpleado", idEmpleado);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Asignar directamente a los labels sin usar propiedades estáticas
                                lblname.Text = reader["Nombre"].ToString();
                                lblsubname.Text = reader["Apellidos"].ToString();
                                lblnif.Text = reader["DNI_NIF"].ToString();
                                lblbirth.Text = Convert.ToDateTime(reader["Fecha_Nacimiento"]).ToString("dd/MM/yyyy");
                                lbladdress.Text = reader["Direccion"].ToString();
                                lblphone.Text = reader["Telefono"].ToString();
                                lblmail.Text = reader["Email"].ToString();
                                lblpass.Text = reader["Contrasenia"].ToString();
                                lblhiring.Text = Convert.ToDateTime(reader["Fecha_Contratacion"]).ToString("dd/MM/yyyy");
                                lbldepart.Text = reader["Departamento"] != DBNull.Value ? reader["Departamento"].ToString() : "No asignado";
                                lblworkstation.Text = reader["Puesto"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("No se encontraron datos del empleado.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos del empleado: {ex.Message}");
            }
        }

        // Método para manejar el evento de clic del label de incidencia
        private void lblIncidencia_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        // Método para manejar el evento de clic del botón de enviar incidencia
        private void bttnEnviar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbIncidencia.Text))
            {
                MessageBox.Show("Por favor, describe la incidencia antes de enviar.");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"
                        INSERT INTO INCIDENCIA
                        (ID_Empleado, Tipo, Descripcion, Fecha, Resuelta)
                        VALUES
                        (@idEmpleado, @tipo, @descripcion, @fecha, @resuelta)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                        cmd.Parameters.AddWithValue("@tipo", "Otro");
                        cmd.Parameters.AddWithValue("@descripcion", tbIncidencia.Text);
                        cmd.Parameters.AddWithValue("@fecha", DateTime.Now);
                        cmd.Parameters.AddWithValue("@resuelta", false);

                        int result = cmd.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Incidencia enviada correctamente.");
                            tbIncidencia.Text = "";
                            panel1.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al registrar la incidencia: {ex.Message}");
            }
        }

        // Método para manejar el evento de clic del botón de cancelar incidencia
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarFormularioIncidencia();
            panel1.Visible = false;
        }

        // Método para limpiar el formulario de incidencia
        private void LimpiarFormularioIncidencia()
        {
            tbIncidencia.Text = "";
            panel1.Visible = false;
            bttnCancelar.Enabled = false;
        }
    }
}