﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class AEDepartamento : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Variables para almacenar el ID del departamento y el modo de operación (edición o nuevo)
        private int? idDepartamento;
        private bool esEdicion;

        // Evento para notificar cuando se actualizan los datos
        public event EventHandler DatosGuardados;

        // Constructor para añadir nuevo departamento
        public AEDepartamento()
        {
            InitializeComponent();
            esEdicion = false;
            Text = "Añadir Nuevo Departamento";
            CargarResponsables();
        }

        // Constructor para editar departamento existente
        public AEDepartamento(int idDepartamento, string nombre, string descripcion, int? idResponsable)
        {
            InitializeComponent();
            this.idDepartamento = idDepartamento;
            esEdicion = true;
            Text = "Editar Departamento";

            // Rellenar los controles con los datos recibidos
            tbNombre.Text = nombre;
            tbDescripcion.Text = descripcion;
            CargarResponsables(idResponsable);
        }

        // Método para cargar los responsables en el ComboBox
        private void CargarResponsables(int? idResponsableSeleccionado = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                    SELECT ID_Empleado, Nombre + ' ' + Apellidos AS NombreCompleto
                    FROM EMPLEADO
                    ORDER BY Nombre, Apellidos";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        // Agregar opción "Sin responsable"
                        DataRow row = dt.NewRow();
                        row["ID_Empleado"] = DBNull.Value;
                        row["NombreCompleto"] = "Sin responsable";
                        dt.Rows.InsertAt(row, 0);

                        // Configurar el ComboBox con los datos cargados
                        comboBoxResponsable.DataSource = dt;
                        comboBoxResponsable.DisplayMember = "NombreCompleto";
                        comboBoxResponsable.ValueMember = "ID_Empleado";

                        // Seleccionar el responsable si se está editando
                        if (idResponsableSeleccionado.HasValue)
                        {
                            comboBoxResponsable.SelectedValue = idResponsableSeleccionado.Value;
                        }
                        else if (comboBoxResponsable.Items.Count > 0)
                        {
                            comboBoxResponsable.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los responsables: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del botón Aceptar
        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            // Validar que el nombre del departamento no esté vacío
            if (string.IsNullOrWhiteSpace(tbNombre.Text))
            {
                MessageBox.Show("El nombre del departamento es obligatorio.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    if (esEdicion)
                    {
                        // Actualizar departamento existente
                        string query = @"
                        UPDATE DEPARTAMENTO
                        SET Nombre = @Nombre,
                            Descripcion = @Descripcion,
                            ID_Responsable = @ID_Responsable
                        WHERE ID_Departamento = @ID_Departamento";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ID_Departamento", idDepartamento);
                            command.Parameters.AddWithValue("@Nombre", tbNombre.Text.Trim());
                            command.Parameters.AddWithValue("@Descripcion",
                                string.IsNullOrWhiteSpace(tbDescripcion.Text) ? DBNull.Value : (object)tbDescripcion.Text.Trim());

                            object responsableValue = (comboBoxResponsable.SelectedValue == null ||
                                                     comboBoxResponsable.SelectedValue == DBNull.Value) ?
                                                     DBNull.Value : comboBoxResponsable.SelectedValue;
                            command.Parameters.AddWithValue("@ID_Responsable", responsableValue);

                            command.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // Insertar nuevo departamento
                        string query = @"
                        INSERT INTO DEPARTAMENTO (Nombre, Descripcion, ID_Responsable)
                        VALUES (@Nombre, @Descripcion, @ID_Responsable)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Nombre", tbNombre.Text.Trim());
                            command.Parameters.AddWithValue("@Descripcion",
                                string.IsNullOrWhiteSpace(tbDescripcion.Text) ? DBNull.Value : (object)tbDescripcion.Text.Trim());

                            object responsableValue = (comboBoxResponsable.SelectedValue == null ||
                                                     comboBoxResponsable.SelectedValue == DBNull.Value) ?
                                                     DBNull.Value : comboBoxResponsable.SelectedValue;
                            command.Parameters.AddWithValue("@ID_Responsable", responsableValue);

                            command.ExecuteNonQuery();
                        }
                    }

                    // Disparar el evento para notificar que se guardaron los datos
                    DatosGuardados?.Invoke(this, EventArgs.Empty);

                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar el departamento: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del botón Cancelar
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}