﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GestorFichajes
{
    public partial class Main : Form
    {
        // Declaración de variables privadas para almacenar datos del empleado y el estado de la jornada
        private int idEmpleado;
        private int puestoEmpleado;
        private Timer timer;
        private Timer inactividadTimer;
        private DateTime entradaEsperada;
        private DateTime entradaReal;
        private DateTime salidaEsperada;
        private TimeSpan tiempoTrabajado = TimeSpan.Zero;
        private TimeSpan tiempoInactivo = TimeSpan.Zero;
        private TimeSpan retraso = TimeSpan.Zero;
        private int cantidadPausas = 0;
        private bool isRunning = false;
        private bool isInactive = false;
        private DateTime startTime;
        private DateTime pausaInicio;
        private bool primeraVez = true;
        private string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Diccionario para traducir los días de la semana al español
        private static readonly Dictionary<string, string> DiasTraduccion = new Dictionary<string, string>
        {
            {"Sunday", "Domingo"},
            {"Monday", "Lunes"},
            {"Tuesday", "Martes"},
            {"Wednesday", "Miércoles"},
            {"Thursday", "Jueves"},
            {"Friday", "Viernes"},
            {"Saturday", "Sábado"}
        };

        // Constructor de la clase Main
        public Main(string nombreEmpleado, int idEmpleado, int puestoEmpleado)
        {
            InitializeComponent();
            this.idEmpleado = idEmpleado;
            this.puestoEmpleado = puestoEmpleado;
            CargarHorarioEmpleado();

            // Configuración de los timers
            timer = new Timer { Interval = 1000 };
            timer.Tick += timer1_Tick;

            inactividadTimer = new Timer { Interval = 30000 };
            inactividadTimer.Tick += VerificarInactividad;

            // Configuración de la interfaz de usuario
            lbl_empleado.Text = nombreEmpleado;
            lbl_empleado.ForeColor = puestoEmpleado == 1 ? Color.Purple : Color.Black;
        }

        // Método para cargar el horario del empleado desde la base de datos
        private void CargarHorarioEmpleado()
        {
            try
            {
                string diaSemana = DateTime.Now.DayOfWeek.ToString();

                // Usar diccionario para la traducción del día de la semana
                if (DiasTraduccion.TryGetValue(diaSemana, out string diaTraducido))
                {
                    diaSemana = diaTraducido;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Hora_Entrada, Hora_Salida FROM HORARIO WHERE ID_Empleado = @idEmpleado AND Dia_Semana = @diaSemana";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                        command.Parameters.AddWithValue("@diaSemana", diaSemana);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                TimeSpan horaEntrada = (TimeSpan)reader["Hora_Entrada"];
                                TimeSpan horaSalida = (TimeSpan)reader["Hora_Salida"];

                                entradaEsperada = DateTime.Today.Add(horaEntrada);
                                salidaEsperada = DateTime.Today.Add(horaSalida);

                                lblHorario.Text = $"Horario: {horaEntrada.ToString(@"hh\:mm")} - {horaSalida.ToString(@"hh\:mm")}";
                            }
                            else
                            {
                                entradaEsperada = DateTime.Today.AddHours(9);
                                salidaEsperada = DateTime.Today.AddHours(17);
                                lblHorario.Text = "Horario: 09:00 - 17:00 (por defecto)";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar el horario: {ex.Message}");
                entradaEsperada = DateTime.Today.AddHours(9);
                salidaEsperada = DateTime.Today.AddHours(17);
                lblHorario.Text = "Horario: 09:00 - 17:00 (por defecto)";
            }
        }

        // Método para manejar el cierre del formulario
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            timer?.Stop();
            inactividadTimer?.Stop();
        }

        // Método para manejar el evento de clic del botón de inicio/pausa
        private void bttnStart_Click(object sender, EventArgs e)
        {
            bttnStart.Text = "En marcha";
            if (isRunning)
            {
                PausarTrabajo();
            }
            else
            {
                ReanudarTrabajo();
            }
        }

        // Método para pausar el trabajo
        private void PausarTrabajo()
        {
            tiempoTrabajado += DateTime.Now - startTime;
            pausaInicio = DateTime.Now;
            timer.Stop();
            inactividadTimer.Stop();
            cantidadPausas++;
            bttnStart.ForeColor = Color.Black;
            bttnStart.BackColor = Color.Yellow;
            bttnStart.Text = $"Pausado ({cantidadPausas} paradas)";
            isRunning = false;
        }

        // Método para reanudar el trabajo
        private void ReanudarTrabajo()
        {
            if (primeraVez)
            {
                IniciarNuevaJornada();
            }

            if (pausaInicio != DateTime.MinValue)
            {
                tiempoInactivo += DateTime.Now - pausaInicio;
            }

            startTime = DateTime.Now;
            timer.Start();
            inactividadTimer.Start();
            bttnStart.BackColor = Color.Green;
            bttnStart.ForeColor = Color.White;
            bttnStart.Text = "En marcha";
            isRunning = true;
            isInactive = false;
        }

        // Método para iniciar una nueva jornada laboral
        private void IniciarNuevaJornada()
        {
            entradaReal = DateTime.Now;
            salidaEsperada = entradaReal.Add(salidaEsperada.TimeOfDay - entradaEsperada.TimeOfDay);
            primeraVez = false;

            if (entradaReal > entradaEsperada)
            {
                retraso = entradaReal - entradaEsperada;
                lblRetraso.Text = $"Retraso: {retraso.Hours}h {retraso.Minutes}m {retraso.Seconds}s";
                lblRetraso.ForeColor = Color.Red;
            }
            else
            {
                lblRetraso.Text = "Sin retraso";
                lblRetraso.ForeColor = Color.Green;
            }

            RegistrarFichajeEntrada();
        }

        // Método para registrar el fichaje de entrada en la base de datos
        private void RegistrarFichajeEntrada()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"INSERT INTO FICHAJE
                                   (ID_Empleado, Fecha_Hora_Entrada, Tipo_Fichaje,
                                    Metodo_Fichaje, Ubicacion_Fichaje, Estado)
                                   VALUES
                                   (@idEmpleado, @fechaEntrada, 'Entrada',
                                    'App', 'Oficina', @estado)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                        command.Parameters.AddWithValue("@fechaEntrada", entradaReal);
                        command.Parameters.AddWithValue("@estado", retraso.TotalMinutes > 15 ? "Retraso" : "Normal");
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al registrar el fichaje de entrada: {ex.Message}");
            }
        }

        // Método que se ejecuta cada segundo para actualizar los tiempos y verificar el fin de la jornada
        private void timer1_Tick(object sender, EventArgs e)
        {
            ActualizarTiempos();
            VerificarFinJornada();
        }

        // Método para actualizar los tiempos de trabajo e inactividad en la interfaz de usuario
        private void ActualizarTiempos()
        {
            TimeSpan tiempoTranscurrido = DateTime.Now - entradaReal;
            lblTiempo.Text = $"Tiempo trabajado: {tiempoTranscurrido.Hours}h {tiempoTranscurrido.Minutes}m {tiempoTranscurrido.Seconds}s";
            lblInactivo.Text = $"Tiempo inactivo: {tiempoInactivo.Hours}h {tiempoInactivo.Minutes}m {tiempoInactivo.Seconds}s";
        }

        // Método para verificar si ha llegado el momento de finalizar la jornada
        private void VerificarFinJornada()
        {
            if (DateTime.Now >= salidaEsperada)
            {
                FinalizarJornada();
            }
        }

        // Método para finalizar la jornada laboral
        private void FinalizarJornada()
        {
            timer.Stop();
            inactividadTimer.Stop();
            bttnStart.BackColor = Color.Red;
            bttnStart.Text = "Jornada Finalizada";
            isRunning = false;
            RegistrarFichajeSalida();

            MessageBox.Show($"Jornada finalizada.\nPausas: {cantidadPausas}.\nInactividad: {tiempoInactivo.Hours}h {tiempoInactivo.Minutes}m {tiempoInactivo.Seconds}s.");
            bttnStart.Enabled = false;
        }

        // Método para registrar el fichaje de salida en la base de datos
        private void RegistrarFichajeSalida()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"UPDATE FICHAJE
                                   SET Fecha_Hora_Salida = @fechaSalida,
                                       Estado = @estado
                                   WHERE ID_Empleado = @idEmpleado
                                   AND CONVERT(DATE, Fecha_Hora_Entrada) = CONVERT(DATE, @fechaEntrada)
                                   AND Fecha_Hora_Salida IS NULL";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@fechaSalida", DateTime.Now);
                        command.Parameters.AddWithValue("@estado", retraso.TotalMinutes > 15 ? "Retraso" : "Normal");
                        command.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                        command.Parameters.AddWithValue("@fechaEntrada", entradaReal);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            RegistrarFichajeCompleto();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al registrar el fichaje de salida: {ex.Message}");
            }
        }

        // Método para registrar un fichaje completo (entrada y salida) en la base de datos
        private void RegistrarFichajeCompleto()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"INSERT INTO FICHAJE
                               (ID_Empleado, Fecha_Hora_Entrada, Fecha_Hora_Salida,
                                Tipo_Fichaje, Metodo_Fichaje, Ubicacion_Fichaje, Estado)
                               VALUES
                               (@idEmpleado, @fechaEntrada, @fechaSalida,
                                'Salida', 'App', 'Oficina', @estado)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                    command.Parameters.AddWithValue("@fechaEntrada", entradaReal);
                    command.Parameters.AddWithValue("@fechaSalida", DateTime.Now);
                    command.Parameters.AddWithValue("@estado", retraso.TotalMinutes > 15 ? "Retraso" : "Normal");
                    command.ExecuteNonQuery();
                }
            }
        }

        // Método para verificar la inactividad del usuario
        private void VerificarInactividad(object sender, EventArgs e)
        {
            if (EsUsuarioInactivo() && isRunning)
            {
                tiempoInactivo += TimeSpan.FromSeconds(30);
                lblInactivo.Text = $"Tiempo inactivo: {tiempoInactivo.Hours}h {tiempoInactivo.Minutes}m {tiempoInactivo.Seconds}s";

                if (!isInactive)
                {
                    timer.Stop();
                    isInactive = true;
                    MessageBox.Show("Modo inactivo activado por falta de movimiento.");
                }
            }
            else if (!EsUsuarioInactivo() && isInactive)
            {
                timer.Start();
                isInactive = false;
                MessageBox.Show("Modo inactivo desactivado por detección de actividad.");
            }
        }

        // Método para determinar si el usuario ha estado inactivo
        private bool EsUsuarioInactivo()
        {
            LASTINPUTINFO lii = new LASTINPUTINFO();
            lii.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
            return GetLastInputInfo(ref lii) && ((Environment.TickCount - lii.dwTime) / 1000) >= 30;
        }

        // Estructura para obtener la última actividad del usuario
        [StructLayout(LayoutKind.Sequential)]
        private struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        // Método para obtener la última actividad del usuario
        [DllImport("user32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        // Método para manejar el evento de clic del botón de usuario
        private void bttnUser_Click(object sender, EventArgs e)
        {
            if (puestoEmpleado == 1) // Si el ID_Puesto es 1, se abre Gestor_de_la_APP
            {
                // Pasar el idEmpleado al constructor
                Gestor_de_la_APP gestor = new Gestor_de_la_APP(idEmpleado);
                gestor.ShowDialog();
            }
            else // Si el puesto es otro, se abre Ajustes
            {
                // Pasar el idEmpleado al constructor
                Ajustes ajustes = new Ajustes(idEmpleado);
                ajustes.ShowDialog();
            }
        }

        // Método para manejar el evento de clic del botón de salida
        private void bttnSalir_Click(object sender, EventArgs e)
        {
            // Buscar y cerrar todos los procesos llamados "GestionFichajes"
            foreach (var proceso in System.Diagnostics.Process.GetProcessesByName("GestorFichajes"))
            {
                try
                {
                    proceso.Kill();
                    proceso.WaitForExit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo cerrar el proceso GestionFichajes.exe: " + ex.Message);
                }
            }

            this.Close();
        }

        // Método para manejar el evento de clic del enlace de ausencias
        private void lblAAusencias_Click(object sender, EventArgs e)
        {
            if (idEmpleado > 0) // Asegurarse que hay un empleado seleccionado
            {
                AEAusencias ausencias = new AEAusencias(idEmpleado);
                if (ausencias.ShowDialog() == DialogResult.OK)
                {
                    // Opcional: Actualizar la vista si es necesario
                    MessageBox.Show("Ausencia registrada con éxito", "Información",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Seleccione un empleado primero", "Advertencia",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}