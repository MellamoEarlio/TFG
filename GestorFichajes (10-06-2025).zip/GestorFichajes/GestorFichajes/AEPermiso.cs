﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class AEPermiso : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        // ID del permiso, puede ser nulo
        private readonly int? idPermiso;

        // Constructor de la clase AEPermiso
        public AEPermiso(int? id = null, DateTime? fecha = null, string motivo = "", string estado = "")
        {
            InitializeComponent();
            idPermiso = id;

            // Cargar empleados en el ComboBox
            CargarEmpleados();

            // Añadir opciones al ComboBox de estado
            comboBoxEstado.Items.AddRange(new string[] { "Pendiente", "Aprobado", "Rechazado" });
            comboBoxEstado.SelectedIndex = 0;

            // Asignar valores a los controles si se proporcionan
            if (fecha.HasValue) dTPFecha.Value = fecha.Value;
            tbMotivo.Text = motivo;
            if (!string.IsNullOrWhiteSpace(estado)) comboBoxEstado.Text = estado;
        }

        // Método para cargar empleados en el ComboBox
        private void CargarEmpleados()
        {
            comboBoxEmpleado.Items.Clear();

            // Conectar a la base de datos y ejecutar la consulta
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Empleado, Nombre + ' ' + Apellidos AS NombreCompleto FROM EMPLEADO";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                // Leer los resultados y añadir a ComboBoxItem
                while (reader.Read())
                {
                    comboBoxEmpleado.Items.Add(new ComboBoxItem
                    {
                        Text = reader["NombreCompleto"].ToString(),
                        Value = (int)reader["ID_Empleado"]
                    });
                }
            }

            // Seleccionar el primer empleado por defecto
            if (comboBoxEmpleado.Items.Count > 0)
                comboBoxEmpleado.SelectedIndex = 0;
        }

        // Manejar el evento de clic del botón Aceptar
        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            // Validar que el campo de motivo no esté vacío
            if (string.IsNullOrWhiteSpace(tbMotivo.Text))
            {
                MessageBox.Show("El motivo no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Verificar que el empleado esté seleccionado correctamente
            if (!(comboBoxEmpleado.SelectedItem is ComboBoxItem item))
            {
                MessageBox.Show("Debes seleccionar un empleado válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Convertir la hora del DateTimePicker a formato decimal
            decimal horas = (decimal)dTPFecha.Value.TimeOfDay.TotalHours;

            // Validar el estado seleccionado
            string estado = comboBoxEstado.Text.Trim();
            if (estado != "Pendiente" && estado != "Aprobado" && estado != "Rechazado")
            {
                MessageBox.Show("Valor de estado no válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Conectar a la base de datos y ejecutar la consulta de inserción o actualización
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd;

                // Si idPermiso tiene un valor, realizar una actualización; de lo contrario, realizar una inserción
                if (idPermiso.HasValue)
                {
                    cmd = new SqlCommand(@"UPDATE PERMISO SET
                                    ID_Empleado = @idEmpleado,
                                    Fecha = @fecha,
                                    Horas = @horas,
                                    Motivo = @motivo,
                                    Estado = @estado
                                    WHERE ID_Permiso = @id", conn);
                    cmd.Parameters.AddWithValue("@id", idPermiso.Value);
                }
                else
                {
                    cmd = new SqlCommand(@"INSERT INTO PERMISO
                                  (ID_Empleado, Fecha, Horas, Motivo, Estado)
                                  VALUES (@idEmpleado, @fecha, @horas, @motivo, @estado)", conn);
                }

                // Añadir parámetros a la consulta
                cmd.Parameters.AddWithValue("@idEmpleado", item.Value);
                cmd.Parameters.AddWithValue("@fecha", dTPFecha.Value);
                cmd.Parameters.AddWithValue("@horas", horas);
                cmd.Parameters.AddWithValue("@motivo", tbMotivo.Text.Trim());
                cmd.Parameters.AddWithValue("@estado", estado);

                // Ejecutar la consulta y verificar si se realizó correctamente
                if (cmd.ExecuteNonQuery() > 0)
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Error al guardar el permiso.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Manejar el evento de clic del botón Cancelar
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        // Clase interna para representar un elemento del ComboBox
        private class ComboBoxItem
        {
            public string Text { get; set; }
            public int Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }
    }
}