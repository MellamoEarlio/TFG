﻿namespace GestorFichajes
{
    partial class EditarFichaje
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFHEntrada = new System.Windows.Forms.Label();
            this.lblFHSalida = new System.Windows.Forms.Label();
            this.lblTipoFichaje = new System.Windows.Forms.Label();
            this.lblMetodoFichaje = new System.Windows.Forms.Label();
            this.lblUbiFichaje = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.comboBoxEstado = new System.Windows.Forms.ComboBox();
            this.comboBoxMetodo = new System.Windows.Forms.ComboBox();
            this.comboBoxTipo = new System.Windows.Forms.ComboBox();
            this.dTPSalida = new System.Windows.Forms.DateTimePicker();
            this.dTPEntrada = new System.Windows.Forms.DateTimePicker();
            this.bttnAceptar = new System.Windows.Forms.Button();
            this.bttnCancelar = new System.Windows.Forms.Button();
            this.tbUbi = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblFHEntrada
            // 
            this.lblFHEntrada.AutoSize = true;
            this.lblFHEntrada.Location = new System.Drawing.Point(12, 55);
            this.lblFHEntrada.Name = "lblFHEntrada";
            this.lblFHEntrada.Size = new System.Drawing.Size(111, 13);
            this.lblFHEntrada.TabIndex = 1;
            this.lblFHEntrada.Text = "Fecha y Hora Entrada";
            // 
            // lblFHSalida
            // 
            this.lblFHSalida.AutoSize = true;
            this.lblFHSalida.Location = new System.Drawing.Point(12, 83);
            this.lblFHSalida.Name = "lblFHSalida";
            this.lblFHSalida.Size = new System.Drawing.Size(103, 13);
            this.lblFHSalida.TabIndex = 2;
            this.lblFHSalida.Text = "Fecha y Hora Salida";
            // 
            // lblTipoFichaje
            // 
            this.lblTipoFichaje.AutoSize = true;
            this.lblTipoFichaje.Location = new System.Drawing.Point(12, 109);
            this.lblTipoFichaje.Name = "lblTipoFichaje";
            this.lblTipoFichaje.Size = new System.Drawing.Size(80, 13);
            this.lblTipoFichaje.TabIndex = 3;
            this.lblTipoFichaje.Text = "Tipo de Fichaje";
            // 
            // lblMetodoFichaje
            // 
            this.lblMetodoFichaje.AutoSize = true;
            this.lblMetodoFichaje.Location = new System.Drawing.Point(12, 137);
            this.lblMetodoFichaje.Name = "lblMetodoFichaje";
            this.lblMetodoFichaje.Size = new System.Drawing.Size(95, 13);
            this.lblMetodoFichaje.TabIndex = 4;
            this.lblMetodoFichaje.Text = "Metodo de Fichaje";
            // 
            // lblUbiFichaje
            // 
            this.lblUbiFichaje.AutoSize = true;
            this.lblUbiFichaje.Location = new System.Drawing.Point(12, 166);
            this.lblUbiFichaje.Name = "lblUbiFichaje";
            this.lblUbiFichaje.Size = new System.Drawing.Size(107, 13);
            this.lblUbiFichaje.TabIndex = 5;
            this.lblUbiFichaje.Text = "Ubicacion de Fichaje";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(12, 193);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(40, 13);
            this.lblEstado.TabIndex = 6;
            this.lblEstado.Text = "Estado";
            // 
            // comboBoxEstado
            // 
            this.comboBoxEstado.FormattingEnabled = true;
            this.comboBoxEstado.Location = new System.Drawing.Point(137, 190);
            this.comboBoxEstado.Name = "comboBoxEstado";
            this.comboBoxEstado.Size = new System.Drawing.Size(200, 21);
            this.comboBoxEstado.TabIndex = 7;
            // 
            // comboBoxMetodo
            // 
            this.comboBoxMetodo.FormattingEnabled = true;
            this.comboBoxMetodo.Location = new System.Drawing.Point(137, 133);
            this.comboBoxMetodo.Name = "comboBoxMetodo";
            this.comboBoxMetodo.Size = new System.Drawing.Size(200, 21);
            this.comboBoxMetodo.TabIndex = 9;
            // 
            // comboBoxTipo
            // 
            this.comboBoxTipo.FormattingEnabled = true;
            this.comboBoxTipo.Location = new System.Drawing.Point(137, 106);
            this.comboBoxTipo.Name = "comboBoxTipo";
            this.comboBoxTipo.Size = new System.Drawing.Size(200, 21);
            this.comboBoxTipo.TabIndex = 10;
            // 
            // dTPSalida
            // 
            this.dTPSalida.Location = new System.Drawing.Point(137, 80);
            this.dTPSalida.Name = "dTPSalida";
            this.dTPSalida.Size = new System.Drawing.Size(200, 20);
            this.dTPSalida.TabIndex = 11;
            // 
            // dTPEntrada
            // 
            this.dTPEntrada.Location = new System.Drawing.Point(137, 54);
            this.dTPEntrada.Name = "dTPEntrada";
            this.dTPEntrada.Size = new System.Drawing.Size(200, 20);
            this.dTPEntrada.TabIndex = 12;
            // 
            // bttnAceptar
            // 
            this.bttnAceptar.Location = new System.Drawing.Point(261, 235);
            this.bttnAceptar.Name = "bttnAceptar";
            this.bttnAceptar.Size = new System.Drawing.Size(75, 23);
            this.bttnAceptar.TabIndex = 13;
            this.bttnAceptar.Text = "Aceptar";
            this.bttnAceptar.UseVisualStyleBackColor = true;
            this.bttnAceptar.Click += new System.EventHandler(this.bttnAceptar_Click);
            // 
            // bttnCancelar
            // 
            this.bttnCancelar.Location = new System.Drawing.Point(137, 235);
            this.bttnCancelar.Name = "bttnCancelar";
            this.bttnCancelar.Size = new System.Drawing.Size(75, 23);
            this.bttnCancelar.TabIndex = 14;
            this.bttnCancelar.Text = "Cancelar";
            this.bttnCancelar.UseVisualStyleBackColor = true;
            this.bttnCancelar.Click += new System.EventHandler(this.bttnCancelar_Click);
            // 
            // tbUbi
            // 
            this.tbUbi.Location = new System.Drawing.Point(137, 161);
            this.tbUbi.Name = "tbUbi";
            this.tbUbi.Size = new System.Drawing.Size(200, 20);
            this.tbUbi.TabIndex = 15;
            // 
            // EditarFichaje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbUbi);
            this.Controls.Add(this.bttnCancelar);
            this.Controls.Add(this.bttnAceptar);
            this.Controls.Add(this.dTPEntrada);
            this.Controls.Add(this.dTPSalida);
            this.Controls.Add(this.comboBoxTipo);
            this.Controls.Add(this.comboBoxMetodo);
            this.Controls.Add(this.comboBoxEstado);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblUbiFichaje);
            this.Controls.Add(this.lblMetodoFichaje);
            this.Controls.Add(this.lblTipoFichaje);
            this.Controls.Add(this.lblFHSalida);
            this.Controls.Add(this.lblFHEntrada);
            this.Name = "EditarFichaje";
            this.Text = "EditarFichaje";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblFHEntrada;
        private System.Windows.Forms.Label lblFHSalida;
        private System.Windows.Forms.Label lblTipoFichaje;
        private System.Windows.Forms.Label lblMetodoFichaje;
        private System.Windows.Forms.Label lblUbiFichaje;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.ComboBox comboBoxEstado;
        private System.Windows.Forms.ComboBox comboBoxMetodo;
        private System.Windows.Forms.ComboBox comboBoxTipo;
        private System.Windows.Forms.DateTimePicker dTPSalida;
        private System.Windows.Forms.DateTimePicker dTPEntrada;
        private System.Windows.Forms.Button bttnAceptar;
        private System.Windows.Forms.Button bttnCancelar;
        private System.Windows.Forms.TextBox tbUbi;
    }
}