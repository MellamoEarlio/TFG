﻿namespace GestorFichajes
{
    partial class Fichajes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvFichaje = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ID_Fichaje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Empleado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre_Empleado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fecha_Hora_Entrada = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fecha_Hora_Salida = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tipo_Fichaje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Metodo_Fichaje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ubicacion_Fichaje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFichaje)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvFichaje
            // 
            this.dgvFichaje.BackgroundColor = System.Drawing.Color.White;
            this.dgvFichaje.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFichaje.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFichaje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFichaje.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_Fichaje,
            this.ID_Empleado,
            this.Nombre_Empleado,
            this.Fecha_Hora_Entrada,
            this.Fecha_Hora_Salida,
            this.Tipo_Fichaje,
            this.Metodo_Fichaje,
            this.Ubicacion_Fichaje,
            this.Estado});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFichaje.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvFichaje.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFichaje.EnableHeadersVisualStyles = false;
            this.dgvFichaje.GridColor = System.Drawing.Color.Gainsboro;
            this.dgvFichaje.Location = new System.Drawing.Point(0, 24);
            this.dgvFichaje.Name = "dgvFichaje";
            this.dgvFichaje.Size = new System.Drawing.Size(928, 427);
            this.dgvFichaje.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editarToolStripMenuItem,
            this.borrarToolStripMenuItem,
            this.imprimirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(928, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.editarToolStripMenuItem.Text = "Editar";
            this.editarToolStripMenuItem.Click += new System.EventHandler(this.editarToolStripMenuItem_Click);
            // 
            // borrarToolStripMenuItem
            // 
            this.borrarToolStripMenuItem.Name = "borrarToolStripMenuItem";
            this.borrarToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.borrarToolStripMenuItem.Text = "Borrar";
            this.borrarToolStripMenuItem.Click += new System.EventHandler(this.borrarToolStripMenuItem_Click);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            this.imprimirToolStripMenuItem.Click += new System.EventHandler(this.imprimirToolStripMenuItem_Click);
            // 
            // ID_Fichaje
            // 
            this.ID_Fichaje.HeaderText = "ID_Fichaje";
            this.ID_Fichaje.Name = "ID_Fichaje";
            this.ID_Fichaje.Visible = false;
            // 
            // ID_Empleado
            // 
            this.ID_Empleado.HeaderText = "ID_Empleado";
            this.ID_Empleado.Name = "ID_Empleado";
            this.ID_Empleado.Visible = false;
            // 
            // Nombre_Empleado
            // 
            this.Nombre_Empleado.HeaderText = "Nombre_Empleado";
            this.Nombre_Empleado.Name = "Nombre_Empleado";
            // 
            // Fecha_Hora_Entrada
            // 
            this.Fecha_Hora_Entrada.HeaderText = "Fecha_Hora_Entrada";
            this.Fecha_Hora_Entrada.Name = "Fecha_Hora_Entrada";
            // 
            // Fecha_Hora_Salida
            // 
            this.Fecha_Hora_Salida.HeaderText = "Fecha_Hora_Salida";
            this.Fecha_Hora_Salida.Name = "Fecha_Hora_Salida";
            // 
            // Tipo_Fichaje
            // 
            this.Tipo_Fichaje.HeaderText = "Tipo_Fichaje";
            this.Tipo_Fichaje.Name = "Tipo_Fichaje";
            // 
            // Metodo_Fichaje
            // 
            this.Metodo_Fichaje.HeaderText = "Metodo_Fichaje";
            this.Metodo_Fichaje.Name = "Metodo_Fichaje";
            // 
            // Ubicacion_Fichaje
            // 
            this.Ubicacion_Fichaje.HeaderText = "Ubicacion_Fichaje";
            this.Ubicacion_Fichaje.Name = "Ubicacion_Fichaje";
            // 
            // Estado
            // 
            this.Estado.HeaderText = "Estado";
            this.Estado.Name = "Estado";
            // 
            // Fichajes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(928, 451);
            this.Controls.Add(this.dgvFichaje);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Fichajes";
            this.Text = "Fichajes";
            ((System.ComponentModel.ISupportInitialize)(this.dgvFichaje)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvFichaje;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borrarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Fichaje;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Empleado;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre_Empleado;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha_Hora_Entrada;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha_Hora_Salida;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tipo_Fichaje;
        private System.Windows.Forms.DataGridViewTextBoxColumn Metodo_Fichaje;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ubicacion_Fichaje;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado;
    }
}