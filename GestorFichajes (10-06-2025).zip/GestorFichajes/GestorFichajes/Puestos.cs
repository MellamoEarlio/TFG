﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Puestos : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Puestos
        public Puestos()
        {
            InitializeComponent();
            // Cargar los puestos desde la base de datos al DataGridView
            CargarPuestos();
        }

        // Método para cargar los puestos desde la base de datos
        private void CargarPuestos()
        {
            dgvPuestos.Rows.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ID_Puesto, Nombre_Puesto, Descripcion, Salario_Base FROM PUESTO";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                // Leer los resultados y añadir al DataGridView
                while (reader.Read())
                {
                    int fila = dgvPuestos.Rows.Add();
                    dgvPuestos.Rows[fila].Cells["ID_Puesto"].Value = reader["ID_Puesto"];
                    dgvPuestos.Rows[fila].Cells["Nombre_Puesto"].Value = reader["Nombre_Puesto"];
                    dgvPuestos.Rows[fila].Cells["Descripcion"].Value = reader["Descripcion"];
                    dgvPuestos.Rows[fila].Cells["Salario_Base"].Value = reader["Salario_Base"];
                }
            }
        }

        // Manejar el evento de clic del menú "Añadir"
        private void añadirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new AEPuesto();
            if (form.ShowDialog() == DialogResult.OK)
            {
                // Recargar los puestos después de añadir uno nuevo
                CargarPuestos();
                MessageBox.Show("Puesto añadido correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvPuestos.SelectedRows.Count > 0)
            {
                int idPuesto = Convert.ToInt32(dgvPuestos.SelectedRows[0].Cells["ID_Puesto"].Value);
                string nombre = dgvPuestos.SelectedRows[0].Cells["Nombre_Puesto"].Value.ToString();
                string descripcion = dgvPuestos.SelectedRows[0].Cells["Descripcion"].Value.ToString();
                string salario = dgvPuestos.SelectedRows[0].Cells["Salario_Base"].Value.ToString();

                var form = new AEPuesto(idPuesto, nombre, descripcion, salario);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    // Recargar los puestos después de editar uno
                    CargarPuestos();
                    MessageBox.Show("Puesto actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Seleccione un puesto para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvPuestos.SelectedRows.Count > 0)
            {
                int idPuesto = Convert.ToInt32(dgvPuestos.SelectedRows[0].Cells["ID_Puesto"].Value);
                var confirm = MessageBox.Show("¿Deseas eliminar este puesto?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        string query = "DELETE FROM PUESTO WHERE ID_Puesto = @id";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@id", idPuesto);
                        cmd.ExecuteNonQuery();
                        // Recargar los puestos después de eliminar uno
                        CargarPuestos();
                        MessageBox.Show("Puesto eliminado.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione un puesto para borrar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IPuestos(); // Asegurar que `IPuestos` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Listado_de_Puestos{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe (exportar e imprimir)
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}