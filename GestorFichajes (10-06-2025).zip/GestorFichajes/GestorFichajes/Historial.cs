﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Historial : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Historial
        public Historial()
        {
            InitializeComponent();
            CargarHistorial();
        }

        // Método para cargar el historial de cambios de puesto desde la base de datos
        private void CargarHistorial()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"SELECT h.ID_Historial,
                                        e.Nombre + ' ' + e.Apellidos AS NombreEmpleado,
                                        p1.Nombre_Puesto AS PuestoAnterior,
                                        p2.Nombre_Puesto AS PuestoNuevo,
                                        h.Fecha_Cambio,
                                        h.Motivo
                                 FROM HISTORIAL_PUESTO h
                                 JOIN EMPLEADO e ON h.ID_Empleado = e.ID_Empleado
                                 LEFT JOIN PUESTO p1 ON h.ID_Puesto_Anterior = p1.ID_Puesto
                                 JOIN PUESTO p2 ON h.ID_Puesto_Nuevo = p2.ID_Puesto";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                dgvHistorial.Rows.Clear(); // Limpiar filas antes de agregar nuevas

                while (reader.Read())
                {
                    dgvHistorial.Rows.Add(
                        reader["ID_Historial"],
                        reader["NombreEmpleado"],
                        reader["PuestoAnterior"],
                        reader["PuestoNuevo"],
                        reader["Fecha_Cambio"],
                        reader["Motivo"]
                    );
                }
            }
        }

        // Método para manejar el evento de clic del menú "Añadir"
        private void añadirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AEHistorial form = new AEHistorial();
            if (form.ShowDialog() == DialogResult.OK)
            {
                CargarHistorial();
            }
        }

        // Método para manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvHistorial.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvHistorial.SelectedRows[0];

                // Cargar los valores de la fila seleccionada en AEHistorial
                AEHistorial form = new AEHistorial(
                    (int)row.Cells["ID_Historial"].Value,
                    (DateTime)row.Cells["Fecha_Cambio"].Value,
                    row.Cells["Motivo"].Value.ToString()
                );

                if (form.ShowDialog() == DialogResult.OK)
                {
                    CargarHistorial(); // Recargar datos después de la edición
                }
            }
            else
            {
                MessageBox.Show("Selecciona un registro para editar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvHistorial.SelectedRows.Count > 0)
            {
                int idHistorial = (int)dgvHistorial.SelectedRows[0].Cells["ID_Historial"].Value;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM HISTORIAL_PUESTO WHERE ID_Historial = @id", conn);
                    cmd.Parameters.AddWithValue("@id", idHistorial);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Historial eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarHistorial();
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el historial.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecciona un historial para borrar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IHistotial(); // Asegurar que `IHistotial` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Historial_empleados{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de visualización del informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}