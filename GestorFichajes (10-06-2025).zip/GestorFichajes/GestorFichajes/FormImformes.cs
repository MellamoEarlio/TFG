﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class FormImformes : Form
    {
        // Informe a generar
        ReportDocument informe;

        public FormImformes(ReportDocument informe)
        {
            InitializeComponent();
            this.informe = informe;
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            // Se personaliza el título de la ventana y se pasan parámetros
            this.Text = "Informe " + informe.GetType().Name;

            // Se asocia el informe al visor
            crystalReportViewer1.ReportSource = informe;
        }
    }
}
