﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class EditarFichaje : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        // ID del fichaje a editar
        private readonly int idFichaje;

        // Constructor de la clase EditarFichaje
        public EditarFichaje(int idFichaje)
        {
            InitializeComponent();
            this.idFichaje = idFichaje;
            CargarTiposFichaje();
            CargarMetodosFichaje();
            CargarEstados();
            CargarDatosFichaje();
        }

        // Método para cargar los datos del fichaje desde la base de datos
        private void CargarDatosFichaje()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM FICHAJE WHERE ID_Fichaje = @id";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", idFichaje);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Rellenar los controles con los datos del fichaje
                                dTPEntrada.Value = Convert.ToDateTime(reader["Fecha_Hora_Entrada"]);
                                if (reader["Fecha_Hora_Salida"] != DBNull.Value)
                                {
                                    dTPSalida.Value = Convert.ToDateTime(reader["Fecha_Hora_Salida"]);
                                    dTPSalida.Checked = true;
                                }
                                else
                                {
                                    dTPSalida.Checked = false;
                                }

                                comboBoxTipo.SelectedItem = reader["Tipo_Fichaje"].ToString();
                                comboBoxMetodo.SelectedItem = reader["Metodo_Fichaje"].ToString();
                                tbUbi.Text = reader["Ubicacion_Fichaje"].ToString();
                                comboBoxEstado.SelectedItem = reader["Estado"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("No se encontró el fichaje especificado.");
                                this.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos del fichaje: {ex.Message}");
                this.Close();
            }
        }

        // Método para cargar los tipos de fichaje en el ComboBox
        private void CargarTiposFichaje()
        {
            try
            {
                comboBoxTipo.Items.Clear();
                comboBoxTipo.Items.Add("Entrada");
                comboBoxTipo.Items.Add("Salida");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar tipos de fichaje: {ex.Message}");
            }
        }

        // Método para cargar los métodos de fichaje en el ComboBox
        private void CargarMetodosFichaje()
        {
            try
            {
                comboBoxMetodo.Items.Clear();
                comboBoxMetodo.Items.Add("App");
                comboBoxMetodo.Items.Add("Web");
                comboBoxMetodo.Items.Add("Facial");
                comboBoxMetodo.Items.Add("Huella");
                comboBoxMetodo.Items.Add("Tarjeta");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar métodos de fichaje: {ex.Message}");
            }
        }

        // Método para cargar los estados en el ComboBox
        private void CargarEstados()
        {
            try
            {
                comboBoxEstado.Items.Clear();
                comboBoxEstado.Items.Add("Normal");
                comboBoxEstado.Items.Add("Retraso");
                comboBoxEstado.Items.Add("Ausencia");
                comboBoxEstado.Items.Add("Horas Extra");
                comboBoxEstado.Items.Add("Conflicto");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar estados: {ex.Message}");
            }
        }

        // Método para manejar el evento de clic del botón Aceptar
        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"UPDATE FICHAJE SET
                                  Fecha_Hora_Entrada = @entrada,
                                  Fecha_Hora_Salida = @salida,
                                  Tipo_Fichaje = @tipo,
                                  Metodo_Fichaje = @metodo,
                                  Ubicacion_Fichaje = @ubicacion,
                                  Estado = @estado
                                  WHERE ID_Fichaje = @id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@entrada", dTPEntrada.Value);
                        cmd.Parameters.AddWithValue("@salida", dTPSalida.Checked ? (object)dTPSalida.Value : DBNull.Value);
                        cmd.Parameters.AddWithValue("@tipo", comboBoxTipo.SelectedItem?.ToString() ?? "Entrada");
                        cmd.Parameters.AddWithValue("@metodo", comboBoxMetodo.SelectedItem?.ToString() ?? "App");
                        cmd.Parameters.AddWithValue("@ubicacion", tbUbi.Text.Trim());
                        cmd.Parameters.AddWithValue("@estado", comboBoxEstado.SelectedItem?.ToString() ?? "Normal");
                        cmd.Parameters.AddWithValue("@id", idFichaje);

                        int filasAfectadas = cmd.ExecuteNonQuery();
                        if (filasAfectadas > 0)
                        {
                            MessageBox.Show("Fichaje actualizado correctamente.");
                            DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo actualizar el fichaje.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar el fichaje: {ex.Message}");
            }
        }

        // Método para manejar el evento de clic del botón Cancelar
        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}