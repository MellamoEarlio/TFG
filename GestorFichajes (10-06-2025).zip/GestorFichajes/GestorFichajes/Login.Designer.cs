﻿namespace GestorFichajes
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_nocuenta = new System.Windows.Forms.Label();
            this.bttn_login = new System.Windows.Forms.Button();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.tb_user = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox_puesto = new System.Windows.Forms.ComboBox();
            this.comboBox_depart = new System.Windows.Forms.ComboBox();
            this.lbl_puesto = new System.Windows.Forms.Label();
            this.lbl_depart = new System.Windows.Forms.Label();
            this.lbl_contratacion = new System.Windows.Forms.Label();
            this.dtp_contratacion = new System.Windows.Forms.DateTimePicker();
            this.dtp_nacimiento = new System.Windows.Forms.DateTimePicker();
            this.lbl_password = new System.Windows.Forms.Label();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.tb_address = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_dni = new System.Windows.Forms.Label();
            this.lbl_sicuenta = new System.Windows.Forms.Label();
            this.tb_phone = new System.Windows.Forms.TextBox();
            this.lbl_birthday = new System.Windows.Forms.Label();
            this.tb_dni = new System.Windows.Forms.TextBox();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.tb_ape = new System.Windows.Forms.TextBox();
            this.lbl_ape = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.bttn_signin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lbl_nocuenta);
            this.panel1.Controls.Add(this.bttn_login);
            this.panel1.Controls.Add(this.tb_pass);
            this.panel1.Controls.Add(this.tb_user);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lbl_nombre);
            this.panel1.Location = new System.Drawing.Point(21, 88);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(351, 189);
            this.panel1.TabIndex = 0;
            // 
            // lbl_nocuenta
            // 
            this.lbl_nocuenta.AutoSize = true;
            this.lbl_nocuenta.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nocuenta.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.lbl_nocuenta.Location = new System.Drawing.Point(140, 152);
            this.lbl_nocuenta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_nocuenta.Name = "lbl_nocuenta";
            this.lbl_nocuenta.Size = new System.Drawing.Size(100, 15);
            this.lbl_nocuenta.TabIndex = 5;
            this.lbl_nocuenta.Text = "No tengo cuenta";
            this.lbl_nocuenta.Click += new System.EventHandler(this.lbl_nocuenta_Click);
            // 
            // bttn_login
            // 
            this.bttn_login.BackColor = System.Drawing.Color.CornflowerBlue;
            this.bttn_login.FlatAppearance.BorderSize = 0;
            this.bttn_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_login.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_login.ForeColor = System.Drawing.Color.White;
            this.bttn_login.Location = new System.Drawing.Point(151, 105);
            this.bttn_login.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bttn_login.Name = "bttn_login";
            this.bttn_login.Size = new System.Drawing.Size(88, 30);
            this.bttn_login.TabIndex = 4;
            this.bttn_login.Text = "Login";
            this.bttn_login.UseVisualStyleBackColor = false;
            this.bttn_login.Click += new System.EventHandler(this.bttn_login_Click);
            // 
            // tb_pass
            // 
            this.tb_pass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_pass.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_pass.Location = new System.Drawing.Point(123, 71);
            this.tb_pass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.Size = new System.Drawing.Size(154, 23);
            this.tb_pass.TabIndex = 3;
            this.tb_pass.UseSystemPasswordChar = true;
            // 
            // tb_user
            // 
            this.tb_user.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_user.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_user.Location = new System.Drawing.Point(123, 31);
            this.tb_user.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_user.Name = "tb_user";
            this.tb_user.Size = new System.Drawing.Size(154, 23);
            this.tb_user.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(34, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Contraseña";
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_nombre.Location = new System.Drawing.Point(34, 31);
            this.lbl_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(60, 30);
            this.lbl_nombre.TabIndex = 0;
            this.lbl_nombre.Text = "Nombre\r\nEmpleado";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.comboBox_puesto);
            this.panel2.Controls.Add(this.comboBox_depart);
            this.panel2.Controls.Add(this.lbl_puesto);
            this.panel2.Controls.Add(this.lbl_depart);
            this.panel2.Controls.Add(this.lbl_contratacion);
            this.panel2.Controls.Add(this.dtp_contratacion);
            this.panel2.Controls.Add(this.dtp_nacimiento);
            this.panel2.Controls.Add(this.lbl_password);
            this.panel2.Controls.Add(this.tb_password);
            this.panel2.Controls.Add(this.tb_email);
            this.panel2.Controls.Add(this.tb_address);
            this.panel2.Controls.Add(this.lbl_email);
            this.panel2.Controls.Add(this.lbl_address);
            this.panel2.Controls.Add(this.lbl_dni);
            this.panel2.Controls.Add(this.lbl_sicuenta);
            this.panel2.Controls.Add(this.tb_phone);
            this.panel2.Controls.Add(this.lbl_birthday);
            this.panel2.Controls.Add(this.tb_dni);
            this.panel2.Controls.Add(this.lbl_phone);
            this.panel2.Controls.Add(this.tb_ape);
            this.panel2.Controls.Add(this.lbl_ape);
            this.panel2.Controls.Add(this.tb_name);
            this.panel2.Controls.Add(this.lbl_name);
            this.panel2.Controls.Add(this.bttn_signin);
            this.panel2.Location = new System.Drawing.Point(498, 88);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(405, 487);
            this.panel2.TabIndex = 5;
            this.panel2.Visible = false;
            // 
            // comboBox_puesto
            // 
            this.comboBox_puesto.FormattingEnabled = true;
            this.comboBox_puesto.Location = new System.Drawing.Point(158, 370);
            this.comboBox_puesto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox_puesto.Name = "comboBox_puesto";
            this.comboBox_puesto.Size = new System.Drawing.Size(154, 25);
            this.comboBox_puesto.TabIndex = 29;
            // 
            // comboBox_depart
            // 
            this.comboBox_depart.FormattingEnabled = true;
            this.comboBox_depart.Location = new System.Drawing.Point(158, 336);
            this.comboBox_depart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox_depart.Name = "comboBox_depart";
            this.comboBox_depart.Size = new System.Drawing.Size(154, 25);
            this.comboBox_depart.TabIndex = 28;
            // 
            // lbl_puesto
            // 
            this.lbl_puesto.AutoSize = true;
            this.lbl_puesto.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_puesto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_puesto.Location = new System.Drawing.Point(64, 374);
            this.lbl_puesto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_puesto.Name = "lbl_puesto";
            this.lbl_puesto.Size = new System.Drawing.Size(43, 15);
            this.lbl_puesto.TabIndex = 27;
            this.lbl_puesto.Text = "Puesto";
            // 
            // lbl_depart
            // 
            this.lbl_depart.AutoSize = true;
            this.lbl_depart.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_depart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_depart.Location = new System.Drawing.Point(64, 340);
            this.lbl_depart.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_depart.Name = "lbl_depart";
            this.lbl_depart.Size = new System.Drawing.Size(83, 15);
            this.lbl_depart.TabIndex = 26;
            this.lbl_depart.Text = "Departamento";
            // 
            // lbl_contratacion
            // 
            this.lbl_contratacion.AutoSize = true;
            this.lbl_contratacion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_contratacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_contratacion.Location = new System.Drawing.Point(64, 301);
            this.lbl_contratacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_contratacion.Name = "lbl_contratacion";
            this.lbl_contratacion.Size = new System.Drawing.Size(76, 30);
            this.lbl_contratacion.TabIndex = 25;
            this.lbl_contratacion.Text = "Fecha\r\nContratacion\r\n";
            // 
            // dtp_contratacion
            // 
            this.dtp_contratacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_contratacion.Location = new System.Drawing.Point(158, 301);
            this.dtp_contratacion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtp_contratacion.Name = "dtp_contratacion";
            this.dtp_contratacion.Size = new System.Drawing.Size(154, 25);
            this.dtp_contratacion.TabIndex = 14;
            this.dtp_contratacion.Value = new System.DateTime(2025, 5, 10, 0, 0, 0, 0);
            // 
            // dtp_nacimiento
            // 
            this.dtp_nacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_nacimiento.Location = new System.Drawing.Point(158, 131);
            this.dtp_nacimiento.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtp_nacimiento.Name = "dtp_nacimiento";
            this.dtp_nacimiento.Size = new System.Drawing.Size(154, 25);
            this.dtp_nacimiento.TabIndex = 9;
            this.dtp_nacimiento.Value = new System.DateTime(2025, 5, 10, 0, 0, 0, 0);
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_password.Location = new System.Drawing.Point(64, 271);
            this.lbl_password.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(67, 15);
            this.lbl_password.TabIndex = 21;
            this.lbl_password.Text = "Contraseña";
            // 
            // tb_password
            // 
            this.tb_password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_password.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_password.Location = new System.Drawing.Point(158, 267);
            this.tb_password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(154, 23);
            this.tb_password.TabIndex = 13;
            this.tb_password.UseSystemPasswordChar = true;
            // 
            // tb_email
            // 
            this.tb_email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_email.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_email.Location = new System.Drawing.Point(158, 233);
            this.tb_email.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(154, 23);
            this.tb_email.TabIndex = 12;
            // 
            // tb_address
            // 
            this.tb_address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_address.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_address.Location = new System.Drawing.Point(158, 165);
            this.tb_address.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_address.Name = "tb_address";
            this.tb_address.Size = new System.Drawing.Size(154, 23);
            this.tb_address.TabIndex = 10;
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_email.Location = new System.Drawing.Point(64, 237);
            this.lbl_email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(36, 15);
            this.lbl_email.TabIndex = 18;
            this.lbl_email.Text = "Email";
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_address.Location = new System.Drawing.Point(64, 174);
            this.lbl_address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(57, 15);
            this.lbl_address.TabIndex = 17;
            this.lbl_address.Text = "Direccion";
            // 
            // lbl_dni
            // 
            this.lbl_dni.AutoSize = true;
            this.lbl_dni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dni.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_dni.Location = new System.Drawing.Point(64, 101);
            this.lbl_dni.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dni.Name = "lbl_dni";
            this.lbl_dni.Size = new System.Drawing.Size(48, 15);
            this.lbl_dni.TabIndex = 16;
            this.lbl_dni.Text = "DNI NIF";
            // 
            // lbl_sicuenta
            // 
            this.lbl_sicuenta.AutoSize = true;
            this.lbl_sicuenta.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sicuenta.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.lbl_sicuenta.Location = new System.Drawing.Point(176, 457);
            this.lbl_sicuenta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_sicuenta.Name = "lbl_sicuenta";
            this.lbl_sicuenta.Size = new System.Drawing.Size(96, 15);
            this.lbl_sicuenta.TabIndex = 15;
            this.lbl_sicuenta.Text = "Ya tengo cuenta";
            this.lbl_sicuenta.Click += new System.EventHandler(this.lbl_sicuenta_Click);
            // 
            // tb_phone
            // 
            this.tb_phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_phone.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_phone.Location = new System.Drawing.Point(158, 199);
            this.tb_phone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_phone.Name = "tb_phone";
            this.tb_phone.Size = new System.Drawing.Size(154, 23);
            this.tb_phone.TabIndex = 11;
            // 
            // lbl_birthday
            // 
            this.lbl_birthday.AutoSize = true;
            this.lbl_birthday.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_birthday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_birthday.Location = new System.Drawing.Point(64, 131);
            this.lbl_birthday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_birthday.Name = "lbl_birthday";
            this.lbl_birthday.Size = new System.Drawing.Size(69, 30);
            this.lbl_birthday.TabIndex = 11;
            this.lbl_birthday.Text = "Fecha\r\nNacimiento";
            // 
            // tb_dni
            // 
            this.tb_dni.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_dni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_dni.Location = new System.Drawing.Point(158, 97);
            this.tb_dni.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_dni.Name = "tb_dni";
            this.tb_dni.Size = new System.Drawing.Size(154, 23);
            this.tb_dni.TabIndex = 8;
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_phone.Location = new System.Drawing.Point(64, 203);
            this.lbl_phone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(53, 15);
            this.lbl_phone.TabIndex = 9;
            this.lbl_phone.Text = "Telefono";
            // 
            // tb_ape
            // 
            this.tb_ape.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_ape.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ape.Location = new System.Drawing.Point(158, 63);
            this.tb_ape.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_ape.Name = "tb_ape";
            this.tb_ape.Size = new System.Drawing.Size(154, 23);
            this.tb_ape.TabIndex = 7;
            // 
            // lbl_ape
            // 
            this.lbl_ape.AutoSize = true;
            this.lbl_ape.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ape.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_ape.Location = new System.Drawing.Point(64, 63);
            this.lbl_ape.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ape.Name = "lbl_ape";
            this.lbl_ape.Size = new System.Drawing.Size(56, 15);
            this.lbl_ape.TabIndex = 7;
            this.lbl_ape.Text = "Apellidos";
            // 
            // tb_name
            // 
            this.tb_name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_name.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_name.Location = new System.Drawing.Point(158, 29);
            this.tb_name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(154, 23);
            this.tb_name.TabIndex = 6;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl_name.Location = new System.Drawing.Point(64, 33);
            this.lbl_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(51, 15);
            this.lbl_name.TabIndex = 5;
            this.lbl_name.Text = "Nombre";
            // 
            // bttn_signin
            // 
            this.bttn_signin.BackColor = System.Drawing.Color.CornflowerBlue;
            this.bttn_signin.FlatAppearance.BorderSize = 0;
            this.bttn_signin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_signin.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_signin.ForeColor = System.Drawing.Color.White;
            this.bttn_signin.Location = new System.Drawing.Point(188, 404);
            this.bttn_signin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bttn_signin.Name = "bttn_signin";
            this.bttn_signin.Size = new System.Drawing.Size(88, 30);
            this.bttn_signin.TabIndex = 0;
            this.bttn_signin.Text = "Registrar";
            this.bttn_signin.UseVisualStyleBackColor = false;
            this.bttn_signin.Click += new System.EventHandler(this.bttn_signin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 47);
            this.label1.TabIndex = 6;
            this.label1.Text = "¡Bienvenido a FichAPP!";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = global::GestorFichajes.Properties.Resources.VeniceAI_fV6KlWo;
            this.ClientSize = new System.Drawing.Size(933, 588);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.DimGray;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bttn_login;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.TextBox tb_user;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_nocuenta;
        private System.Windows.Forms.TextBox tb_phone;
        private System.Windows.Forms.Label lbl_birthday;
        private System.Windows.Forms.TextBox tb_dni;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.TextBox tb_ape;
        private System.Windows.Forms.Label lbl_ape;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Button bttn_signin;
        private System.Windows.Forms.Label lbl_sicuenta;
        private System.Windows.Forms.Label lbl_dni;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.DateTimePicker dtp_contratacion;
        private System.Windows.Forms.DateTimePicker dtp_nacimiento;
        private System.Windows.Forms.Label lbl_puesto;
        private System.Windows.Forms.Label lbl_depart;
        private System.Windows.Forms.Label lbl_contratacion;
        private System.Windows.Forms.ComboBox comboBox_puesto;
        private System.Windows.Forms.ComboBox comboBox_depart;
        private System.Windows.Forms.Label label1;
    }
}