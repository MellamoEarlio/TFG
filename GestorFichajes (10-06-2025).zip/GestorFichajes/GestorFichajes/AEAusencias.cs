﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class AEAusencias : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Variables para almacenar el ID del empleado y la ausencia
        private int idEmpleado;
        private int? idAusencia; // Nullable para saber si es nuevo (null) o editar (con valor)
        private bool modoEdicion = false;

        // Constructor para NUEVA ausencia
        public AEAusencias(int empleadoId)
        {
            InitializeComponent();

            // Inicializar variables y cargar datos iniciales
            idEmpleado = empleadoId;
            modoEdicion = false;

            CargarTiposAusencia();
            CargarDatosEmpleado();

            // Establecer las fechas por defecto
            dateTimePicker1.Value = DateTime.Today;
            dateTimePicker2.Value = DateTime.Today;
        }

        // Constructor para EDITAR ausencia
        public AEAusencias(int idAusencia, int empleadoId, string tipo, DateTime fechaInicio, DateTime? fechaFin, bool certificado, string observaciones)
        {
            InitializeComponent();

            // Inicializar variables y cargar datos iniciales
            this.idAusencia = idAusencia;
            idEmpleado = empleadoId;
            modoEdicion = true;

            CargarTiposAusencia();
            CargarDatosEmpleado();

            // Rellenar controles con datos recibidos
            comboBoxTipo.SelectedItem = tipo;
            dateTimePicker1.Value = fechaInicio;
            dateTimePicker2.Value = fechaFin ?? fechaInicio; // Si fechaFin es null, ponemos inicio
            checkBoxCertificado.Checked = certificado;
            tbObservaciones.Text = observaciones;
        }

        // Método para cargar los tipos de ausencias en el ComboBox
        private void CargarTiposAusencia()
        {
            comboBoxTipo.Items.Clear();
            comboBoxTipo.Items.AddRange(new object[] {
                "Enfermedad",
                "Accidente",
                "Maternidad",
                "Paternidad",
                "Otro"
            });
        }

        // Método para cargar los datos del empleado
        private void CargarDatosEmpleado()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"SELECT e.Nombre, e.Apellidos, d.Nombre AS Departamento
                                     FROM EMPLEADO e
                                     LEFT JOIN DEPARTAMENTO d ON e.ID_Departamento = d.ID_Departamento
                                     WHERE e.ID_Empleado = @ID_Empleado";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Empleado", idEmpleado);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            lblEmpleado.Text = $"{reader["Nombre"]} {reader["Apellidos"]}";
                            lblDepartamento.Text = reader["Departamento"]?.ToString() ?? "Sin departamento";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos del empleado: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del botón Guardar
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    if (modoEdicion && idAusencia.HasValue)
                    {
                        // Actualizar la ausencia existente en la base de datos
                        string updateQuery = @"UPDATE AUSENCIA SET
                                                Tipo = @Tipo,
                                                Fecha_Inicio = @Fecha_Inicio,
                                                Fecha_Fin = @Fecha_Fin,
                                                Certificado = @Certificado,
                                                Observaciones = @Observaciones
                                            WHERE ID_Ausencia = @ID_Ausencia";

                        SqlCommand cmdUpdate = new SqlCommand(updateQuery, connection);
                        cmdUpdate.Parameters.AddWithValue("@Tipo", comboBoxTipo.SelectedItem.ToString());
                        cmdUpdate.Parameters.AddWithValue("@Fecha_Inicio", dateTimePicker1.Value.Date);
                        cmdUpdate.Parameters.AddWithValue("@Fecha_Fin", dateTimePicker2.Value.Date);
                        cmdUpdate.Parameters.AddWithValue("@Certificado", checkBoxCertificado.Checked);
                        cmdUpdate.Parameters.AddWithValue("@Observaciones", tbObservaciones.Text);
                        cmdUpdate.Parameters.AddWithValue("@ID_Ausencia", idAusencia.Value);

                        int rows = cmdUpdate.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            MessageBox.Show("Ausencia actualizada correctamente", "Éxito",
                                          MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo actualizar la ausencia", "Error",
                                          MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        // Insertar una nueva ausencia en la base de datos
                        string insertQuery = @"INSERT INTO AUSENCIA
                                            (ID_Empleado, Tipo, Fecha_Inicio, Fecha_Fin, Certificado, Observaciones)
                                            VALUES
                                            (@ID_Empleado, @Tipo, @Fecha_Inicio, @Fecha_Fin, @Certificado, @Observaciones)";

                        SqlCommand cmdInsert = new SqlCommand(insertQuery, connection);
                        cmdInsert.Parameters.AddWithValue("@ID_Empleado", idEmpleado);
                        cmdInsert.Parameters.AddWithValue("@Tipo", comboBoxTipo.SelectedItem.ToString());
                        cmdInsert.Parameters.AddWithValue("@Fecha_Inicio", dateTimePicker1.Value.Date);
                        cmdInsert.Parameters.AddWithValue("@Fecha_Fin", dateTimePicker2.Value.Date);
                        cmdInsert.Parameters.AddWithValue("@Certificado", checkBoxCertificado.Checked);
                        cmdInsert.Parameters.AddWithValue("@Observaciones", tbObservaciones.Text);

                        int rows = cmdInsert.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            MessageBox.Show("Ausencia registrada correctamente", "Éxito",
                                          MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo registrar la ausencia", "Error",
                                          MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar la ausencia: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para validar los campos antes de guardar
        private bool ValidarCampos()
        {
            if (comboBoxTipo.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccione un tipo de ausencia", "Advertencia",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                comboBoxTipo.Focus();
                return false;
            }

            if (dateTimePicker1.Value > dateTimePicker2.Value)
            {
                MessageBox.Show("La fecha de inicio no puede ser posterior a la fecha fin", "Advertencia",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dateTimePicker1.Focus();
                return false;
            }

            return true;
        }

        // Método para manejar el evento de clic del botón Cancelar
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}