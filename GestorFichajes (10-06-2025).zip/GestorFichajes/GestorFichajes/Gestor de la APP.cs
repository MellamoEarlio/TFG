﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Gestor_de_la_APP : Form
    {
        // Variable para almacenar el ID del empleado
        private int idEmpleado;

        // Constructor de la clase Gestor_de_la_APP
        public Gestor_de_la_APP(int empleadoId)
        {
            InitializeComponent();
            this.idEmpleado = empleadoId;
        }

        // Método para manejar el evento de clic del menú "Información"
        private void InformacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Ajustes y mostrarla como un cuadro de diálogo
            Ajustes ajustes = new Ajustes(idEmpleado);
            ajustes.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Incidencias de Ausencias"
        private void incidenciasDeAusenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Listado_de_Incidencias y mostrarla como un cuadro de diálogo
            Listado_de_Incidencias listado_De_Incidencias = new Listado_de_Incidencias();
            listado_De_Incidencias.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Ausencia"
        private void ausenciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Ausencias y mostrarla como un cuadro de diálogo
            Ausencias ausencias = new Ausencias();
            ausencias.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Departamento"
        private void departamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Departamentos y mostrarla como un cuadro de diálogo
            Departamentos departamentos = new Departamentos();
            departamentos.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Empleados"
        private void empleadosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Empleados y mostrarla como un cuadro de diálogo
            Empleados empleados = new Empleados();
            empleados.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Fichajes"
        private void fichajesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Fichajes y mostrarla como un cuadro de diálogo
            Fichajes fichajes = new Fichajes();
            fichajes.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Historial"
        private void historialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Historial y mostrarla como un cuadro de diálogo
            Historial historial = new Historial();
            historial.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Horarios"
        private void horariosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Horarios y mostrarla como un cuadro de diálogo
            Horarios horarios = new Horarios();
            horarios.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Permisos"
        private void permisosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Permisos y mostrarla como un cuadro de diálogo
            Permisos permisos = new Permisos();
            permisos.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Puesto"
        private void puestoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Permisos y mostrarla como un cuadro de diálogo
            Permisos permisos = new Permisos();
            permisos.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Vacaciones"
        private void vacacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Vacaciones y mostrarla como un cuadro de diálogo
            Vacaciones vacaciones = new Vacaciones();
            vacaciones.ShowDialog();
        }

        // Método para manejar el evento de clic del menú "Ir a Fichaje"
        private void irAFichajeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Obtener el nombre y puesto del empleado desde la base de datos
            string nombreEmpleado = "";
            int puestoEmpleado = 0;

            try
            {
                // Establecer la conexión a la base de datos
                using (SqlConnection connection = new SqlConnection(@"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True"))
                {
                    connection.Open();
                    // Consultar el nombre y el ID del puesto del empleado por su ID
                    string query = "SELECT Nombre, ID_Puesto FROM EMPLEADO WHERE ID_Empleado = @idEmpleado";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Añadir el parámetro de ID del empleado a la consulta
                        command.Parameters.AddWithValue("@idEmpleado", idEmpleado);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Leer los datos del empleado
                            if (reader.Read())
                            {
                                nombreEmpleado = reader["Nombre"].ToString();
                                puestoEmpleado = Convert.ToInt32(reader["ID_Puesto"]);
                            }
                            else
                            {
                                // Mostrar un mensaje de error si no se encuentra el empleado
                                MessageBox.Show("No se encontró el empleado en la base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }
                }

                // Abrir el formulario Main con los datos correctos
                Main main = new Main(nombreEmpleado, idEmpleado, puestoEmpleado);
                main.Show();
            }
            catch (Exception ex)
            {
                // Mostrar un mensaje de error si ocurre una excepción durante la carga de datos
                MessageBox.Show($"Error al cargar los datos del empleado: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}