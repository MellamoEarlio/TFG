﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Listado_de_Incidencias : Form
    {
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        public Listado_de_Incidencias()
        {
            InitializeComponent();
            CargarDatos();
        }

        public void CargarDatos()
        {
            dgvIncidencias.Rows.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT i.ID_Incidencia, 
                           e.Nombre + ' ' + e.Apellidos AS NombreEmpleado, 
                           i.Tipo, i.Descripcion, i.Fecha, i.Resuelta 
                           FROM INCIDENCIA i
                           INNER JOIN EMPLEADO e ON i.ID_Empleado = e.ID_Empleado";

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        int fila = dgvIncidencias.Rows.Add();
                        dgvIncidencias.Rows[fila].Cells["ID_Incidencia"].Value = reader["ID_Incidencia"];
                        dgvIncidencias.Rows[fila].Cells["Empleado"].Value = reader["NombreEmpleado"];
                        dgvIncidencias.Rows[fila].Cells["Tipo"].Value = reader["Tipo"];
                        dgvIncidencias.Rows[fila].Cells["Descripcion"].Value = reader["Descripcion"];
                        dgvIncidencias.Rows[fila].Cells["Fecha"].Value = Convert.ToDateTime(reader["Fecha"]).ToString("dd/MM/yyyy");
                        dgvIncidencias.Rows[fila].Cells["Resuelta"].Value = (bool)reader["Resuelta"] ? "Sí" : "No";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar datos: {ex.Message}", "Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvIncidencias.SelectedRows.Count > 0)
            {
                int idIncidencia = Convert.ToInt32(dgvIncidencias.SelectedRows[0].Cells["ID_Incidencia"].Value);
                int idEmpleado = ObtenerIdEmpleadoPorIncidencia(idIncidencia);

                var incidencia = new Incidencia
                {
                    ID_Incidencia = idIncidencia,
                    ID_Empleado = idEmpleado,
                    Tipo = dgvIncidencias.SelectedRows[0].Cells["Tipo"].Value.ToString(),
                    Descripcion = dgvIncidencias.SelectedRows[0].Cells["Descripcion"].Value.ToString(),
                    Fecha = dgvIncidencias.SelectedRows[0].Cells["Fecha"].Value.ToString(),
                    Resuelta = dgvIncidencias.SelectedRows[0].Cells["Resuelta"].Value.ToString() == "Sí"
                };

                using (var form = new EditarIncidencia(incidencia))
                {
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        if (ActualizarIncidenciaBD(form.Incidencia))
                        {
                            CargarDatos();
                            MessageBox.Show("Incidencia actualizada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione una incidencia para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private int ObtenerIdEmpleadoPorIncidencia(int idIncidencia)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ID_Empleado FROM INCIDENCIA WHERE ID_Incidencia = @ID_Incidencia";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ID_Incidencia", idIncidencia);
                return Convert.ToInt32(command.ExecuteScalar());
            }
        }

        private void BorrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvIncidencias.SelectedRows.Count > 0)
            {
                int idIncidencia = Convert.ToInt32(dgvIncidencias.SelectedRows[0].Cells["ID_Incidencia"].Value);

                var confirm = MessageBox.Show("¿Está seguro de que desea borrar esta incidencia?",
                                            "Confirmar borrado",
                                            MessageBoxButtons.YesNo,
                                            MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    if (EliminarIncidenciaBD(idIncidencia))
                    {
                        CargarDatos();
                        MessageBox.Show("Incidencia eliminada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione una incidencia para borrar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private bool ActualizarIncidenciaBD(Incidencia incidencia)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"UPDATE INCIDENCIA 
                                   SET ID_Empleado = @ID_Empleado,
                                       Tipo = @Tipo, 
                                       Descripcion = @Descripcion, 
                                       Fecha = @Fecha, 
                                       Resuelta = @Resuelta
                                   WHERE ID_Incidencia = @ID_Incidencia";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Empleado", incidencia.ID_Empleado);
                    command.Parameters.AddWithValue("@Tipo", incidencia.Tipo);
                    command.Parameters.AddWithValue("@Descripcion", incidencia.Descripcion);
                    command.Parameters.AddWithValue("@Fecha", DateTime.ParseExact(incidencia.Fecha, "dd/MM/yyyy", null));
                    command.Parameters.AddWithValue("@Resuelta", incidencia.Resuelta);
                    command.Parameters.AddWithValue("@ID_Incidencia", incidencia.ID_Incidencia);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar incidencia: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private bool EliminarIncidenciaBD(int idIncidencia)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM INCIDENCIA WHERE ID_Incidencia = @ID_Incidencia";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Incidencia", idIncidencia);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar incidencia: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void imprimirToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IIncidencias(); // Asegurar que `Productos` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Informe_Incidencias{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }

    public class Incidencia
    {
        public int ID_Incidencia { get; set; }
        public int ID_Empleado { get; set; }
        public string Tipo { get; set; }
        public string Descripcion { get; set; }
        public string Fecha { get; set; }
        public bool Resuelta { get; set; }
    }
}