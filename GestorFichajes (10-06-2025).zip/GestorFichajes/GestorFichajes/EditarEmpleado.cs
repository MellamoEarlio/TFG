﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class EditarEmpleado : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        // ID del empleado a editar
        private int empleadoId;

        // Constructor de la clase EditarEmpleado
        public EditarEmpleado(int idEmpleado)
        {
            InitializeComponent();
            empleadoId = idEmpleado;
            CargarDepartamentos();
            CargarPuestos();
            CargarDatosEmpleado();
        }

        // Método para cargar los datos del empleado desde la base de datos
        private void CargarDatosEmpleado()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM EMPLEADO WHERE ID_Empleado = @id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", empleadoId);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Rellenar los controles con los datos del empleado
                            tb_name.Text = reader["Nombre"].ToString();
                            tb_ape.Text = reader["Apellidos"].ToString();
                            tb_dni.Text = reader["DNI_NIF"].ToString();
                            dtp_nacimiento.Value = Convert.ToDateTime(reader["Fecha_Nacimiento"]);
                            tb_address.Text = reader["Direccion"].ToString();
                            tb_phone.Text = reader["Telefono"].ToString();
                            tb_email.Text = reader["Email"].ToString();
                            tb_password.Text = reader["Contrasenia"].ToString();
                            dtp_contratacion.Value = Convert.ToDateTime(reader["Fecha_Contratacion"]);

                            // Establecer los valores de los ComboBox
                            comboBox_depart.SelectedItem = ObtenerNombreDepartamento((int)reader["ID_Departamento"]);
                            comboBox_puesto.SelectedItem = ObtenerNombrePuesto((int)reader["ID_Puesto"]);
                        }
                    }
                }
            }
        }

        // Método para obtener el nombre del departamento por su ID
        private string ObtenerNombreDepartamento(int id)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nombre FROM DEPARTAMENTO WHERE ID_Departamento = @id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    return cmd.ExecuteScalar()?.ToString();
                }
            }
        }

        // Método para obtener el nombre del puesto por su ID
        private string ObtenerNombrePuesto(int id)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nombre_Puesto FROM PUESTO WHERE ID_Puesto = @id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    return cmd.ExecuteScalar()?.ToString();
                }
            }
        }

        // Método para cargar los departamentos en el ComboBox
        private void CargarDepartamentos()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nombre FROM DEPARTAMENTO";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                        comboBox_depart.Items.Add(reader["Nombre"].ToString());
                }
            }
        }

        // Método para cargar los puestos en el ComboBox
        private void CargarPuestos()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nombre_Puesto FROM PUESTO";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                        comboBox_puesto.Items.Add(reader["Nombre_Puesto"].ToString());
                }
            }
        }

        // Método para manejar el evento de clic del botón Guardar
        private void bttn_guardar_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"UPDATE EMPLEADO SET
                                Nombre = @nombre,
                                Apellidos = @apellidos,
                                DNI_NIF = @dni,
                                Fecha_Nacimiento = @nac,
                                Direccion = @direccion,
                                Telefono = @tel,
                                Email = @email,
                                Contrasenia = @pass,
                                Fecha_Contratacion = @fc,
                                ID_Departamento = (SELECT ID_Departamento FROM DEPARTAMENTO WHERE Nombre = @depart),
                                ID_Puesto = (SELECT ID_Puesto FROM PUESTO WHERE Nombre_Puesto = @puesto)
                                WHERE ID_Empleado = @id";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nombre", tb_name.Text.Trim());
                    cmd.Parameters.AddWithValue("@apellidos", tb_ape.Text.Trim());
                    cmd.Parameters.AddWithValue("@dni", tb_dni.Text.Trim());
                    cmd.Parameters.AddWithValue("@nac", dtp_nacimiento.Value);
                    cmd.Parameters.AddWithValue("@direccion", tb_address.Text.Trim());
                    cmd.Parameters.AddWithValue("@tel", tb_phone.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", tb_email.Text.Trim());
                    cmd.Parameters.AddWithValue("@pass", tb_password.Text);
                    cmd.Parameters.AddWithValue("@fc", dtp_contratacion.Value);
                    cmd.Parameters.AddWithValue("@depart", comboBox_depart.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@puesto", comboBox_puesto.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@id", empleadoId);

                    int filas = cmd.ExecuteNonQuery();
                    if (filas > 0)
                        MessageBox.Show("Empleado actualizado correctamente.");
                    else
                        MessageBox.Show("Error al actualizar.");
                }
            }

            this.Close();
        }
    }
}