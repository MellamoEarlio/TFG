﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Ausencias : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Ausencias
        public Ausencias()
        {
            InitializeComponent();
            CargarDatos();
            ConfigurarDataGridView();
        }

        // Método para configurar el DataGridView
        private void ConfigurarDataGridView()
        {
            // Desactivar la generación automática de columnas
            dgvAusencias.AutoGenerateColumns = false;
            // Desactivar la adición y eliminación de filas por el usuario
            dgvAusencias.AllowUserToAddRows = false;
            dgvAusencias.AllowUserToDeleteRows = false;
            // Establecer el DataGridView como de solo lectura
            dgvAusencias.ReadOnly = true;
            // Configurar el modo de selección de filas
            dgvAusencias.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAusencias.MultiSelect = false;
            // Ajustar el tamaño de las columnas automáticamente
            dgvAusencias.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Añadir una columna oculta para el ID del empleado
            if (!dgvAusencias.Columns.Contains("ID_Empleado"))
            {
                DataGridViewTextBoxColumn colEmpleadoId = new DataGridViewTextBoxColumn
                {
                    Name = "ID_Empleado",
                    HeaderText = "ID Empleado",
                    DataPropertyName = "ID_Empleado",
                    Visible = false
                };
                dgvAusencias.Columns.Add(colEmpleadoId);
            }
        }

        // Método para cargar los datos de ausencias desde la base de datos
        public void CargarDatos()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Consultar los datos de ausencias y empleados relacionados
                    string query = @"
                    SELECT
                        e.Nombre + ' ' + e.Apellidos AS Empleado,
                        a.Tipo,
                        CONVERT(varchar, a.Fecha_Inicio, 103) AS Fecha_Inicio,
                        CASE
                            WHEN a.Fecha_Fin IS NULL THEN ''
                            ELSE CONVERT(varchar, a.Fecha_Fin, 103)
                        END AS Fecha_Fin,
                        CASE
                            WHEN a.Certificado = 1 THEN 'Sí'
                            ELSE 'No'
                        END AS Certificado,
                        ISNULL(a.Observaciones, '') AS Observaciones
                    FROM AUSENCIA a
                    INNER JOIN EMPLEADO e ON a.ID_Empleado = e.ID_Empleado
                    ORDER BY a.Fecha_Inicio DESC";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvAusencias.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las ausencias: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvAusencias.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una ausencia para ver.", "Advertencia",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow fila = dgvAusencias.SelectedRows[0];

            // Obtener los datos de la fila seleccionada
            int idAusencia = Convert.ToInt32(fila.Cells["ID_Ausencia"].Value);
            int idEmpleado = Convert.ToInt32(fila.Cells["ID_Empleado"].Value);
            string tipo = fila.Cells["Tipo"].Value.ToString();
            DateTime fechaInicio = DateTime.ParseExact(fila.Cells["Fecha_Inicio"].Value.ToString(), "dd/MM/yyyy", null);
            DateTime? fechaFin = string.IsNullOrWhiteSpace(fila.Cells["Fecha_Fin"].Value.ToString())
                ? (DateTime?)null
                : DateTime.ParseExact(fila.Cells["Fecha_Fin"].Value.ToString(), "dd/MM/yyyy", null);
            bool certificado = fila.Cells["Certificado"].Value.ToString() == "Sí";
            string observaciones = fila.Cells["Observaciones"].Value.ToString();

            // Abrir el formulario de edición de ausencias
            AEAusencias frm = new AEAusencias(idAusencia, idEmpleado, tipo, fechaInicio, fechaFin, certificado, observaciones);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                CargarDatos();
            }
        }

        // Método para manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvAusencias.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una ausencia para eliminar.", "Advertencia",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int idAusencia = Convert.ToInt32(dgvAusencias.SelectedRows[0].Cells["ID_Ausencia"].Value);
            string empleado = dgvAusencias.SelectedRows[0].Cells["Empleado"].Value.ToString();

            var confirm = MessageBox.Show(
                $"¿Está seguro de que desea eliminar la ausencia de {empleado}?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                if (EliminarAusenciaBD(idAusencia))
                {
                    MessageBox.Show("Ausencia eliminada correctamente.", "Éxito",
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarDatos();
                }
            }
        }

        // Método para eliminar una ausencia de la base de datos
        private bool EliminarAusenciaBD(int idAusencia)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM AUSENCIA WHERE ID_Ausencia = @ID_Ausencia";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID_Ausencia", idAusencia);
                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar la ausencia: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Método para manejar el evento de clic del menú "Actualizar"
        private void actualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CargarDatos();
        }

        // Método para manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IAusencias(); // Asegurar que `IAusencias` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Informe_Ausencias{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de visualización del informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}