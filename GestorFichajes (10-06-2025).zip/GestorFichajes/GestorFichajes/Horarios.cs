﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Horarios : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Horarios
        public Horarios()
        {
            InitializeComponent();
            CargarHorarios();
        }

        // Método para cargar los horarios desde la base de datos y mostrarlos en el DataGridView
        public void CargarHorarios()
        {
            dgvHorarios.Rows.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT h.ID_Horario, h.ID_Empleado, e.Nombre + ' ' + e.Apellidos AS NombreEmpleado,
                                    h.Dia_Semana, h.Hora_Entrada, h.Hora_Salida, h.Flexible
                                    FROM HORARIO h
                                    INNER JOIN EMPLEADO e ON h.ID_Empleado = e.ID_Empleado";

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        int fila = dgvHorarios.Rows.Add();
                        dgvHorarios.Rows[fila].Cells["ID_Horario"].Value = reader["ID_Horario"];
                        dgvHorarios.Rows[fila].Cells["ID_Empleado"].Value = reader["ID_Empleado"];
                        dgvHorarios.Rows[fila].Cells["NombreEmpleado"].Value = reader["NombreEmpleado"];
                        dgvHorarios.Rows[fila].Cells["Dia_Semana"].Value = reader["Dia_Semana"];
                        dgvHorarios.Rows[fila].Cells["Hora_Entrada"].Value = ((TimeSpan)reader["Hora_Entrada"]).ToString(@"hh\:mm");
                        dgvHorarios.Rows[fila].Cells["Hora_Salida"].Value = ((TimeSpan)reader["Hora_Salida"]).ToString(@"hh\:mm");
                        dgvHorarios.Rows[fila].Cells["Flexible"].Value = (bool)reader["Flexible"] ? "Sí" : "No";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar horarios: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Método para manejar el evento de clic del menú "Añadir"
        private void añadirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Lógica para añadir un nuevo horario
        }

        // Método para manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvHorarios.SelectedRows.Count > 0)
            {
                int idHorario = Convert.ToInt32(dgvHorarios.SelectedRows[0].Cells["ID_Horario"].Value);
                AEHorario editarForm = new AEHorario(idHorario); // Este formulario deberás crearlo
                if (editarForm.ShowDialog() == DialogResult.OK)
                {
                    CargarHorarios();
                    MessageBox.Show("Horario actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Seleccione un horario para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Método para manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvHorarios.SelectedRows.Count > 0)
            {
                int idHorario = Convert.ToInt32(dgvHorarios.SelectedRows[0].Cells["ID_Horario"].Value);

                var confirm = MessageBox.Show("¿Está seguro de que desea borrar este horario?",
                                              "Confirmar borrado",
                                              MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    if (EliminarHorarioBD(idHorario))
                    {
                        CargarHorarios();
                        MessageBox.Show("Horario eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione un horario para borrar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Método para eliminar un horario de la base de datos
        private bool EliminarHorarioBD(int idHorario)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM HORARIO WHERE ID_Horario = @ID_Horario";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Horario", idHorario);
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar horario: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Método para manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IHorarios(); // Asegurar que `IHorarios` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Listado_de_Horarios{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de visualización del informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}