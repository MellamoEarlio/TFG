﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Vacaciones : Form
    {
        // Cadena de conexión a la base de datos
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        // Constructor de la clase Vacaciones
        public Vacaciones()
        {
            InitializeComponent();
            // Cargar las vacaciones desde la base de datos al DataGridView
            CargarVacaciones();
        }

        // Método para cargar las vacaciones desde la base de datos
        private void CargarVacaciones()
        {
            dgvVacaciones.Rows.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"SELECT v.ID_Vacaciones, v.ID_Empleado, e.Nombre + ' ' + e.Apellidos AS NombreEmpleado,
                                v.Fecha_Inicio, v.Fecha_Fin, v.Estado, v.Motivo
                                FROM VACACIONES v
                                INNER JOIN EMPLEADO e ON v.ID_Empleado = e.ID_Empleado";

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                // Leer los resultados y añadir al DataGridView
                while (reader.Read())
                {
                    int fila = dgvVacaciones.Rows.Add();
                    dgvVacaciones.Rows[fila].Cells["ID_Vacaciones"].Value = reader["ID_Vacaciones"];
                    dgvVacaciones.Rows[fila].Cells["ID_Empleado"].Value = reader["ID_Empleado"];
                    dgvVacaciones.Rows[fila].Cells["Empleado"].Value = reader["NombreEmpleado"];
                    dgvVacaciones.Rows[fila].Cells["Fecha_Inicio"].Value = Convert.ToDateTime(reader["Fecha_Inicio"]).ToString("dd/MM/yyyy");
                    dgvVacaciones.Rows[fila].Cells["Fecha_Fin"].Value = Convert.ToDateTime(reader["Fecha_Fin"]).ToString("dd/MM/yyyy");
                    dgvVacaciones.Rows[fila].Cells["Estado"].Value = reader["Estado"];
                    dgvVacaciones.Rows[fila].Cells["Motivo"].Value = reader["Motivo"];
                }
            }
        }

        // Manejar el evento de clic del menú "Añadir"
        private void añadirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new AEVacaciones();
            if (form.ShowDialog() == DialogResult.OK)
            {
                // Recargar las vacaciones después de añadir un nuevo registro
                CargarVacaciones();
                MessageBox.Show("Vacaciones registradas correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Manejar el evento de clic del menú "Editar"
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvVacaciones.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una fila para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow fila = dgvVacaciones.SelectedRows[0];
            int idVacaciones = Convert.ToInt32(fila.Cells["ID_Vacaciones"].Value);

            var form = new AEVacaciones(
                idVacaciones,
                Convert.ToDateTime(fila.Cells["Fecha_Inicio"].Value),
                Convert.ToDateTime(fila.Cells["Fecha_Fin"].Value),
                fila.Cells["Estado"].Value.ToString(),
                fila.Cells["Motivo"].Value.ToString(),
                Convert.ToInt32(fila.Cells["ID_Empleado"].Value)
            );

            if (form.ShowDialog() == DialogResult.OK)
            {
                // Recargar las vacaciones después de editar un registro
                CargarVacaciones();
                MessageBox.Show("Vacaciones actualizadas.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Manejar el evento de clic del menú "Borrar"
        private void borrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvVacaciones.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una fila para borrar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int idVacaciones = Convert.ToInt32(dgvVacaciones.SelectedRows[0].Cells["ID_Vacaciones"].Value);

            var confirm = MessageBox.Show("¿Desea eliminar este registro de vacaciones?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM VACACIONES WHERE ID_Vacaciones = @id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", idVacaciones);
                    cmd.ExecuteNonQuery();
                }

                // Recargar las vacaciones después de eliminar un registro
                CargarVacaciones();
                MessageBox.Show("Registro eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Manejar el evento de clic del menú "Imprimir"
        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Crear el informe
                ReportDocument informe = new IVacaciones(); // Asegurar que `IVacaciones` hereda de `ReportDocument`

                // Ejecutar el informe
                ejecutarInforme(informe);
            }
            catch (Exception ex)
            {
                // Manejar la excepción (mostrar un mensaje de error, loggear, etc.)
                MessageBox.Show("Ocurrió un error al generar el informe: " + ex.Message);
            }
        }

        // Método para exportar el informe a un archivo PDF
        private void exportarInforme(ReportDocument informe)
        {
            try
            {
                string carpeta = "C:\\Informes exportados\\";
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                string fichero = $"Listado_de_Vacaciones{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.pdf";
                string rutaCompleta = Path.Combine(carpeta, fichero);

                informe.ExportToDisk(ExportFormatType.PortableDocFormat, rutaCompleta);
                MessageBox.Show($"Se ha exportado el informe a: {rutaCompleta}", "Exportación exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la exportación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para ejecutar el informe (exportar e imprimir)
        private void ejecutarInforme(ReportDocument informe)
        {
            exportarInforme(informe);
            abrirFormularioInforme(informe);
        }

        // Método para abrir el formulario de informe
        private void abrirFormularioInforme(ReportDocument informe)
        {
            using (FormImformes form = new FormImformes(informe)) // `using` asegura la liberación de recursos
            {
                form.ShowDialog();
            }
        }
    }
}