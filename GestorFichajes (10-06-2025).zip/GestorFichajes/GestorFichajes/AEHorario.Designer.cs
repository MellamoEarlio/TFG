﻿namespace GestorFichajes
{
    partial class AEHorario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxDia = new System.Windows.Forms.ComboBox();
            this.dTPEntrada = new System.Windows.Forms.DateTimePicker();
            this.dTPSalida = new System.Windows.Forms.DateTimePicker();
            this.comboBoxFlexible = new System.Windows.Forms.ComboBox();
            this.lblDiaSemana = new System.Windows.Forms.Label();
            this.lblHEntrada = new System.Windows.Forms.Label();
            this.lblHSalida = new System.Windows.Forms.Label();
            this.lblFlexible = new System.Windows.Forms.Label();
            this.bttnCancelar = new System.Windows.Forms.Button();
            this.bttnAceptar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // comboBoxDia
            // 
            this.comboBoxDia.FormattingEnabled = true;
            this.comboBoxDia.Location = new System.Drawing.Point(131, 36);
            this.comboBoxDia.Name = "comboBoxDia";
            this.comboBoxDia.Size = new System.Drawing.Size(121, 21);
            this.comboBoxDia.TabIndex = 0;
            // 
            // dTPEntrada
            // 
            this.dTPEntrada.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dTPEntrada.Location = new System.Drawing.Point(131, 67);
            this.dTPEntrada.Name = "dTPEntrada";
            this.dTPEntrada.Size = new System.Drawing.Size(121, 20);
            this.dTPEntrada.TabIndex = 1;
            // 
            // dTPSalida
            // 
            this.dTPSalida.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dTPSalida.Location = new System.Drawing.Point(131, 93);
            this.dTPSalida.Name = "dTPSalida";
            this.dTPSalida.Size = new System.Drawing.Size(121, 20);
            this.dTPSalida.TabIndex = 2;
            // 
            // comboBoxFlexible
            // 
            this.comboBoxFlexible.FormattingEnabled = true;
            this.comboBoxFlexible.Location = new System.Drawing.Point(131, 119);
            this.comboBoxFlexible.Name = "comboBoxFlexible";
            this.comboBoxFlexible.Size = new System.Drawing.Size(121, 21);
            this.comboBoxFlexible.TabIndex = 3;
            // 
            // lblDiaSemana
            // 
            this.lblDiaSemana.AutoSize = true;
            this.lblDiaSemana.Location = new System.Drawing.Point(36, 39);
            this.lblDiaSemana.Name = "lblDiaSemana";
            this.lblDiaSemana.Size = new System.Drawing.Size(89, 13);
            this.lblDiaSemana.TabIndex = 4;
            this.lblDiaSemana.Text = "Dia de la semana";
            // 
            // lblHEntrada
            // 
            this.lblHEntrada.AutoSize = true;
            this.lblHEntrada.Location = new System.Drawing.Point(36, 67);
            this.lblHEntrada.Name = "lblHEntrada";
            this.lblHEntrada.Size = new System.Drawing.Size(85, 13);
            this.lblHEntrada.TabIndex = 5;
            this.lblHEntrada.Text = "Hora de Entrada";
            // 
            // lblHSalida
            // 
            this.lblHSalida.AutoSize = true;
            this.lblHSalida.Location = new System.Drawing.Point(36, 93);
            this.lblHSalida.Name = "lblHSalida";
            this.lblHSalida.Size = new System.Drawing.Size(77, 13);
            this.lblHSalida.TabIndex = 6;
            this.lblHSalida.Text = "Hora de Salida";
            // 
            // lblFlexible
            // 
            this.lblFlexible.AutoSize = true;
            this.lblFlexible.Location = new System.Drawing.Point(36, 122);
            this.lblFlexible.Name = "lblFlexible";
            this.lblFlexible.Size = new System.Drawing.Size(42, 13);
            this.lblFlexible.TabIndex = 7;
            this.lblFlexible.Text = "Flexible";
            // 
            // bttnCancelar
            // 
            this.bttnCancelar.Location = new System.Drawing.Point(78, 161);
            this.bttnCancelar.Name = "bttnCancelar";
            this.bttnCancelar.Size = new System.Drawing.Size(75, 23);
            this.bttnCancelar.TabIndex = 8;
            this.bttnCancelar.Text = "Cancelar";
            this.bttnCancelar.UseVisualStyleBackColor = true;
            this.bttnCancelar.Click += new System.EventHandler(this.bttnCancelar_Click);
            // 
            // bttnAceptar
            // 
            this.bttnAceptar.Location = new System.Drawing.Point(177, 161);
            this.bttnAceptar.Name = "bttnAceptar";
            this.bttnAceptar.Size = new System.Drawing.Size(75, 23);
            this.bttnAceptar.TabIndex = 9;
            this.bttnAceptar.Text = "Aceptar";
            this.bttnAceptar.UseVisualStyleBackColor = true;
            this.bttnAceptar.Click += new System.EventHandler(this.bttnAceptar_Click);
            // 
            // AEHorario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 215);
            this.Controls.Add(this.bttnAceptar);
            this.Controls.Add(this.bttnCancelar);
            this.Controls.Add(this.lblFlexible);
            this.Controls.Add(this.lblHSalida);
            this.Controls.Add(this.lblHEntrada);
            this.Controls.Add(this.lblDiaSemana);
            this.Controls.Add(this.comboBoxFlexible);
            this.Controls.Add(this.dTPSalida);
            this.Controls.Add(this.dTPEntrada);
            this.Controls.Add(this.comboBoxDia);
            this.Name = "AEHorario";
            this.Text = "AEHorario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxDia;
        private System.Windows.Forms.DateTimePicker dTPEntrada;
        private System.Windows.Forms.DateTimePicker dTPSalida;
        private System.Windows.Forms.ComboBox comboBoxFlexible;
        private System.Windows.Forms.Label lblDiaSemana;
        private System.Windows.Forms.Label lblHEntrada;
        private System.Windows.Forms.Label lblHSalida;
        private System.Windows.Forms.Label lblFlexible;
        private System.Windows.Forms.Button bttnCancelar;
        private System.Windows.Forms.Button bttnAceptar;
    }
}