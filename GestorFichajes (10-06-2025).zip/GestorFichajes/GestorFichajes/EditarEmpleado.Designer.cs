﻿namespace GestorFichajes
{
    partial class EditarEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox_puesto = new System.Windows.Forms.ComboBox();
            this.comboBox_depart = new System.Windows.Forms.ComboBox();
            this.lbl_puesto = new System.Windows.Forms.Label();
            this.lbl_depart = new System.Windows.Forms.Label();
            this.lbl_contratacion = new System.Windows.Forms.Label();
            this.dtp_contratacion = new System.Windows.Forms.DateTimePicker();
            this.dtp_nacimiento = new System.Windows.Forms.DateTimePicker();
            this.lbl_password = new System.Windows.Forms.Label();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.tb_address = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_dni = new System.Windows.Forms.Label();
            this.tb_phone = new System.Windows.Forms.TextBox();
            this.lbl_birthday = new System.Windows.Forms.Label();
            this.tb_dni = new System.Windows.Forms.TextBox();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.tb_ape = new System.Windows.Forms.TextBox();
            this.lbl_ape = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.bttnAceptar = new System.Windows.Forms.Button();
            this.bttnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // comboBox_puesto
            // 
            this.comboBox_puesto.FormattingEnabled = true;
            this.comboBox_puesto.Location = new System.Drawing.Point(161, 290);
            this.comboBox_puesto.Name = "comboBox_puesto";
            this.comboBox_puesto.Size = new System.Drawing.Size(133, 21);
            this.comboBox_puesto.TabIndex = 52;
            // 
            // comboBox_depart
            // 
            this.comboBox_depart.FormattingEnabled = true;
            this.comboBox_depart.Location = new System.Drawing.Point(161, 264);
            this.comboBox_depart.Name = "comboBox_depart";
            this.comboBox_depart.Size = new System.Drawing.Size(133, 21);
            this.comboBox_depart.TabIndex = 51;
            // 
            // lbl_puesto
            // 
            this.lbl_puesto.AutoSize = true;
            this.lbl_puesto.Location = new System.Drawing.Point(81, 293);
            this.lbl_puesto.Name = "lbl_puesto";
            this.lbl_puesto.Size = new System.Drawing.Size(40, 13);
            this.lbl_puesto.TabIndex = 50;
            this.lbl_puesto.Text = "Puesto";
            // 
            // lbl_depart
            // 
            this.lbl_depart.AutoSize = true;
            this.lbl_depart.Location = new System.Drawing.Point(81, 267);
            this.lbl_depart.Name = "lbl_depart";
            this.lbl_depart.Size = new System.Drawing.Size(74, 13);
            this.lbl_depart.TabIndex = 49;
            this.lbl_depart.Text = "Departamento";
            // 
            // lbl_contratacion
            // 
            this.lbl_contratacion.AutoSize = true;
            this.lbl_contratacion.Location = new System.Drawing.Point(81, 237);
            this.lbl_contratacion.Name = "lbl_contratacion";
            this.lbl_contratacion.Size = new System.Drawing.Size(67, 26);
            this.lbl_contratacion.TabIndex = 48;
            this.lbl_contratacion.Text = "Fecha\r\nContratacion\r\n";
            // 
            // dtp_contratacion
            // 
            this.dtp_contratacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_contratacion.Location = new System.Drawing.Point(161, 237);
            this.dtp_contratacion.Name = "dtp_contratacion";
            this.dtp_contratacion.Size = new System.Drawing.Size(133, 20);
            this.dtp_contratacion.TabIndex = 43;
            this.dtp_contratacion.Value = new System.DateTime(2025, 5, 10, 0, 0, 0, 0);
            // 
            // dtp_nacimiento
            // 
            this.dtp_nacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_nacimiento.Location = new System.Drawing.Point(161, 107);
            this.dtp_nacimiento.Name = "dtp_nacimiento";
            this.dtp_nacimiento.Size = new System.Drawing.Size(133, 20);
            this.dtp_nacimiento.TabIndex = 37;
            this.dtp_nacimiento.Value = new System.DateTime(2025, 5, 10, 0, 0, 0, 0);
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(81, 214);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(61, 13);
            this.lbl_password.TabIndex = 47;
            this.lbl_password.Text = "Contraseña";
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(161, 211);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(133, 20);
            this.tb_password.TabIndex = 42;
            this.tb_password.UseSystemPasswordChar = true;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(161, 185);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(133, 20);
            this.tb_email.TabIndex = 41;
            // 
            // tb_address
            // 
            this.tb_address.Location = new System.Drawing.Point(161, 133);
            this.tb_address.Name = "tb_address";
            this.tb_address.Size = new System.Drawing.Size(133, 20);
            this.tb_address.TabIndex = 38;
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(81, 188);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(32, 13);
            this.lbl_email.TabIndex = 46;
            this.lbl_email.Text = "Email";
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Location = new System.Drawing.Point(81, 140);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(52, 13);
            this.lbl_address.TabIndex = 45;
            this.lbl_address.Text = "Direccion";
            // 
            // lbl_dni
            // 
            this.lbl_dni.AutoSize = true;
            this.lbl_dni.Location = new System.Drawing.Point(81, 84);
            this.lbl_dni.Name = "lbl_dni";
            this.lbl_dni.Size = new System.Drawing.Size(46, 13);
            this.lbl_dni.TabIndex = 44;
            this.lbl_dni.Text = "DNI NIF";
            // 
            // tb_phone
            // 
            this.tb_phone.Location = new System.Drawing.Point(161, 159);
            this.tb_phone.Name = "tb_phone";
            this.tb_phone.Size = new System.Drawing.Size(133, 20);
            this.tb_phone.TabIndex = 39;
            // 
            // lbl_birthday
            // 
            this.lbl_birthday.AutoSize = true;
            this.lbl_birthday.Location = new System.Drawing.Point(81, 107);
            this.lbl_birthday.Name = "lbl_birthday";
            this.lbl_birthday.Size = new System.Drawing.Size(60, 26);
            this.lbl_birthday.TabIndex = 40;
            this.lbl_birthday.Text = "Fecha\r\nNacimiento";
            // 
            // tb_dni
            // 
            this.tb_dni.Location = new System.Drawing.Point(161, 81);
            this.tb_dni.Name = "tb_dni";
            this.tb_dni.Size = new System.Drawing.Size(133, 20);
            this.tb_dni.TabIndex = 35;
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Location = new System.Drawing.Point(81, 162);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(49, 13);
            this.lbl_phone.TabIndex = 36;
            this.lbl_phone.Text = "Telefono";
            // 
            // tb_ape
            // 
            this.tb_ape.Location = new System.Drawing.Point(161, 55);
            this.tb_ape.Name = "tb_ape";
            this.tb_ape.Size = new System.Drawing.Size(133, 20);
            this.tb_ape.TabIndex = 34;
            // 
            // lbl_ape
            // 
            this.lbl_ape.AutoSize = true;
            this.lbl_ape.Location = new System.Drawing.Point(81, 55);
            this.lbl_ape.Name = "lbl_ape";
            this.lbl_ape.Size = new System.Drawing.Size(49, 13);
            this.lbl_ape.TabIndex = 33;
            this.lbl_ape.Text = "Apellidos";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(161, 32);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(133, 20);
            this.tb_name.TabIndex = 32;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(81, 32);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(44, 13);
            this.lbl_name.TabIndex = 31;
            this.lbl_name.Text = "Nombre";
            // 
            // bttnAceptar
            // 
            this.bttnAceptar.Location = new System.Drawing.Point(219, 336);
            this.bttnAceptar.Name = "bttnAceptar";
            this.bttnAceptar.Size = new System.Drawing.Size(75, 23);
            this.bttnAceptar.TabIndex = 30;
            this.bttnAceptar.Text = "Aceptar";
            this.bttnAceptar.UseVisualStyleBackColor = true;
            // 
            // bttnCancelar
            // 
            this.bttnCancelar.Location = new System.Drawing.Point(117, 336);
            this.bttnCancelar.Name = "bttnCancelar";
            this.bttnCancelar.Size = new System.Drawing.Size(75, 23);
            this.bttnCancelar.TabIndex = 53;
            this.bttnCancelar.Text = "Cancelar";
            this.bttnCancelar.UseVisualStyleBackColor = true;
            // 
            // EditarEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 371);
            this.Controls.Add(this.bttnCancelar);
            this.Controls.Add(this.comboBox_puesto);
            this.Controls.Add(this.comboBox_depart);
            this.Controls.Add(this.lbl_puesto);
            this.Controls.Add(this.lbl_depart);
            this.Controls.Add(this.lbl_contratacion);
            this.Controls.Add(this.dtp_contratacion);
            this.Controls.Add(this.dtp_nacimiento);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.tb_email);
            this.Controls.Add(this.tb_address);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.lbl_dni);
            this.Controls.Add(this.tb_phone);
            this.Controls.Add(this.lbl_birthday);
            this.Controls.Add(this.tb_dni);
            this.Controls.Add(this.lbl_phone);
            this.Controls.Add(this.tb_ape);
            this.Controls.Add(this.lbl_ape);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.bttnAceptar);
            this.Name = "EditarEmpleado";
            this.Text = "EditarEmpleado";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_puesto;
        private System.Windows.Forms.ComboBox comboBox_depart;
        private System.Windows.Forms.Label lbl_puesto;
        private System.Windows.Forms.Label lbl_depart;
        private System.Windows.Forms.Label lbl_contratacion;
        private System.Windows.Forms.DateTimePicker dtp_contratacion;
        private System.Windows.Forms.DateTimePicker dtp_nacimiento;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_dni;
        private System.Windows.Forms.TextBox tb_phone;
        private System.Windows.Forms.Label lbl_birthday;
        private System.Windows.Forms.TextBox tb_dni;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.TextBox tb_ape;
        private System.Windows.Forms.Label lbl_ape;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Button bttnAceptar;
        private System.Windows.Forms.Button bttnCancelar;
    }
}