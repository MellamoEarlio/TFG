﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Gestion_de_Incidencias : Form
    {
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";
        private List<Incidencia> incidencias = new List<Incidencia>();
        private int idEmpleadoActual; // Almacena el ID del empleado logueado

        // Modifica el constructor para recibir el ID del empleado
        public Gestion_de_Incidencias(int idEmpleado)
        {
            InitializeComponent();
            idEmpleadoActual = idEmpleado;
        }

        private void Gestion_de_Incidencias_Load(object sender, EventArgs e)
        {
            ConfigurarDataGridView();
            CargarDatosDesdeBD();
            ActualizarGrid();
        }

        private void ConfigurarDataGridView()
        {
            dgvIncidencias.AutoGenerateColumns = false;
            dgvIncidencias.Columns.Clear();

            // Añade columna de empleado
            dgvIncidencias.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "NombreEmpleado",
                HeaderText = "Empleado"
            });

            dgvIncidencias.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "Tipo",
                HeaderText = "Tipo"
            });

            dgvIncidencias.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "Descripcion",
                HeaderText = "Descripción"
            });

            dgvIncidencias.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "Fecha",
                HeaderText = "Fecha"
            });

            dgvIncidencias.Columns.Add(new DataGridViewTextBoxColumn()
            {
                DataPropertyName = "ResueltaTexto",
                HeaderText = "Resuelta"
            });
        }

        private void CargarDatosDesdeBD()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Consulta modificada para incluir el nombre del empleado
                    string query = @"SELECT i.ID_Incidencia, i.Tipo, i.Descripcion, i.Fecha, i.Resuelta, 
                                     e.Nombre + ' ' + e.Apellidos AS NombreEmpleado
                                     FROM INCIDENCIA i
                                     INNER JOIN EMPLEADO e ON i.ID_Empleado = e.ID_Empleado
                                     WHERE i.ID_Empleado = @ID_Empleado"; // Filtra por empleado

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Empleado", idEmpleadoActual);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    incidencias.Clear();

                    while (reader.Read())
                    {
                        incidencias.Add(new Incidencia
                        {
                            ID_Incidencia = Convert.ToInt32(reader["ID_Incidencia"]),
                            Tipo = reader["Tipo"].ToString(),
                            Descripcion = reader["Descripcion"].ToString(),
                            Fecha = Convert.ToDateTime(reader["Fecha"]).ToString("dd/MM/yyyy"),
                            Resuelta = Convert.ToBoolean(reader["Resuelta"]),
                            NombreEmpleado = reader["NombreEmpleado"].ToString()
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void ActualizarGrid()
        {
            dgvIncidencias.DataSource = null;
            dgvIncidencias.DataSource = incidencias;
        }

        private void añadirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var form = new EditarIncidencia())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    form.Incidencia.ID_Empleado = idEmpleadoActual; // Asigna el ID del empleado
                    if (InsertarIncidenciaBD(form.Incidencia))
                    {
                        CargarDatosDesdeBD();
                        ActualizarGrid();
                    }
                }
            }
        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvIncidencias.SelectedRows.Count > 0)
            {
                var incidenciaSeleccionada = (Incidencia)dgvIncidencias.SelectedRows[0].DataBoundItem;

                using (var form = new EditarIncidencia(incidenciaSeleccionada))
                {
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        form.Incidencia.ID_Empleado = idEmpleadoActual; // Mantiene el mismo empleado
                        if (ActualizarIncidenciaBD(form.Incidencia))
                        {
                            CargarDatosDesdeBD();
                            ActualizarGrid();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione una incidencia para editar.",
                              "Advertencia",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Warning);
            }
        }

        private void BorrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvIncidencias.SelectedRows.Count > 0)
            {
                var incidenciaSeleccionada = (Incidencia)dgvIncidencias.SelectedRows[0].DataBoundItem;

                var confirm = MessageBox.Show("¿Está seguro de que desea borrar esta incidencia?",
                                            "Confirmar borrado",
                                            MessageBoxButtons.YesNo,
                                            MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    if (EliminarIncidenciaBD(incidenciaSeleccionada.ID_Incidencia))
                    {
                        CargarDatosDesdeBD();
                        ActualizarGrid();
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione una incidencia para borrar.",
                              "Advertencia",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Warning);
            }
        }

        private bool InsertarIncidenciaBD(Incidencia incidencia)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"INSERT INTO INCIDENCIA (ID_Empleado, Tipo, Descripcion, Fecha, Resuelta) 
                                   VALUES (@ID_Empleado, @Tipo, @Descripcion, @Fecha, @Resuelta)";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Empleado", incidencia.ID_Empleado);
                    command.Parameters.AddWithValue("@Tipo", incidencia.Tipo);
                    command.Parameters.AddWithValue("@Descripcion", incidencia.Descripcion);
                    command.Parameters.AddWithValue("@Fecha", DateTime.ParseExact(incidencia.Fecha, "dd/MM/yyyy", null));
                    command.Parameters.AddWithValue("@Resuelta", incidencia.Resuelta);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar incidencia: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
                return false;
            }
        }

        private bool ActualizarIncidenciaBD(Incidencia incidencia)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"UPDATE INCIDENCIA 
                                   SET Tipo = @Tipo, 
                                       Descripcion = @Descripcion, 
                                       Fecha = @Fecha, 
                                       Resuelta = @Resuelta
                                   WHERE ID_Incidencia = @ID_Incidencia";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Tipo", incidencia.Tipo);
                    command.Parameters.AddWithValue("@Descripcion", incidencia.Descripcion);
                    command.Parameters.AddWithValue("@Fecha", DateTime.ParseExact(incidencia.Fecha, "dd/MM/yyyy", null));
                    command.Parameters.AddWithValue("@Resuelta", incidencia.Resuelta);
                    command.Parameters.AddWithValue("@ID_Incidencia", incidencia.ID_Incidencia);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar incidencia: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
                return false;
            }
        }

        private bool EliminarIncidenciaBD(int idIncidencia)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM INCIDENCIA WHERE ID_Incidencia = @ID_Incidencia";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_Incidencia", idIncidencia);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar incidencia: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
                return false;
            }
        }

        public class Incidencia
        {
            public int ID_Incidencia { get; set; }
            public int ID_Empleado { get; set; }
            public string NombreEmpleado { get; set; }
            public string Tipo { get; set; }
            public string Descripcion { get; set; }
            public string Fecha { get; set; }
            public bool Resuelta { get; set; }

            public string ResueltaTexto => Resuelta ? "Sí" : "No";
        }
    }
}