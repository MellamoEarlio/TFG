﻿namespace GestorFichajes
{
    partial class Gestor_de_la_APP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.empleadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empleadosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fichajesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horariosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.permisosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.puestoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vacacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incidenciasDeAusenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InformacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.empleadosToolStripMenuItem,
            this.incenciasToolStripMenuItem,
            this.InformacionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // empleadosToolStripMenuItem
            // 
            this.empleadosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.horariosToolStripMenuItem,
            this.departamentoToolStripMenuItem,
            this.empleadosToolStripMenuItem1,
            this.fichajesToolStripMenuItem,
            this.historialToolStripMenuItem,
            this.horariosToolStripMenuItem1,
            this.permisosToolStripMenuItem,
            this.puestoToolStripMenuItem,
            this.vacacionesToolStripMenuItem});
            this.empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
            this.empleadosToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.empleadosToolStripMenuItem.Text = "Empleados";
            // 
            // horariosToolStripMenuItem
            // 
            this.horariosToolStripMenuItem.Name = "horariosToolStripMenuItem";
            this.horariosToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.horariosToolStripMenuItem.Text = "Ausencias";
            // 
            // departamentoToolStripMenuItem
            // 
            this.departamentoToolStripMenuItem.Name = "departamentoToolStripMenuItem";
            this.departamentoToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.departamentoToolStripMenuItem.Text = "Departamento";
            // 
            // empleadosToolStripMenuItem1
            // 
            this.empleadosToolStripMenuItem1.Name = "empleadosToolStripMenuItem1";
            this.empleadosToolStripMenuItem1.Size = new System.Drawing.Size(150, 22);
            this.empleadosToolStripMenuItem1.Text = "Empleados";
            // 
            // fichajesToolStripMenuItem
            // 
            this.fichajesToolStripMenuItem.Name = "fichajesToolStripMenuItem";
            this.fichajesToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.fichajesToolStripMenuItem.Text = "Fichajes";
            // 
            // historialToolStripMenuItem
            // 
            this.historialToolStripMenuItem.Name = "historialToolStripMenuItem";
            this.historialToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.historialToolStripMenuItem.Text = "Historial ";
            // 
            // horariosToolStripMenuItem1
            // 
            this.horariosToolStripMenuItem1.Name = "horariosToolStripMenuItem1";
            this.horariosToolStripMenuItem1.Size = new System.Drawing.Size(150, 22);
            this.horariosToolStripMenuItem1.Text = "Horarios";
            // 
            // permisosToolStripMenuItem
            // 
            this.permisosToolStripMenuItem.Name = "permisosToolStripMenuItem";
            this.permisosToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.permisosToolStripMenuItem.Text = "Permisos";
            // 
            // puestoToolStripMenuItem
            // 
            this.puestoToolStripMenuItem.Name = "puestoToolStripMenuItem";
            this.puestoToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.puestoToolStripMenuItem.Text = "Puesto";
            // 
            // vacacionesToolStripMenuItem
            // 
            this.vacacionesToolStripMenuItem.Name = "vacacionesToolStripMenuItem";
            this.vacacionesToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.vacacionesToolStripMenuItem.Text = "Vacaciones";
            // 
            // incenciasToolStripMenuItem
            // 
            this.incenciasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.incidenciasDeAusenciasToolStripMenuItem});
            this.incenciasToolStripMenuItem.Name = "incenciasToolStripMenuItem";
            this.incenciasToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.incenciasToolStripMenuItem.Text = "Incencias";
            // 
            // incidenciasDeAusenciasToolStripMenuItem
            // 
            this.incidenciasDeAusenciasToolStripMenuItem.Name = "incidenciasDeAusenciasToolStripMenuItem";
            this.incidenciasDeAusenciasToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.incidenciasDeAusenciasToolStripMenuItem.Text = "Listado de incidencias";
            this.incidenciasDeAusenciasToolStripMenuItem.Click += new System.EventHandler(this.incidenciasDeAusenciasToolStripMenuItem_Click);
            // 
            // InformacionToolStripMenuItem
            // 
            this.InformacionToolStripMenuItem.Name = "InformacionToolStripMenuItem";
            this.InformacionToolStripMenuItem.Size = new System.Drawing.Size(159, 20);
            this.InformacionToolStripMenuItem.Text = "Informacion del empleado";
            this.InformacionToolStripMenuItem.Click += new System.EventHandler(this.InformacionToolStripMenuItem_Click);
            // 
            // Gestor_de_la_APP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Gestor_de_la_APP";
            this.Text = "Gestor_de_la_APP";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem empleadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem departamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empleadosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fichajesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horariosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem permisosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem puestoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vacacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incidenciasDeAusenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InformacionToolStripMenuItem;
    }
}