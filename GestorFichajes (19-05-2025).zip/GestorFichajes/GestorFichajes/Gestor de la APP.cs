﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Gestor_de_la_APP : Form
    {
        private int idEmpleado; // Variable para almacenar el ID del empleado
        public Gestor_de_la_APP(int empleadoId)
        {
            InitializeComponent();
            this.idEmpleado = empleadoId;
        }

        private void InformacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ajustes ajustes = new Ajustes(idEmpleado);
            ajustes.ShowDialog();
        }

        private void incidenciasDeAusenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Gestion_de_Incidencias gestionIncidencias = new Gestion_de_Incidencias();
            gestionIncidencias.ShowDialog();
        }
    }
}
