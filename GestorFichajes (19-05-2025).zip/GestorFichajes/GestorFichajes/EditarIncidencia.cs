﻿using System;
using System.Windows.Forms;
using static GestorFichajes.Gestion_de_Incidencias;

namespace GestorFichajes
{
    public partial class EditarIncidencia : Form
    {
        public Incidencia Incidencia { get; private set; }

        // Constructor para nueva incidencia
        public EditarIncidencia()
        {
            InitializeComponent();
            Incidencia = new Incidencia();
            comboboxResuelta.Items.AddRange(new object[] { "Sí", "No" });
        }

        // Constructor para editar incidencia existente
        public EditarIncidencia(Incidencia incidencia) : this()
        {
            if (incidencia != null)
            {
                tbTipo.Text = incidencia.Tipo;
                tbDescripcion.Text = incidencia.Descripcion;

                if (DateTime.TryParseExact(incidencia.Fecha, "dd/MM/yyyy", null,
                    System.Globalization.DateTimeStyles.None, out DateTime fecha))
                {
                    dtpFecha.Value = fecha;
                }

                comboboxResuelta.SelectedItem = incidencia.Resuelta ? "Sí" : "No";
                Incidencia = incidencia;
            }
        }

        private void bttnAceptar_Click(object sender, EventArgs e)
        {
            if (ValidarDatos())
            {
                Incidencia.Tipo = tbTipo.Text;
                Incidencia.Descripcion = tbDescripcion.Text;
                Incidencia.Fecha = dtpFecha.Value.ToString("dd/MM/yyyy");
                Incidencia.Resuelta = comboboxResuelta.SelectedItem.ToString() == "Sí";

                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private bool ValidarDatos()
        {
            if (string.IsNullOrWhiteSpace(tbTipo.Text))
            {
                MessageBox.Show("Debe especificar un tipo de incidencia",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbDescripcion.Text))
            {
                MessageBox.Show("Debe ingresar una descripción",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }

            if (comboboxResuelta.SelectedItem == null)
            {
                MessageBox.Show("Debe seleccionar si la incidencia está resuelta",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}