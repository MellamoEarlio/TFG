﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Gestor_de_la_APP : Form
    {
        public Gestor_de_la_APP()
        {
            InitializeComponent();
        }
    }
}
