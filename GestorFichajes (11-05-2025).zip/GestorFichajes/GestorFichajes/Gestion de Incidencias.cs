﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Gestion_de_Incidencias : Form
    {
        public Gestion_de_Incidencias()
        {
            InitializeComponent();
        }
    }
}
