﻿namespace GestorFichajes
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_nocuenta = new System.Windows.Forms.Label();
            this.bttn_login = new System.Windows.Forms.Button();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.tb_user = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_puesto = new System.Windows.Forms.Label();
            this.lbl_depart = new System.Windows.Forms.Label();
            this.lbl_contratacion = new System.Windows.Forms.Label();
            this.tb_puesto = new System.Windows.Forms.TextBox();
            this.dtp_contratacion = new System.Windows.Forms.DateTimePicker();
            this.dtp_nacimiento = new System.Windows.Forms.DateTimePicker();
            this.lbl_password = new System.Windows.Forms.Label();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.tb_address = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_dni = new System.Windows.Forms.Label();
            this.lbl_sicuenta = new System.Windows.Forms.Label();
            this.tb_depart = new System.Windows.Forms.TextBox();
            this.tb_phone = new System.Windows.Forms.TextBox();
            this.lbl_birthday = new System.Windows.Forms.Label();
            this.tb_dni = new System.Windows.Forms.TextBox();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.tb_ape = new System.Windows.Forms.TextBox();
            this.lbl_ape = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.bttn_signin = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbl_nocuenta);
            this.panel1.Controls.Add(this.bttn_login);
            this.panel1.Controls.Add(this.tb_pass);
            this.panel1.Controls.Add(this.tb_user);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lbl_nombre);
            this.panel1.Location = new System.Drawing.Point(73, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(281, 158);
            this.panel1.TabIndex = 0;
            // 
            // lbl_nocuenta
            // 
            this.lbl_nocuenta.AutoSize = true;
            this.lbl_nocuenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nocuenta.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.lbl_nocuenta.Location = new System.Drawing.Point(108, 127);
            this.lbl_nocuenta.Name = "lbl_nocuenta";
            this.lbl_nocuenta.Size = new System.Drawing.Size(102, 13);
            this.lbl_nocuenta.TabIndex = 5;
            this.lbl_nocuenta.Text = "No tengo cuenta";
            this.lbl_nocuenta.Click += new System.EventHandler(this.lbl_nocuenta_Click);
            // 
            // bttn_login
            // 
            this.bttn_login.Location = new System.Drawing.Point(124, 99);
            this.bttn_login.Name = "bttn_login";
            this.bttn_login.Size = new System.Drawing.Size(75, 23);
            this.bttn_login.TabIndex = 4;
            this.bttn_login.Text = "Login";
            this.bttn_login.UseVisualStyleBackColor = true;
            this.bttn_login.Click += new System.EventHandler(this.bttn_login_Click);
            // 
            // tb_pass
            // 
            this.tb_pass.Location = new System.Drawing.Point(100, 73);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.Size = new System.Drawing.Size(133, 20);
            this.tb_pass.TabIndex = 3;
            // 
            // tb_user
            // 
            this.tb_user.Location = new System.Drawing.Point(100, 42);
            this.tb_user.Name = "tb_user";
            this.tb_user.Size = new System.Drawing.Size(133, 20);
            this.tb_user.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Contraseña";
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Location = new System.Drawing.Point(24, 42);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(54, 26);
            this.lbl_nombre.TabIndex = 0;
            this.lbl_nombre.Text = "Nombre\r\nEmpleado";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl_puesto);
            this.panel2.Controls.Add(this.lbl_depart);
            this.panel2.Controls.Add(this.lbl_contratacion);
            this.panel2.Controls.Add(this.tb_puesto);
            this.panel2.Controls.Add(this.dtp_contratacion);
            this.panel2.Controls.Add(this.dtp_nacimiento);
            this.panel2.Controls.Add(this.lbl_password);
            this.panel2.Controls.Add(this.tb_password);
            this.panel2.Controls.Add(this.tb_email);
            this.panel2.Controls.Add(this.tb_address);
            this.panel2.Controls.Add(this.lbl_email);
            this.panel2.Controls.Add(this.lbl_address);
            this.panel2.Controls.Add(this.lbl_dni);
            this.panel2.Controls.Add(this.lbl_sicuenta);
            this.panel2.Controls.Add(this.tb_depart);
            this.panel2.Controls.Add(this.tb_phone);
            this.panel2.Controls.Add(this.lbl_birthday);
            this.panel2.Controls.Add(this.tb_dni);
            this.panel2.Controls.Add(this.lbl_phone);
            this.panel2.Controls.Add(this.tb_ape);
            this.panel2.Controls.Add(this.lbl_ape);
            this.panel2.Controls.Add(this.tb_name);
            this.panel2.Controls.Add(this.lbl_name);
            this.panel2.Controls.Add(this.bttn_signin);
            this.panel2.Location = new System.Drawing.Point(379, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(347, 349);
            this.panel2.TabIndex = 5;
            this.panel2.Visible = false;
            // 
            // lbl_puesto
            // 
            this.lbl_puesto.AutoSize = true;
            this.lbl_puesto.Location = new System.Drawing.Point(44, 273);
            this.lbl_puesto.Name = "lbl_puesto";
            this.lbl_puesto.Size = new System.Drawing.Size(40, 13);
            this.lbl_puesto.TabIndex = 27;
            this.lbl_puesto.Text = "Puesto";
            // 
            // lbl_depart
            // 
            this.lbl_depart.AutoSize = true;
            this.lbl_depart.Location = new System.Drawing.Point(44, 247);
            this.lbl_depart.Name = "lbl_depart";
            this.lbl_depart.Size = new System.Drawing.Size(74, 13);
            this.lbl_depart.TabIndex = 26;
            this.lbl_depart.Text = "Departamento";
            // 
            // lbl_contratacion
            // 
            this.lbl_contratacion.AutoSize = true;
            this.lbl_contratacion.Location = new System.Drawing.Point(44, 217);
            this.lbl_contratacion.Name = "lbl_contratacion";
            this.lbl_contratacion.Size = new System.Drawing.Size(67, 26);
            this.lbl_contratacion.TabIndex = 25;
            this.lbl_contratacion.Text = "Fecha\r\nContratacion\r\n";
            // 
            // tb_puesto
            // 
            this.tb_puesto.Location = new System.Drawing.Point(124, 270);
            this.tb_puesto.Name = "tb_puesto";
            this.tb_puesto.Size = new System.Drawing.Size(133, 20);
            this.tb_puesto.TabIndex = 16;
            // 
            // dtp_contratacion
            // 
            this.dtp_contratacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_contratacion.Location = new System.Drawing.Point(124, 217);
            this.dtp_contratacion.Name = "dtp_contratacion";
            this.dtp_contratacion.Size = new System.Drawing.Size(133, 20);
            this.dtp_contratacion.TabIndex = 14;
            this.dtp_contratacion.Value = new System.DateTime(2025, 5, 10, 0, 0, 0, 0);
            // 
            // dtp_nacimiento
            // 
            this.dtp_nacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_nacimiento.Location = new System.Drawing.Point(124, 87);
            this.dtp_nacimiento.Name = "dtp_nacimiento";
            this.dtp_nacimiento.Size = new System.Drawing.Size(133, 20);
            this.dtp_nacimiento.TabIndex = 9;
            this.dtp_nacimiento.Value = new System.DateTime(2025, 5, 10, 0, 0, 0, 0);
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(44, 194);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(61, 13);
            this.lbl_password.TabIndex = 21;
            this.lbl_password.Text = "Contraseña";
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(124, 191);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(133, 20);
            this.tb_password.TabIndex = 13;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(124, 165);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(133, 20);
            this.tb_email.TabIndex = 12;
            // 
            // tb_address
            // 
            this.tb_address.Location = new System.Drawing.Point(124, 113);
            this.tb_address.Name = "tb_address";
            this.tb_address.Size = new System.Drawing.Size(133, 20);
            this.tb_address.TabIndex = 10;
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(44, 168);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(32, 13);
            this.lbl_email.TabIndex = 18;
            this.lbl_email.Text = "Email";
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Location = new System.Drawing.Point(44, 120);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(52, 13);
            this.lbl_address.TabIndex = 17;
            this.lbl_address.Text = "Direccion";
            // 
            // lbl_dni
            // 
            this.lbl_dni.AutoSize = true;
            this.lbl_dni.Location = new System.Drawing.Point(44, 64);
            this.lbl_dni.Name = "lbl_dni";
            this.lbl_dni.Size = new System.Drawing.Size(46, 13);
            this.lbl_dni.TabIndex = 16;
            this.lbl_dni.Text = "DNI NIF";
            // 
            // lbl_sicuenta
            // 
            this.lbl_sicuenta.AutoSize = true;
            this.lbl_sicuenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sicuenta.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.lbl_sicuenta.Location = new System.Drawing.Point(134, 322);
            this.lbl_sicuenta.Name = "lbl_sicuenta";
            this.lbl_sicuenta.Size = new System.Drawing.Size(101, 13);
            this.lbl_sicuenta.TabIndex = 15;
            this.lbl_sicuenta.Text = "Ya tengo cuenta";
            this.lbl_sicuenta.Click += new System.EventHandler(this.lbl_sicuenta_Click);
            // 
            // tb_depart
            // 
            this.tb_depart.Location = new System.Drawing.Point(124, 244);
            this.tb_depart.Name = "tb_depart";
            this.tb_depart.Size = new System.Drawing.Size(133, 20);
            this.tb_depart.TabIndex = 15;
            // 
            // tb_phone
            // 
            this.tb_phone.Location = new System.Drawing.Point(124, 139);
            this.tb_phone.Name = "tb_phone";
            this.tb_phone.Size = new System.Drawing.Size(133, 20);
            this.tb_phone.TabIndex = 11;
            // 
            // lbl_birthday
            // 
            this.lbl_birthday.AutoSize = true;
            this.lbl_birthday.Location = new System.Drawing.Point(44, 87);
            this.lbl_birthday.Name = "lbl_birthday";
            this.lbl_birthday.Size = new System.Drawing.Size(60, 26);
            this.lbl_birthday.TabIndex = 11;
            this.lbl_birthday.Text = "Fecha\r\nNacimiento";
            // 
            // tb_dni
            // 
            this.tb_dni.Location = new System.Drawing.Point(124, 61);
            this.tb_dni.Name = "tb_dni";
            this.tb_dni.Size = new System.Drawing.Size(133, 20);
            this.tb_dni.TabIndex = 8;
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Location = new System.Drawing.Point(44, 142);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(49, 13);
            this.lbl_phone.TabIndex = 9;
            this.lbl_phone.Text = "Telefono";
            // 
            // tb_ape
            // 
            this.tb_ape.Location = new System.Drawing.Point(124, 35);
            this.tb_ape.Name = "tb_ape";
            this.tb_ape.Size = new System.Drawing.Size(133, 20);
            this.tb_ape.TabIndex = 7;
            // 
            // lbl_ape
            // 
            this.lbl_ape.AutoSize = true;
            this.lbl_ape.Location = new System.Drawing.Point(44, 35);
            this.lbl_ape.Name = "lbl_ape";
            this.lbl_ape.Size = new System.Drawing.Size(49, 13);
            this.lbl_ape.TabIndex = 7;
            this.lbl_ape.Text = "Apellidos";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(124, 9);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(133, 20);
            this.tb_name.TabIndex = 6;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(44, 12);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(44, 13);
            this.lbl_name.TabIndex = 5;
            this.lbl_name.Text = "Nombre";
            // 
            // bttn_signin
            // 
            this.bttn_signin.Location = new System.Drawing.Point(150, 296);
            this.bttn_signin.Name = "bttn_signin";
            this.bttn_signin.Size = new System.Drawing.Size(75, 23);
            this.bttn_signin.TabIndex = 0;
            this.bttn_signin.Text = "Registrar";
            this.bttn_signin.UseVisualStyleBackColor = true;
            this.bttn_signin.Click += new System.EventHandler(this.bttn_signin_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Login";
            this.Text = "Login";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bttn_login;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.TextBox tb_user;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_nocuenta;
        private System.Windows.Forms.TextBox tb_depart;
        private System.Windows.Forms.TextBox tb_phone;
        private System.Windows.Forms.Label lbl_birthday;
        private System.Windows.Forms.TextBox tb_dni;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.TextBox tb_ape;
        private System.Windows.Forms.Label lbl_ape;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Button bttn_signin;
        private System.Windows.Forms.Label lbl_sicuenta;
        private System.Windows.Forms.Label lbl_dni;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.DateTimePicker dtp_contratacion;
        private System.Windows.Forms.DateTimePicker dtp_nacimiento;
        private System.Windows.Forms.Label lbl_puesto;
        private System.Windows.Forms.Label lbl_depart;
        private System.Windows.Forms.Label lbl_contratacion;
        private System.Windows.Forms.TextBox tb_puesto;
    }
}