﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Login : Form
    {
        private readonly string connectionString = @"Server=(LocalDB)\MSSQLLocalDB;Database=FichAPP;Integrated Security=True";

        public Login()
        {
            InitializeComponent();
        }

        private void bttn_login_Click(object sender, EventArgs e)
        {
            string usuarioIngresado = tb_user.Text;
            string contraseñaIngresada = tb_pass.Text;

            if (ValidarCredenciales(usuarioIngresado, contraseñaIngresada))
            {
                MessageBox.Show($"Bienvenido, {NombreEmpleado}.");
                this.Hide();

                // Preguntar al usuario dónde quiere entrar
                DialogResult resultado = MessageBox.Show("¿Deseas entrar en Gestor de la APP?",
                                                         "Selecciona destino",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    Gestor_de_la_APP gestor = new Gestor_de_la_APP();
                    gestor.Show();
                }
                else
                {
                    Main main = new Main(NombreEmpleado, PuestoEmpleado);
                    main.Show();
                }
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.");
            }
        }


        private void bttn_signin_Click(object sender, EventArgs e)
        {
            string nombre = tb_name.Text;
            string apellidos = tb_ape.Text;
            string dniNif = tb_dni.Text;
            DateTime fechaNacimiento = dtp_nacimiento.Value;
            string direccion = tb_address.Text;
            string telefono = tb_phone.Text;
            string email = tb_email.Text;
            string contraseña = tb_password.Text;
            DateTime fechaContratacion = dtp_contratacion.Value;

            // El usuario ingresa los nombres del departamento y puesto
            string nombreDepartamento = tb_depart.Text;
            string nombrePuesto = tb_puesto.Text;

            // Buscar los IDs en la base de datos
            int idDepartamento = ObtenerIdDepartamento(nombreDepartamento);
            int idPuesto = ObtenerIdPuesto(nombrePuesto);

            if (idDepartamento == -1 || idPuesto == -1)
            {
                MessageBox.Show("Error: Departamento o puesto no encontrados.");
                return;
            }

            if (RegistrarUsuario(nombre, apellidos, dniNif, fechaNacimiento, direccion, telefono, email, contraseña, fechaContratacion, idDepartamento, idPuesto))
            {
                MessageBox.Show("Registro exitoso.");
                this.Hide();

                Main main = new Main(NombreEmpleado,PuestoEmpleado);
                main.ShowDialog();
            }
            else
            {
                MessageBox.Show("Error al registrar el usuario.");
            }
        }

        public static string NombreEmpleado { get; private set; } // Variable estática para almacenar el nombre
        public static int PuestoEmpleado { get; private set; } // Variable estática para almacenar el puesto

        private bool ValidarCredenciales(string usuario, string contraseña)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nombre, ID_Puesto FROM EMPLEADO WHERE Nombre = @usuario AND Contrasenia = @contraseña";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@usuario", usuario);
                    cmd.Parameters.AddWithValue("@contraseña", contraseña);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            NombreEmpleado = reader["Nombre"].ToString();
                            PuestoEmpleado = Convert.ToInt32(reader["ID_Puesto"]); // Convertir a int
                            return true;
                        }
                        else
                        {
                            MessageBox.Show("Usuario o contraseña incorrectos.");
                            return false;
                        }
                    }
                }
            }
        }

        private bool RegistrarUsuario(string nombre, string apellidos, string dniNif, DateTime fechaNacimiento, string direccion, string telefono, string email, string contraseña, DateTime fechaContratacion, int idDepartamento, int idPuesto)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO EMPLEADO (Nombre, Apellidos, DNI_NIF, Fecha_Nacimiento, Direccion, Telefono, Email, Contrasenia, Fecha_Contratacion, ID_Departamento, ID_Puesto) VALUES (@nombre, @apellidos, @dniNif, @fechaNacimiento, @direccion, @telefono, @email, @contrasenia, @fechaContratacion, @idDepartamento, @idPuesto)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@apellidos", apellidos);
                    cmd.Parameters.AddWithValue("@dniNif", dniNif);
                    cmd.Parameters.AddWithValue("@fechaNacimiento", fechaNacimiento);
                    cmd.Parameters.AddWithValue("@direccion", direccion);
                    cmd.Parameters.AddWithValue("@telefono", telefono);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@contrasenia", contraseña);
                    cmd.Parameters.AddWithValue("@fechaContratacion", fechaContratacion);
                    cmd.Parameters.AddWithValue("@idDepartamento", idDepartamento);
                    cmd.Parameters.AddWithValue("@idPuesto", idPuesto);

                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Buscar el ID del departamento usando su nombre
        private int ObtenerIdDepartamento(string nombreDepartamento)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Departamento FROM DEPARTAMENTO WHERE Nombre = @nombreDepartamento";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nombreDepartamento", nombreDepartamento);
                    object result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1; // Si no se encuentra, devuelve -1
                }
            }
        }

        // Buscar el ID del puesto usando su nombre
        private int ObtenerIdPuesto(string nombrePuesto)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID_Puesto FROM PUESTO WHERE Nombre_Puesto = @nombrePuesto";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nombrePuesto", nombrePuesto);
                    object result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1; // Si no se encuentra, devuelve -1
                }
            }
        }

        private void lbl_nocuenta_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }

        private void lbl_sicuenta_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }
    }
}
