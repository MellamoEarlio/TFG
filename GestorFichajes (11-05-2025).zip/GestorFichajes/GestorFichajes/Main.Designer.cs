﻿namespace GestorFichajes
{
    partial class Main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bttnStart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblTiempo = new System.Windows.Forms.Label();
            this.lblRetraso = new System.Windows.Forms.Label();
            this.lblInactivo = new System.Windows.Forms.Label();
            this.lbl_empleado = new System.Windows.Forms.Label();
            this.bttnUser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bttnStart
            // 
            this.bttnStart.BackColor = System.Drawing.Color.Green;
            this.bttnStart.FlatAppearance.BorderSize = 0;
            this.bttnStart.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnStart.ForeColor = System.Drawing.Color.Transparent;
            this.bttnStart.Location = new System.Drawing.Point(337, 244);
            this.bttnStart.Name = "bttnStart";
            this.bttnStart.Size = new System.Drawing.Size(284, 101);
            this.bttnStart.TabIndex = 0;
            this.bttnStart.Text = "INICIAR JORNADA\r\nDE TRABAJO";
            this.bttnStart.UseVisualStyleBackColor = false;
            this.bttnStart.Click += new System.EventHandler(this.bttnStart_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Arial", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(379, 77);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bienvenido";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblTiempo
            // 
            this.lblTiempo.AutoSize = true;
            this.lblTiempo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTiempo.Location = new System.Drawing.Point(255, 180);
            this.lblTiempo.Name = "lblTiempo";
            this.lblTiempo.Size = new System.Drawing.Size(0, 25);
            this.lblTiempo.TabIndex = 3;
            // 
            // lblRetraso
            // 
            this.lblRetraso.AutoSize = true;
            this.lblRetraso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRetraso.Location = new System.Drawing.Point(621, 96);
            this.lblRetraso.Name = "lblRetraso";
            this.lblRetraso.Size = new System.Drawing.Size(0, 25);
            this.lblRetraso.TabIndex = 4;
            // 
            // lblInactivo
            // 
            this.lblInactivo.AutoSize = true;
            this.lblInactivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInactivo.Location = new System.Drawing.Point(596, 139);
            this.lblInactivo.Name = "lblInactivo";
            this.lblInactivo.Size = new System.Drawing.Size(0, 25);
            this.lblInactivo.TabIndex = 5;
            // 
            // lbl_empleado
            // 
            this.lbl_empleado.AutoSize = true;
            this.lbl_empleado.BackColor = System.Drawing.Color.Transparent;
            this.lbl_empleado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empleado.Location = new System.Drawing.Point(822, 26);
            this.lbl_empleado.Name = "lbl_empleado";
            this.lbl_empleado.Size = new System.Drawing.Size(112, 25);
            this.lbl_empleado.TabIndex = 6;
            this.lbl_empleado.Text = "@usuario";
            // 
            // bttnUser
            // 
            this.bttnUser.BackColor = System.Drawing.Color.Transparent;
            this.bttnUser.BackgroundImage = global::GestorFichajes.Properties.Resources.Icono_de_usuario;
            this.bttnUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bttnUser.FlatAppearance.BorderSize = 0;
            this.bttnUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttnUser.Location = new System.Drawing.Point(779, 21);
            this.bttnUser.Name = "bttnUser";
            this.bttnUser.Size = new System.Drawing.Size(38, 41);
            this.bttnUser.TabIndex = 2;
            this.bttnUser.UseVisualStyleBackColor = false;
            this.bttnUser.Click += new System.EventHandler(this.bttnUser_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GestorFichajes.Properties.Resources.VeniceAI_fV6KlWo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(966, 526);
            this.Controls.Add(this.lbl_empleado);
            this.Controls.Add(this.lblInactivo);
            this.Controls.Add(this.lblRetraso);
            this.Controls.Add(this.lblTiempo);
            this.Controls.Add(this.bttnUser);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bttnStart);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "FichAPP";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttnStart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttnUser;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTiempo;
        private System.Windows.Forms.Label lblRetraso;
        private System.Windows.Forms.Label lblInactivo;
        private System.Windows.Forms.Label lbl_empleado;
    }
}

