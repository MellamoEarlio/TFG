﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace GestorFichajes
{
    public partial class Main : Form
    {
        private Timer timer;
        private Timer inactividadTimer;
        private DateTime entradaEsperada = DateTime.Today.AddHours(7);
        private DateTime entradaReal;
        private DateTime salida;
        private TimeSpan tiempoTrabajado = TimeSpan.Zero;
        private TimeSpan tiempoInactivo = TimeSpan.Zero;
        private TimeSpan retraso = TimeSpan.Zero;
        private int cantidadPausas = 0;
        private bool isRunning = false;
        private bool isInactive = false;
        private DateTime startTime;
        private DateTime pausaInicio;
        private bool primeraVez = true;

        public Main()
        {
            InitializeComponent();

            // Configuración del Timer principal
            timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += timer1_Tick;

            // Timer para verificar la inactividad cada 30 segundos
            inactividadTimer = new Timer();
            inactividadTimer.Interval = 30000;
            inactividadTimer.Tick += VerificarInactividad;
            inactividadTimer.Start();
        }

        private void bttnStart_Click(object sender, EventArgs e)
        {
            if (isRunning)
            {
                tiempoTrabajado += DateTime.Now - startTime;
                pausaInicio = DateTime.Now;
                timer.Stop();
                cantidadPausas++;
                bttnStart.BackColor = Color.Yellow;
                bttnStart.Text = $"Pausado ({cantidadPausas} paradas)";
                isRunning = false;
            }
            else
            {
                if (primeraVez)
                {
                    entradaReal = DateTime.Now;
                    salida = entradaReal.AddHours(8);
                    primeraVez = false;

                    if (entradaReal > entradaEsperada)
                    {
                        retraso = entradaReal - entradaEsperada;
                        lblRetraso.Text = $"Retraso: {retraso.Hours}h {retraso.Minutes}m {retraso.Seconds}s";
                        lblRetraso.ForeColor = Color.Red;
                    }
                    else
                    {
                        lblRetraso.Text = "Sin retraso";
                        lblRetraso.ForeColor = Color.Green;
                    }
                }

                if (pausaInicio != DateTime.MinValue)
                {
                    tiempoInactivo += DateTime.Now - pausaInicio;
                }

                startTime = DateTime.Now;
                timer.Start();
                bttnStart.BackColor = Color.Green;
                bttnStart.Text = "En marcha";
                isRunning = true;
                isInactive = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan tiempoTranscurrido = DateTime.Now - entradaReal;
            lblTiempo.Text = $"Tiempo trabajado: {tiempoTranscurrido.Hours}h {tiempoTranscurrido.Minutes}m {tiempoTranscurrido.Seconds}s";
            lblInactivo.Text = $"Tiempo inactivo: {tiempoInactivo.Hours}h {tiempoInactivo.Minutes}m {tiempoInactivo.Seconds}s";

            if (DateTime.Now >= salida)
            {
                timer.Stop();
                inactividadTimer.Stop();
                bttnStart.BackColor = Color.Red;
                bttnStart.Text = "Jornada Finalizada";
                isRunning = false;
                MessageBox.Show($"La jornada ha finalizado.\nTotal de pausas: {cantidadPausas}.\nTiempo inactivo: {tiempoInactivo.Hours}h {tiempoInactivo.Minutes}m {tiempoInactivo.Seconds}s.");
                bttnStart.Enabled = false;
            }
        }

        private void VerificarInactividad(object sender, EventArgs e)
        {
            if (EsUsuarioInactivo() && isRunning)
            {
                tiempoInactivo += TimeSpan.FromSeconds(30);
                lblInactivo.Text = $"Tiempo inactivo: {tiempoInactivo.Hours}h {tiempoInactivo.Minutes}m {tiempoInactivo.Seconds}s";

                if (!isInactive)
                {
                    timer.Stop();
                    isInactive = true;
                    MessageBox.Show("Modo inactivo activado por falta de movimiento.");
                }
            }
            else if (!EsUsuarioInactivo() && isInactive)
            {
                timer.Start();
                isInactive = false;
                MessageBox.Show("Modo inactivo desactivado por detección de actividad.");
            }
        }

        private bool EsUsuarioInactivo()
        {
            LASTINPUTINFO lii = new LASTINPUTINFO();
            lii.cbSize = (uint)Marshal.SizeOf(lii);

            if (GetLastInputInfo(ref lii))
            {
                uint idleTime = ((uint)Environment.TickCount - lii.dwTime) / 1000;
                return idleTime >= 30;
            }
            return false;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        [DllImport("user32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
    }
}
